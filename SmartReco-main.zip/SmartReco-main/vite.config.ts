import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: ["5173-i9eyz2czdwynp19efow50-3ba13603.manus.computer", "5173-i3to3kj7x8zlrl6jc5ezg-ea589efb.manusvm.computer"],
  }
});

