-- AI Modeling and Insights Database Schema for SmartReco (Redesigned)
-- This schema defines tables to store AI-generated insights and predictions

-- User Segments Table
-- Stores different user segments identified by AI clustering algorithms
CREATE TABLE IF NOT EXISTS user_segments (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    characteristics TEXT[], -- Array of segment characteristics
    user_count INTEGER DEFAULT 0,
    avg_engagement DECIMAL(3,2), -- Average engagement score (0-10)
    conversion_rate DECIMAL(4,3), -- Conversion rate (0-1)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Churn Predictions Table
-- Stores AI-generated churn predictions for users
CREATE TABLE IF NOT EXISTS churn_predictions (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    churn_probability DECIMAL(4,3) NOT NULL, -- Probability (0-1)
    risk_level VARCHAR(10),
    key_factors TEXT[], -- Array of factors contributing to churn risk
    recommended_actions TEXT[], -- Array of recommended interventions
    confidence_score DECIMAL(4,3), -- Model confidence (0-1)
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id) -- One prediction per user, updated over time
);

-- Conversion Predictions Table
-- Stores AI-generated conversion predictions for users
CREATE TABLE IF NOT EXISTS conversion_predictions (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    conversion_probability DECIMAL(4,3) NOT NULL, -- Probability (0-1)
    predicted_action VARCHAR(100), -- What action user is likely to take
    confidence DECIMAL(4,3), -- Model confidence (0-1)
    time_to_conversion INTEGER, -- Predicted days until conversion
    influencing_factors TEXT[], -- Array of factors influencing conversion
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE, -- When prediction becomes stale
    UNIQUE(user_id) -- One active prediction per user
);

-- Anomaly Detections Table
-- Stores detected anomalies in metrics and user behavior
CREATE TABLE IF NOT EXISTS anomaly_detections (
    id VARCHAR(50) PRIMARY KEY,
    type VARCHAR(20),
    severity VARCHAR(10),
    description TEXT NOT NULL,
    affected_metric VARCHAR(100),
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expected_value DECIMAL(12,4),
    actual_value DECIMAL(12,4),
    deviation DECIMAL(6,4), -- Percentage deviation from expected
    possible_causes TEXT[], -- Array of possible causes
    recommended_actions TEXT[], -- Array of recommended actions
    status VARCHAR(20) DEFAULT 'open',
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by VARCHAR(50)
);

-- Funnel Insights Table
-- Stores AI-generated insights about funnel performance and bottlenecks
CREATE TABLE IF NOT EXISTS funnel_insights (
    id SERIAL PRIMARY KEY,
    funnel_id VARCHAR(50) NOT NULL,
    step_name VARCHAR(100) NOT NULL,
    dropoff_rate DECIMAL(4,3) NOT NULL, -- Actual dropoff rate (0-1)
    expected_dropoff_rate DECIMAL(4,3), -- Expected/baseline dropoff rate
    is_anomalous BOOLEAN DEFAULT FALSE,
    bottleneck_factors TEXT[], -- Array of factors causing bottlenecks
    optimization_suggestions TEXT[], -- Array of optimization suggestions
    impact_score DECIMAL(4,2), -- Potential impact of optimization (0-10)
    analyzed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(funnel_id, step_name) -- One insight per funnel step
);

-- AI Models Table
-- Stores metadata about trained AI models
CREATE TABLE IF NOT EXISTS ai_models (
    id SERIAL PRIMARY KEY,
    model_type VARCHAR(50) NOT NULL, -- e.g., 'churn_prediction', 'user_segmentation'
    version VARCHAR(20) NOT NULL,
    training_data_size INTEGER,
    accuracy_score DECIMAL(4,3), -- Model accuracy (0-1)
    precision_score DECIMAL(4,3), -- Model precision (0-1)
    recall_score DECIMAL(4,3), -- Model recall (0-1)
    f1_score DECIMAL(4,3), -- Model F1 score (0-1)
    hyperparameters JSONB, -- Model hyperparameters as JSON
    feature_importance JSONB, -- Feature importance scores as JSON
    last_trained TIMESTAMP WITH TIME ZONE,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User Features Table
-- Stores computed features for each user used in AI models
CREATE TABLE IF NOT EXISTS user_features (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    segment_id VARCHAR(50) REFERENCES user_segments(id),
    total_events INTEGER DEFAULT 0,
    unique_event_types INTEGER DEFAULT 0,
    total_sessions INTEGER DEFAULT 0,
    avg_session_duration DECIMAL(8,2), -- Average session duration in minutes
    days_since_first_event INTEGER,
    days_since_last_event INTEGER,
    engagement_score DECIMAL(4,2), -- Computed engagement score (0-10)
    feature_vector JSONB, -- Additional features as JSON
    computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id) -- One feature set per user, updated over time
);

-- AI Insights Summary Table
-- Stores high-level insights and recommendations for the dashboard
CREATE TABLE IF NOT EXISTS ai_insights_summary (
    id SERIAL PRIMARY KEY,
    insight_type VARCHAR(50) NOT NULL, -- e.g., 'churn_risk', 'conversion_opportunity', 'anomaly_alert'
    title VARCHAR(200) NOT NULL,
    description TEXT,
    priority VARCHAR(10),
    affected_users INTEGER, -- Number of users affected
    potential_impact DECIMAL(12,2), -- Potential revenue/metric impact
    recommended_actions TEXT[], -- Array of recommended actions
    status VARCHAR(20) DEFAULT 'new',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE -- When insight becomes stale
);

-- Prediction Accuracy Tracking Table
-- Tracks the accuracy of AI predictions over time for model improvement
CREATE TABLE IF NOT EXISTS prediction_accuracy (
    id SERIAL PRIMARY KEY,
    model_type VARCHAR(50) NOT NULL,
    prediction_id VARCHAR(50), -- Reference to specific prediction
    predicted_outcome VARCHAR(100),
    actual_outcome VARCHAR(100),
    prediction_date TIMESTAMP WITH TIME ZONE,
    outcome_date TIMESTAMP WITH TIME ZONE,
    was_accurate BOOLEAN,
    confidence_score DECIMAL(4,3),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- New: AI Explanations Table
CREATE TABLE IF NOT EXISTS ai_explanations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dropoff_insight_id UUID REFERENCES dropoff_insights(id),
    hypothesis_text TEXT NOT NULL,
    evidence_summary TEXT,
    evidence_details JSONB,
    ai_reasoning_trace JSONB,
    confidence_score DECIMAL(4,3),
    generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- New: Workflow Sync Log Table
CREATE TABLE IF NOT EXISTS workflow_sync_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_id UUID REFERENCES recommendations(id),
    platform VARCHAR(50) NOT NULL, -- e.g., 'JIRA', 'Notion'
    ticket_id VARCHAR(255),
    sync_status VARCHAR(20) NOT NULL,
    synced_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    sync_details JSONB
);

-- New: User Feedback Table
CREATE TABLE IF NOT EXISTS user_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_id UUID REFERENCES recommendations(id),
    feedback_type VARCHAR(50) NOT NULL, -- 'approve', 'edit', 'dismiss', 'explanation_clarity', 'general'
    feedback_text TEXT,
    user_id VARCHAR(50), -- Assuming user_id exists elsewhere or is captured
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    context JSONB
);

-- Modified: dropoff_insights Table
ALTER TABLE dropoff_insights
ADD COLUMN ai_generated_hypothesis_id UUID REFERENCES ai_explanations(id),
ADD COLUMN ai_generated_recommendation_ids UUID[];

-- Modified: recommendations Table
ALTER TABLE recommendations
ADD COLUMN user_feedback TEXT,
ADD COLUMN jira_ticket_id VARCHAR(255),
ADD COLUMN ai_estimated_impact DECIMAL(12,2),
ADD COLUMN ai_estimated_effort VARCHAR(10);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_churn_predictions_user_id ON churn_predictions(user_id);
CREATE INDEX IF NOT EXISTS idx_churn_predictions_risk_level ON churn_predictions(risk_level);
CREATE INDEX IF NOT EXISTS idx_churn_predictions_last_updated ON churn_predictions(last_updated);

CREATE INDEX IF NOT EXISTS idx_conversion_predictions_user_id ON conversion_predictions(user_id);
CREATE INDEX IF NOT EXISTS idx_conversion_predictions_probability ON conversion_predictions(conversion_probability);

CREATE INDEX IF NOT EXISTS idx_anomaly_detections_type ON anomaly_detections(type);
CREATE INDEX IF NOT EXISTS idx_anomaly_detections_severity ON anomaly_detections(severity);
CREATE INDEX IF NOT EXISTS idx_anomaly_detections_status ON anomaly_detections(status);
CREATE INDEX IF NOT EXISTS idx_anomaly_detections_detected_at ON anomaly_detections(detected_at);

CREATE INDEX IF NOT EXISTS idx_funnel_insights_funnel_id ON funnel_insights(funnel_id);
CREATE INDEX IF NOT EXISTS idx_funnel_insights_is_anomalous ON funnel_insights(is_anomalous);

CREATE INDEX IF NOT EXISTS idx_user_features_user_id ON user_features(user_id);
CREATE INDEX IF NOT EXISTS idx_user_features_segment_id ON user_features(segment_id);
CREATE INDEX IF NOT EXISTS idx_user_features_engagement_score ON user_features(engagement_score);

CREATE INDEX IF NOT EXISTS idx_ai_insights_summary_type ON ai_insights_summary(insight_type);
CREATE INDEX IF NOT EXISTS idx_ai_insights_summary_priority ON ai_insights_summary(priority);
CREATE INDEX IF NOT EXISTS idx_ai_insights_summary_status ON ai_insights_summary(status);

-- New Indexes for new tables/columns
CREATE INDEX IF NOT EXISTS idx_ai_explanations_dropoff_insight_id ON ai_explanations(dropoff_insight_id);
CREATE INDEX IF NOT EXISTS idx_workflow_sync_log_recommendation_id ON workflow_sync_log(recommendation_id);
CREATE INDEX IF NOT EXISTS idx_user_feedback_recommendation_id ON user_feedback(recommendation_id);

-- Create views for common queries
CREATE OR REPLACE VIEW high_churn_risk_users AS
SELECT 
    cp.user_id,
    cp.churn_probability,
    cp.risk_level,
    cp.key_factors,
    cp.recommended_actions,
    uf.engagement_score,
    us.name as segment_name
FROM churn_predictions cp
LEFT JOIN user_features uf ON cp.user_id = uf.user_id
LEFT JOIN user_segments us ON uf.segment_id = us.id
WHERE cp.risk_level IN (
    'medium', 'high'
)
ORDER BY cp.churn_probability DESC;

CREATE OR REPLACE VIEW high_conversion_potential_users AS
SELECT 
    cp.user_id,
    cp.conversion_probability,
    cp.predicted_action,
    cp.time_to_conversion,
    uf.engagement_score,
    us.name as segment_name
FROM conversion_predictions cp
LEFT JOIN user_features uf ON cp.user_id = uf.user_id
LEFT JOIN user_segments us ON uf.segment_id = us.id
WHERE cp.conversion_probability > 0.6
ORDER BY cp.conversion_probability DESC;

CREATE OR REPLACE VIEW active_anomalies AS
SELECT 
    id,
    type,
    severity,
    description,
    affected_metric,
    detected_at,
    deviation,
    recommended_actions
FROM anomaly_detections
WHERE status = 'open'
ORDER BY severity DESC, detected_at DESC;

CREATE OR REPLACE VIEW funnel_bottlenecks AS
SELECT 
    funnel_id,
    step_name,
    dropoff_rate,
    expected_dropoff_rate,
    (dropoff_rate - expected_dropoff_rate) as excess_dropoff,
    optimization_suggestions,
    impact_score
FROM funnel_insights
WHERE is_anomalous = true
ORDER BY impact_score DESC;

-- Insert sample data for testing
INSERT INTO user_segments (id, name, description, characteristics, user_count, avg_engagement, conversion_rate) VALUES
('power_users', 'Power Users', 'Highly engaged users with frequent product usage', ARRAY['High session frequency', 'Long session duration', 'Feature exploration'], 150, 8.5, 0.85),
('regular_users', 'Regular Users', 'Consistent users with moderate engagement', ARRAY['Regular login patterns', 'Core feature usage', 'Steady growth'], 600, 6.2, 0.45),
('at_risk_users', 'At-Risk Users', 'Users showing declining engagement patterns', ARRAY['Decreasing session frequency', 'Limited feature usage', 'Long gaps between sessions'], 250, 3.1, 0.15)
ON CONFLICT (id) DO UPDATE SET
    user_count = EXCLUDED.user_count,
    avg_engagement = EXCLUDED.avg_engagement,
    conversion_rate = EXCLUDED.conversion_rate,
    updated_at = NOW();

-- Insert sample AI insights
INSERT INTO ai_insights_summary (insight_type, title, description, priority, affected_users, potential_impact, recommended_actions) VALUES
('churn_risk', 'High Churn Risk Detected', '45 users showing high probability of churning within next 30 days', 'high', 45, 15000.00, ARRAY['Send re-engagement campaign', 'Offer customer success consultation', 'Provide feature training']),
('conversion_opportunity', 'Conversion Opportunities Identified', '120 users with high conversion potential for premium features', 'medium', 120, 25000.00, ARRAY['Send targeted upgrade offers', 'Highlight premium features', 'Offer limited-time discount']),
('anomaly_alert', 'Unusual Drop in Sign-ups', 'Sign-up rate dropped 35% below expected in last 24 hours', 'critical', 0, -5000.00, ARRAY['Check sign-up flow', 'Review recent changes', 'Monitor error logs'])
ON CONFLICT DO NOTHING;





















