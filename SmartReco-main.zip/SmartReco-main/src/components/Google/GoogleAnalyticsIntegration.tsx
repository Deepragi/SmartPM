import React, { useState, useEffect } from 'react';
import {
  Settings,
  Upload,
  BarChart3,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Download,
  RefreshCw,
  Database,
  FileText,
  Zap,
  TrendingUp
} from 'lucide-react';
import { googleAnalyticsService, GAConfig, GAEvent, GAUser, GASession, GAFunnel } from '../../lib/google-analytics-integration';
import { DataValidationService, DataQualityReport } from '../../lib/data-validation';

interface GoogleAnalyticsIntegrationProps {
  isOpen: boolean;
  onClose: () => void;
  onDataImported?: (data: any) => void;
  onDataImportedAndShowSummary: (data: any, report: DataQualityReport) => void; // Modified prop
  onBack?: () => void;
}

const GoogleAnalyticsIntegration: React.FC<GoogleAnalyticsIntegrationProps> = ({
  isOpen,
  onClose,
  onDataImported,
  onDataImportedAndShowSummary,
  onBack
}) => {
  const [activeTab, setActiveTab] = useState<'config' | 'import'>('import'); // Default to import tab
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  const [config, setConfig] = useState<GAConfig>({
    property_id: '',
    access_token: '',
    oauth_client_id: '',
    oauth_client_secret: '',
    refresh_token: ''
  });
  
  // Import state
  const [importType, setImportType] = useState<'api' | 'csv'>('api');
  const [dataType, setDataType] = useState<'events' | 'users' | 'sessions' | 'funnels'>('events');
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStatus, setImportStatus] = useState('');
  
  // Quality report state
  const [qualityReport, setQualityReport] = useState<DataQualityReport | null>(null);
  
  // CSV upload state
  const [csvFile, setCsvFile] = useState<File | null>(null);
  
  // Funnel configuration
  const [funnelSteps, setFunnelSteps] = useState<string[]>(['page_view', 'signup', 'purchase']);

  useEffect(() => {
    if (config.property_id && config.access_token) {
      // Update the service configuration
      googleAnalyticsService.config = config;
    }
  }, [config]);

  const handleTestConnection = async () => {
    if (!config.property_id || !config.access_token) {
      setConnectionStatus('error');
      return;
    }

    setConnectionStatus('connecting');
    
    try {
      const isConnected = await googleAnalyticsService.testConnection();
      setConnectionStatus(isConnected ? 'connected' : 'error');
    } catch (error) {
      console.error('Connection test failed:', error);
      setConnectionStatus('error');
    }
  };

  const handleImportFromAPI = async () => {
    if (connectionStatus !== 'connected') {
      alert('Please configure and test your Google Analytics connection first.');
      return;
    }

    setIsImporting(true);
    setImportProgress(0);
    setImportStatus('Starting import...');

    try {
      let importedData: any = null;

      switch (dataType) {
        case 'events':
          setImportStatus('Pulling event data from Google Analytics...');
          setImportProgress(25);
          importedData = await googleAnalyticsService.pullEventData();
          setImportProgress(50);
          
          setImportStatus('Validating event data...');
          // For now, use a mock report, in a real app, you'd validate the actual data
          const eventReport = DataValidationService.generateDataQualityReport(importedData, [], []);
          setQualityReport(eventReport);
          setImportProgress(75);
          
          if (eventReport.overall.isValid) {
            setImportStatus('Storing event data...');
            await googleAnalyticsService.storeEventData(importedData);
          }
          break;

        case 'users':
          setImportStatus('Pulling user data from Google Analytics...');
          setImportProgress(25);
          importedData = await googleAnalyticsService.pullUserData();
          const userReport = DataValidationService.generateDataQualityReport([], importedData, []);
          setQualityReport(userReport);
          setImportProgress(75);
          break;

        case 'sessions':
          setImportStatus('Pulling session data from Google Analytics...');
          setImportProgress(25);
          importedData = await googleAnalyticsService.pullSessionData();
          const sessionReport = DataValidationService.generateDataQualityReport([], [], importedData);
          setQualityReport(sessionReport);
          setImportProgress(75);
          break;

        case 'funnels':
          setImportStatus('Pulling funnel data from Google Analytics...');
          setImportProgress(25);
          importedData = await googleAnalyticsService.pullFunnelData(funnelSteps);
          // No specific data quality for funnels in current mock, but can be added
          setImportProgress(75);
          break;
      }

      setImportProgress(100);
      setImportStatus(`Successfully imported ${Array.isArray(importedData) ? importedData.length : 1} ${dataType} records`);
      
      if (onDataImported) {
        onDataImported(importedData);
      }
      if (onDataImportedAndShowSummary && qualityReport) {
        onDataImportedAndShowSummary(importedData, qualityReport);
      }

    } catch (error) {
      console.error('Import failed:', error);
      setImportStatus(`Import failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsImporting(false);
      setTimeout(() => {
        setImportProgress(0);
        setImportStatus('');
      }, 3000);
    }
  };

  const handleCSVUpload = async () => {
    if (!csvFile) {
      alert('Please select a CSV file to upload.');
      return;
    }

    setIsImporting(true);
    setImportProgress(0);
    setImportStatus('Processing CSV file...');

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        console.log('FileReader onload triggered');
        const text = e.target?.result as string;
        console.log('CSV raw text:', text.substring(0, 200) + '...'); // Log first 200 chars
        const lines = text.split('\n').filter(line => line.trim() !== '');
        const headers = lines[0].split(',').map(header => header.trim());
        const parsedData = lines.slice(1).map(line => {
          const values = line.split(',').map(value => value.trim());
          return headers.reduce((obj, header, index) => {
            obj[header] = values[index];
            return obj;
          }, {} as Record<string, string>);
        });
        console.log('Parsed CSV data:', parsedData);

        setImportProgress(50);
        setImportStatus('Validating CSV data...');
        
        const report = DataValidationService.generateDataQualityReport(parsedData, [], []);
        console.log('Generated Data Quality Report:', report);
        setQualityReport(report);

        setImportProgress(100);
        setImportStatus('CSV data imported successfully');
        
        if (onDataImported) {
          onDataImported(parsedData);
        }
        if (onDataImportedAndShowSummary && report) {
          console.log('Calling onDataImportedAndShowSummary with:', parsedData, report);
          onDataImportedAndShowSummary(parsedData, report);
        }

        setIsImporting(false);
        setTimeout(() => {
          setImportProgress(0);
          setImportStatus('');
        }, 3000);
      };
      reader.readAsText(csvFile);

    } catch (error) {
      console.error('CSV import failed:', error);
      setImportStatus(`CSV import failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setIsImporting(false);
      setTimeout(() => {
        setImportProgress(0);
        setImportStatus('');
      }, 3000);
    }
  };

  const downloadTemplate = (type: string) => {
    const templates = {
      events: 'event_id,user_id,session_id,timestamp,event_name,event_parameters,device_category,country,source,medium\nga_event_1,user_123,session_456,2024-01-01T10:00:00Z,page_view,"{""page"":""/home""}",desktop,US,google,organic',
      users: 'user_id,first_visit_date,last_visit_date,total_sessions,total_events,device_category,country,city\nuser_123,2024-01-01T10:00:00Z,2024-01-15T15:30:00Z,5,25,desktop,US,New York',
      sessions: 'session_id,user_id,session_start,session_end,session_duration,page_views,events,device_category,country,source\nsession_456,user_123,2024-01-01T10:00:00Z,2024-01-01T10:30:00Z,1800,5,12,desktop,US,google'
    };
    
    const content = templates[type as keyof typeof templates] || templates.events;
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ga_${type}_template.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            {onBack && (
              <button
                onClick={onBack}
                className="flex items-center text-gray-600 hover:text-gray-800 transition-colors mr-2"
              >
                <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back
              </button>
            )}
            <TrendingUp className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Google Analytics Integration</h2>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {connectionStatus === 'connected' && (
                <>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-green-600">Connected</span>
                </>
              )}
              {connectionStatus === 'disconnected' && (
                <>
                  <XCircle className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-500">Disconnected</span>
                </>
              )}
              {connectionStatus === 'error' && (
                <>
                  <XCircle className="h-4 w-4 text-red-500" />
                  <span className="text-sm text-red-600">Connection Error</span>
                </>
              )}
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <p className="text-gray-600">Configure data sources and import analytics data</p>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-1 mb-6">
            <button
              onClick={() => setActiveTab('config')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium ${
                activeTab === 'config'
                  ? 'bg-blue-100 text-blue-700 border border-blue-200'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Settings className="h-4 w-4" />
              <span>Configuration</span>
            </button>
            <button
              onClick={() => setActiveTab('import')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium ${
                activeTab === 'import'
                  ? 'bg-orange-100 text-orange-700 border border-orange-200'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Upload className="h-4 w-4" />
              <span>Data Import</span>
            </button>
          </div>

          {/* Configuration Tab */}
          {activeTab === 'config' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium">Google Analytics Configuration</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Property ID
                  </label>
                  <input
                    type="text"
                    value={config.property_id}
                    onChange={(e) => setConfig(prev => ({ ...prev, property_id: e.target.value }))}
                    placeholder="123456789"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Access Token
                  </label>
                  <input
                    type="password"
                    value={config.access_token}
                    onChange={(e) => setConfig(prev => ({ ...prev, access_token: e.target.value }))}
                    placeholder="ya29.a0AfH6SMC..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    OAuth Client ID (Optional)
                  </label>
                  <input
                    type="text"
                    value={config.oauth_client_id}
                    onChange={(e) => setConfig(prev => ({ ...prev, oauth_client_id: e.target.value }))}
                    placeholder="123456789-abc.apps.googleusercontent.com"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    OAuth Client Secret (Optional)
                  </label>
                  <input
                    type="password"
                    value={config.oauth_client_secret}
                    onChange={(e) => setConfig(prev => ({ ...prev, oauth_client_secret: e.target.value }))}
                    placeholder="GOCSPX-..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <button
                onClick={handleTestConnection}
                disabled={connectionStatus === 'connecting'}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {connectionStatus === 'connecting' ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Zap className="h-4 w-4" />
                )}
                <span>Test Connection</span>
              </button>
            </div>
          )}

          {/* Data Import Tab */}
          {activeTab === 'import' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium">Data Import</h3>
              
              {/* Data Source Selection */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">Data Source</h4>
                <div className="flex space-x-4">
                  <button
                    onClick={() => setImportType('api')}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
                      importType === 'api'
                        ? 'bg-blue-50 border-blue-200 text-blue-700'
                        : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Database className="h-4 w-4" />
                    <span>Google Analytics API</span>
                  </button>
                  <button
                    onClick={() => setImportType('csv')}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
                      importType === 'csv'
                        ? 'bg-pink-50 border-pink-200 text-pink-700'
                        : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <FileText className="h-4 w-4" />
                    <span>CSV Upload</span>
                  </button>
                </div>
              </div>

              {/* Data Type Selection */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">Data Type</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {['events', 'users', 'sessions', 'funnels'].map((type) => (
                    <button
                      key={type}
                      onClick={() => setDataType(type as any)}
                      className={`px-3 py-2 rounded-lg border text-sm font-medium capitalize ${
                        dataType === type
                          ? 'bg-purple-50 border-purple-200 text-purple-700'
                          : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Funnel Configuration */}
              {dataType === 'funnels' && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-3">Funnel Steps</h4>
                  <div className="space-y-2">
                    {funnelSteps.map((step, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <span className="text-sm text-gray-500 w-12">Step {index + 1}:</span>
                        <input
                          type="text"
                          value={step}
                          onChange={(e) => {
                            const newSteps = [...funnelSteps];
                            newSteps[index] = e.target.value;
                            setFunnelSteps(newSteps);
                          }}
                          className="flex-1 px-3 py-1 border border-gray-300 rounded-md text-sm"
                        />
                        {funnelSteps.length > 1 && (
                          <button
                            onClick={() => setFunnelSteps(funnelSteps.filter((_, i) => i !== index))}
                            className="text-red-500 hover:text-red-700"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    ))}
                    <button
                      onClick={() => setFunnelSteps([...funnelSteps, ''])} 
                      className="text-sm text-blue-600 hover:text-blue-800"
                    >
                      + Add Step
                    </button>
                  </div>
                </div>
              )}

              {/* API Import */}
              {importType === 'api' && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-3">Import from Google Analytics API</h4>
                  <p className="text-sm text-gray-600 mb-4">
                    Import {dataType} data from your configured Google Analytics property.
                  </p>
                  <button
                    onClick={handleImportFromAPI}
                    disabled={isImporting || connectionStatus !== 'connected'}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Import {dataType}</span>
                  </button>
                </div>
              )}

              {/* CSV Import */}
              {importType === 'csv' && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-3">Upload CSV File</h4>
                  <p className="text-sm text-gray-600 mb-4">
                    Upload a CSV file containing {dataType} data.
                  </p>
                  <div className="space-y-4">
                    <input
                      type="file"
                      accept=".csv"
                      onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                      className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                    <div className="flex space-x-2">
                      <button
                        onClick={handleCSVUpload}
                        disabled={isImporting || !csvFile}
                        className="flex items-center space-x-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
                      >
                        <Upload className="h-4 w-4" />
                        <span>Import CSV</span>
                      </button>
                      <button
                        onClick={() => downloadTemplate(dataType)}
                        className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download Template</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Import Progress */}
              {isImporting && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span className="text-sm font-medium text-blue-800">Importing...</span>
                  </div>
                  <div className="w-full bg-blue-200 rounded-full h-2 mb-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${importProgress}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-blue-700">{importStatus}</p>
                </div>
              )}

              {/* Import Status */}
              {importStatus && !isImporting && (
                <div className={`border rounded-lg p-4 ${
                  importStatus.includes('Successfully') 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-red-50 border-red-200'
                }`}>
                  <div className="flex items-center space-x-2">
                    {importStatus.includes('Successfully') ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-600" />
                    )}
                    <span className={`text-sm font-medium ${
                      importStatus.includes('Successfully') ? 'text-green-800' : 'text-red-800'
                    }`}>
                      {importStatus}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GoogleAnalyticsIntegration;








