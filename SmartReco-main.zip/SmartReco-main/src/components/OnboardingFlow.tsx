import React from 'react';

interface OnboardingFlowProps {
  onComplete: () => void;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md text-center">
        <h2 className="text-2xl font-bold mb-4">Welcome to SmartPM!</h2>
        <p className="text-gray-700 mb-6">Let's get you set up.</p>
        <button
          onClick={onComplete}
          className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
        >
          Start Onboarding
        </button>
      </div>
    </div>
  );
};

export default OnboardingFlow;


