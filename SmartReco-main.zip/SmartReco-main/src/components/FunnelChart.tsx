import React from 'react';
import { FunnelStep } from '../lib/database.types';
import { ArrowDown } from 'lucide-react';

interface FunnelChartProps {
  data: FunnelStep[];
}

const FunnelChart: React.FC<FunnelChartProps> = ({ data }) => {
  const sortedData = [...data].sort((a, b) => a.step_order - b.step_order);
  
  return (
    <div className="space-y-4">
      {sortedData.map((step, index) => {
        const width = step.conversion_rate * 100;
        const nextStep = sortedData[index + 1];
        const dropRate = nextStep ? ((step.conversion_rate - nextStep.conversion_rate) / step.conversion_rate) * 100 : 0;
        
        return (
          <div key={step.step_name} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-medium text-blue-600">
                  {index + 1}
                </div>
                <span className="font-medium text-gray-900">{step.step_name}</span>
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold text-gray-900">{(step.conversion_rate * 100).toFixed(1)}%</div>
                <div className="text-sm text-gray-600">conversion rate</div>
              </div>
            </div>
            
            <div className="relative">
              <div className="w-full bg-gray-200 rounded-full h-6">
                <div
                  className="bg-gradient-to-r from-blue-500 to-purple-600 h-6 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${width}%` }}
                />
              </div>
              {nextStep && dropRate > 20 && (
                <div className="absolute -right-2 top-1/2 transform -translate-y-1/2 bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                  -{dropRate.toFixed(0)}%
                </div>
              )}
            </div>
            
            {index < sortedData.length - 1 && (
              <div className="flex justify-center py-2">
                <ArrowDown className="h-4 w-4 text-gray-400" />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default FunnelChart;