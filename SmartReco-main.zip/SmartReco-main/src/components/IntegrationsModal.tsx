import React, { useState } from 'react';
import {
  Settings,
  TrendingUp,
  Database,
  BarChart3,
  Zap,
  ArrowRight,
  CheckCircle,
  Upload,
  Download,
  Shield,
  Lightbulb
} from 'lucide-react';
import HeapIntegration from './HeapIntegration';
import GoogleAnalyticsIntegration from './Google/GoogleAnalyticsIntegration';
import PostImportSummary from './PostImportSummary';
import { DataQualityReport } from '../lib/data-validation';

interface IntegrationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectHeap: () => void;
  onSelectGoogleAnalytics: () => void;
  isConnected: boolean;
}

const IntegrationsModal: React.FC<IntegrationsModalProps> = ({
  isOpen,
  onClose,
  onSelectHeap,
  onSelectGoogleAnalytics,
  isConnected
}) => {
  const [currentView, setCurrentView] = useState<'selection' | 'heap' | 'googleAnalytics' | 'summary'>('selection');
  const [importedData, setImportedData] = useState<any>(null);
  const [dataQualityReport, setDataQualityReport] = useState<DataQualityReport | null>(null);

  if (!isOpen) return null;

  const handleHeapSelect = () => {
    setCurrentView('heap');
  };

  const handleGoogleAnalyticsSelect = () => {
    setCurrentView('googleAnalytics');
  };

  const handleDataImportedAndShowSummary = (data: any, report: DataQualityReport) => {
    console.log('handleDataImportedAndShowSummary called with:', { data, report });
    setImportedData(data);
    setDataQualityReport(report);
    setCurrentView('summary');
  };

  const handleCloseSummary = () => {
    setCurrentView('selection');
    setImportedData(null);
    setDataQualityReport(null);
  };

  const handleBackToSelection = () => {
    setCurrentView('selection');
    setImportedData(null);
    setDataQualityReport(null);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-white bg-opacity-20 rounded-lg p-2">
                <Settings className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Analytics Integrations</h2>
                <p className="text-purple-100">Connect your analytics platforms to SmartReco</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-purple-200 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 flex-grow overflow-y-auto">
          {currentView === 'selection' && (
            <>
              <div className="text-center mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Choose Your Analytics Platform
                </h3>
                <p className="text-gray-600">
                  Select an analytics platform to configure data import and quality monitoring
                </p>
              </div>

              {/* Integration Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Heap Analytics Card */}
                <div className="group relative bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl p-6 hover:border-blue-400 hover:shadow-lg transition-all duration-300 cursor-pointer">
                  <div className="absolute top-4 right-4">
                    <div className="bg-blue-100 rounded-full p-2 group-hover:bg-blue-200 transition-colors">
                      <Settings className="h-5 w-5 text-blue-600" />
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="bg-blue-600 rounded-lg p-2">
                        <Database className="h-6 w-6 text-white" />
                      </div>
                      <h4 className="text-xl font-bold text-gray-900">Heap Analytics</h4>
                    </div>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      Connect to Heap Analytics for comprehensive event tracking and user behavior analysis. 
                      Import data from data warehouses or CSV exports.
                    </p>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={handleHeapSelect}
                    className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 group-hover:shadow-md"
                  >
                    <span>Configure Heap</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>

                  {/* Data Types */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">Events</span>
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">Users</span>
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">Sessions</span>
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">Funnels</span>
                  </div>
                </div>

                {/* Google Analytics Card */}
                <div className="group relative bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6 hover:border-green-400 hover:shadow-lg transition-all duration-300 cursor-pointer">
                  <div className="absolute top-4 right-4">
                    <div className="bg-green-100 rounded-full p-2 group-hover:bg-green-200 transition-colors">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="bg-green-600 rounded-lg p-2">
                        <BarChart3 className="h-6 w-6 text-white" />
                      </div>
                      <h4 className="text-xl font-bold text-gray-900">Google Analytics</h4>
                    </div>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      Connect to Google Analytics for real-time data access and comprehensive web analytics. 
                      Pull data directly via API or import CSV exports.
                    </p>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={handleGoogleAnalyticsSelect}
                    className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center space-x-2 group-hover:shadow-md"
                  >
                    <span>Configure Google Analytics</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>

                  {/* Data Types */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Events</span>
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Users</span>
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Sessions</span>
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Funnels</span>
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div className="mt-8 bg-gray-50 rounded-lg p-6">
                <div className="flex items-start space-x-3">
                  <div className="bg-purple-100 rounded-full p-2">
                    <Shield className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-900 mb-2">Data Security & Privacy</h5>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      All integrations use secure authentication methods and encrypted data transmission. 
                      Your analytics data is processed locally and stored securely in your Supabase database. 
                      We never store or access your raw analytics data on our servers.
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <Upload className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="text-sm font-medium text-gray-900">Import Data</div>
                    <div className="text-xs text-gray-600">CSV or API import</div>
                  </div>
                </div>

                <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                  <Zap className="h-5 w-5 text-purple-600" />
                  <div>
                    <div className="text-sm font-medium text-gray-900">Real-time Sync</div>
                    <div className="text-xs text-gray-600">Live data updates</div>
                  </div>
                </div>
              </div>
            </>
          )}

          {currentView === 'heap' && (
            <HeapIntegration
              onDataImported={() => {}} // This can be removed if not needed for dashboard refresh
              onDataImportedAndShowSummary={handleDataImportedAndShowSummary}
              onBack={handleBackToSelection}
            />
          )}

          {currentView === 'googleAnalytics' && (
            <GoogleAnalyticsIntegration
              isOpen={true} // Always open when this view is active
              onClose={handleBackToSelection} // Close GA integration returns to selection
              onDataImported={() => {}} // This can be removed if not needed for dashboard refresh
              onDataImportedAndShowSummary={handleDataImportedAndShowSummary}
              onBack={handleBackToSelection}
            />
          )}

          {currentView === 'summary' && (
            <PostImportSummary
              isOpen={true} // Always open when this view is active
              onClose={handleCloseSummary}
              dataQualityReport={dataQualityReport}
              isConnected={isConnected}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default IntegrationsModal;