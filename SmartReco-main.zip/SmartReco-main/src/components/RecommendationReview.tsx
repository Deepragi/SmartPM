import React, { useState } from 'react';
import { DropoffInsight, Recommendation } from '../lib/database.types';
import { X, CheckCircle, XCircle, Edit3, ExternalLink, Brain, Target, Zap, MessageSquare, TrendingUp, TrendingDown } from 'lucide-react';

interface RecommendationReviewProps {
  dropoff: DropoffInsight;
  onClose: () => void;
  onRecommendationUpdate?: (recommendationId: string, status: 'approved' | 'dismissed' | 'edited', notes?: string) => Promise<void>;
  onWorkflowSync?: (recommendationId: string, platform: 'jira' | 'notion', ticketId?: string, syncDetails?: Record<string, any>) => Promise<void>;
  isConnected?: boolean;
}

const RecommendationReview: React.FC<RecommendationReviewProps> = ({
  dropoff,
  onClose,
  onRecommendationUpdate,
  onWorkflowSync,
  isConnected = false
}) => {
  const [recommendations, setRecommendations] = useState<Recommendation[]>(
    dropoff.recommendations.map(rec => ({ ...rec, status: rec.status || 'pending' }))
  );
  const [selectedRec, setSelectedRec] = useState<string | null>(null);
  const [showWorkflowSync, setShowWorkflowSync] = useState(false);
  const [reviewNotes, setReviewNotes] = useState<{ [key: string]: string }>({});
  const [syncing, setSyncing] = useState<{ [key: string]: boolean }>({});

  const handleRecommendationAction = async (recId: string, action: 'approved' | 'dismissed' | 'edited') => {
    const notes = reviewNotes[recId] || '';

    // Update local state immediately for better UX
    setRecommendations(prev =>
      prev.map(rec =>
        rec.id === recId ? { ...rec, status: action } : rec
      )
    );

    // Update database if connected
    if (isConnected && onRecommendationUpdate) {
      try {
        await onRecommendationUpdate(recId, action, notes);
      } catch (error) {
        console.error('Failed to update recommendation:', error);
        // Revert local state on error
        setRecommendations(prev =>
          prev.map(rec =>
            rec.id === recId ? { ...rec, status: 'pending' } : rec
          )
        );
      }
    }

    if (action === 'approved') {
      setShowWorkflowSync(true);
    }
  };

  const handleWorkflowSyncAction = async (recId: string, platform: 'jira' | 'notion') => {
    if (!isConnected || !onWorkflowSync) {
      // Show mock success for demo
      setShowWorkflowSync(true);
      return;
    }

    setSyncing(prev => ({ ...prev, [recId]: true }));

    try {
      await onWorkflowSync(recId, platform);
      // Show success feedback
    } catch (error) {
      console.error('Failed to sync to workflow:', error);
    } finally {
      setSyncing(prev => ({ ...prev, [recId]: false }));
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-600 bg-green-50 border-green-200';
      case 'dismissed': return 'text-red-600 bg-red-50 border-red-200';
      case 'edited': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence > 0.8) return 'text-green-600 bg-green-50';
    if (confidence > 0.6) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getImpactEffortColor = (value: 'low' | 'medium' | 'high') => {
    switch (value) {
      case 'low': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'high': return 'text-red-600 bg-red-50';
    }
  };

  const approvedRecommendations = recommendations.filter(rec => rec.status === 'approved');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b bg-gradient-to-r from-blue-50 to-purple-50">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">
              Drop-off Analysis: {dropoff.step_from} → {dropoff.step_to}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-2 hover:bg-white rounded-full"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
            <span>Impact Score: <strong className="text-red-600">{(dropoff.impact_score * 100).toFixed(0)}%</strong></span>
            <span>Drop Rate: <strong className="text-red-600">{(dropoff.drop_rate * 100).toFixed(1)}%</strong></span>
            <span>Affected Users: <strong className="text-gray-900">{dropoff.affected_users.toLocaleString()}</strong></span>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* AI Hypothesis */}
          {dropoff.ai_explanation && (
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-2 mb-3">
                <Brain className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-blue-900">AI Hypothesis</h3>
              </div>
              <p className="text-blue-800 leading-relaxed">{dropoff.ai_explanation.hypothesis_text}</p>
              {dropoff.ai_explanation.evidence_summary && (
                <p className="text-blue-700 text-sm mt-2"><strong>Evidence Summary:</strong> {dropoff.ai_explanation.evidence_summary}</p>
              )}
            </div>
          )}

          {/* Recommendations */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Zap className="h-5 w-5 text-orange-600" />
              <h3 className="font-semibold text-gray-900">Recommendations</h3>
              <span className="text-sm text-gray-500">({recommendations.length} total)</span>
            </div>
            <div className="space-y-4">
              {recommendations.map((rec) => (
                <div
                  key={rec.id}
                  className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                    selectedRec === rec.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h4 className="font-medium text-gray-900">{rec.title}</h4>
                        <span className={`px-2 py-1 text-xs rounded-full ${getConfidenceColor(rec.confidence)}`}>
                          {(rec.confidence * 100).toFixed(0)}% confidence
                        </span>
                        {rec.status !== 'pending' && (
                          <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(rec.status)}`}>
                            {rec.status}
                          </span>
                        )}
                      </div>
                      <p className="text-gray-600 mb-2">{rec.description}</p>
                      <p className="text-sm text-gray-500 italic">{rec.rationale}</p>

                      {/* New fields: Estimated Impact and Effort */}
                      <div className="grid grid-cols-2 gap-2 mt-3 text-sm">
                        <div className="flex items-center">
                          <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                          <span className="text-gray-600">Est. Impact:</span>
                          <span className={`ml-1 px-2 py-0.5 rounded-full text-xs font-medium ${getImpactEffortColor(rec.estimated_impact_level)}`}>
                            {rec.estimated_impact_level}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                          <span className="text-gray-600">Est. Effort:</span>
                          <span className={`ml-1 px-2 py-0.5 rounded-full text-xs font-medium ${getImpactEffortColor(rec.estimated_effort_level)}`}>
                            {rec.estimated_effort_level}
                          </span>
                        </div>
                      </div>

                    </div>
                  </div>

                  {rec.status === 'pending' && (
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Review Notes (Optional)
                        </label>
                        <div className="relative">
                          <MessageSquare className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                          <textarea
                            value={reviewNotes[rec.id] || ''}
                            onChange={(e) => setReviewNotes(prev => ({ ...prev, [rec.id]: e.target.value }))}
                            placeholder="Add your thoughts or modifications..."
                            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                            rows={2}
                          />
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleRecommendationAction(rec.id, 'approved')}
                          className="flex items-center space-x-1 px-3 py-2 text-sm bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors"
                        >
                          <CheckCircle className="h-4 w-4" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec.id, 'edited')}
                          className="flex items-center space-x-1 px-3 py-2 text-sm bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors"
                        >
                          <Edit3 className="h-4 w-4" />
                          <span>Edit</span>
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec.id, 'dismissed')}
                          className="flex items-center space-x-1 px-3 py-2 text-sm bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition-colors"
                        >
                          <XCircle className="h-4 w-4" />
                          <span>Dismiss</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Workflow Sync */}
          {(showWorkflowSync || approvedRecommendations.length > 0) && (
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center space-x-2 mb-3">
                <ExternalLink className="h-5 w-5 text-green-600" />
                <h3 className="font-semibold text-green-900">Workflow Integration</h3>
              </div>
              <p className="text-green-800 mb-3">
                {approvedRecommendations.length > 0
                  ? `${approvedRecommendations.length} approved recommendation(s) ready to sync to your workflow tools.`
                  : 'Ready to sync approved recommendations to your workflow tools.'
                }
              </p>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => approvedRecommendations.forEach(rec => handleWorkflowSyncAction(rec.id, 'jira'))}
                  disabled={Object.values(syncing).some(Boolean)}
                  className="flex items-center space-x-1 px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors disabled:opacity-50"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>Push to JIRA</span>
                  {Object.values(syncing).some(Boolean) && (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white ml-1"></div>
                  )}
                </button>
                <button
                  onClick={() => approvedRecommendations.forEach(rec => handleWorkflowSyncAction(rec.id, 'notion'))}
                  disabled={Object.values(syncing).some(Boolean)}
                  className="flex items-center space-x-1 px-3 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors disabled:opacity-50"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>Push to Notion</span>
                </button>
              </div>
              {!isConnected && (
                <p className="text-sm text-green-700 mt-2 italic">
                  Connect to Supabase to enable real workflow integration
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecommendationReview;

