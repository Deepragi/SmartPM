import React, { useState, useEffect } from 'react';
import { DatabaseService } from '../lib/supabase';
import { AIEnhancedDataService } from '../lib/ai-enhanced-data';
import { DropoffInsight, FunnelStep, AIExplanation } from '../lib/database.types';
import { AlertCircle, RefreshCw, Settings, Wifi, WifiOff, Brain, TrendingUp, Lightbulb } from 'lucide-react';
import FunnelChart from './FunnelChart';
import InsightCard from './InsightCard';
import RecommendationReview from './RecommendationReview';
import IntegrationsModal from './IntegrationsModal';
import HeapIntegration from './HeapIntegration';
import GoogleAnalyticsIntegration from './Google/GoogleAnalyticsIntegration';

const Dashboard: React.FC = () => {
  const [dropoffs, setDropoffs] = useState<DropoffInsight[]>([]);
  const [funnelSteps, setFunnelSteps] = useState<FunnelStep[]>([]);
  const [selectedDropoff, setSelectedDropoff] = useState<DropoffInsight | null>(null);
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [showIntegrationsModal, setShowIntegrationsModal] = useState(false);
  const [showHeapIntegration, setShowHeapIntegration] = useState(false);
  const [showGoogleAnalyticsIntegration, setShowGoogleAnalyticsIntegration] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('Starting dashboard data load...');
      
      const supabaseAvailable = DatabaseService.isAvailable();
      setIsConnected(supabaseAvailable);

      if (!supabaseAvailable) {
        console.log('Supabase not configured, using demo data.');
      }
      
      const [topDropoffs, allFunnelSteps] = await Promise.all([
        DatabaseService.getTopDropoffInsights(3), // Fetch only top 3
        DatabaseService.getFunnelSteps()
      ]);

      setDropoffs(topDropoffs);
      setFunnelSteps(allFunnelSteps);
      console.log('Dashboard data loaded successfully.');
      
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      setDropoffs([]);
      setFunnelSteps([]);
    } finally {
      setLoading(false);
    }
  };

  const handleRunAIEnhancement = async () => {
    try {
      setLoading(true);
      console.log('🤖 Running AI enhancement on existing data...');
      
      if (DatabaseService.isAvailable()) {
        await AIEnhancedDataService.runCompleteAIEnhancement();
        console.log('✅ AI enhancement completed successfully!');
        await loadData(); // Refresh data after enhancement
      } else {
        console.log('⚠️ AI enhancement not available in demo mode');
        setError('AI enhancement requires Supabase configuration');
      }
    } catch (error) {
      console.error('💥 Failed to run AI enhancement:', error);
      setError('Failed to run AI enhancement: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const handleViewInsight = async (dropoff: DropoffInsight) => {
    console.log('Viewing insight:', dropoff);
    // Fetch detailed recommendations for the selected dropoff
    if (DatabaseService.isAvailable()) {
      const recommendations = await DatabaseService.getRecommendationsForDropoff(dropoff.id);
      setSelectedDropoff({ ...dropoff, recommendations });
    } else {
      setSelectedDropoff(dropoff);
    }
    setShowRecommendations(true);
  };

  const handleCloseRecommendations = () => {
    setShowRecommendations(false);
    setSelectedDropoff(null);
  };

  const handleRecommendationUpdate = async (recommendationId: string, status: 'approved' | 'dismissed' | 'edited', notes?: string) => {
    if (isConnected) {
      try {
        await DatabaseService.updateRecommendationStatus(recommendationId, status, notes);
        // Log user feedback
        await DatabaseService.logUserFeedback({
          recommendation_id: recommendationId,
          feedback_type: status,
          feedback_text: notes || null,
          user_id: 'current_user_id', // Placeholder
          context: { source: 'RecommendationReview' }
        });
        await loadData(); // Refresh data after update
      } catch (error) {
        console.error('Failed to update recommendation:', error);
      }
    }
  };

  const handleWorkflowSync = async (recommendationId: string, platform: 'jira' | 'notion', ticketId?: string, syncDetails?: Record<string, any>) => {
    if (isConnected) {
      try {
        await DatabaseService.createWorkflowSync(recommendationId, platform, ticketId, syncDetails);
        console.log(`Synced to ${platform}`);
        await loadData(); // Refresh data after sync
      } catch (error) {
        console.error('Failed to sync to workflow:', error);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading SmartPM Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">SmartPM Dashboard</h1>
              <p className="text-gray-600">AI-powered insights for your product funnel</p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleRunAIEnhancement}
                disabled={loading}
                className="flex items-center space-x-2 text-green-600 bg-green-50 px-3 py-2 rounded-lg hover:bg-green-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Brain className="h-4 w-4" />
                <span className="text-sm font-medium">
                  {loading ? 'Enhancing...' : 'AI Enhance'}
                </span>
              </button>
              <button
                onClick={() => setShowIntegrationsModal(true)}
                className="flex items-center space-x-2 text-purple-600 bg-purple-50 px-3 py-2 rounded-lg hover:bg-purple-100 transition-colors"
              >
                <Settings className="h-4 w-4" />
                <span className="text-sm font-medium">Integrations</span>
              </button>
              <button
                onClick={loadData}
                className="flex items-center space-x-2 text-gray-600 bg-gray-100 px-3 py-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                <span className="text-sm font-medium">Refresh</span>
              </button>
              {isConnected ? (
                <div className="flex items-center space-x-2 text-green-600 bg-green-50 px-3 py-2 rounded-lg">
                  <Wifi className="h-4 w-4" />
                  <span className="text-sm font-medium">Connected</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2 text-orange-600 bg-orange-50 px-3 py-2 rounded-lg">
                  <WifiOff className="h-4 w-4" />
                  <span className="text-sm font-medium">Demo Mode</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <div className="flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <div>
                <h3 className="text-sm font-medium text-red-900">Error</h3>
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Demo Mode Banner */}
        {!isConnected && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
            <div className="flex items-center space-x-3">
              <WifiOff className="h-5 w-5 text-blue-600" />
              <div>
                <h3 className="text-sm font-medium text-blue-900">Demo Mode</h3>
                <p className="text-sm text-blue-700">
                  You're viewing demo data. Connect to Supabase to see your real analytics data.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Funnel Visualization */}
        <div className="bg-white p-6 rounded-lg shadow-sm border mb-8 hover:shadow-md transition-shadow duration-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Conversion Funnel</h2>
          {funnelSteps.length > 0 ? (
            <FunnelChart data={funnelSteps} />
          ) : (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No funnel data available. Please connect your analytics tool.</p>
              <button 
                onClick={() => setShowIntegrationsModal(true)}
                className="mt-2 text-blue-600 hover:text-blue-800 text-sm"
              >
                Set Up Integrations
              </button>
            </div>
          )}
        </div>

        {/* Top Drop-offs */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Top Drop-offs This Week</h2>
            <div className="flex items-center text-sm text-gray-600">
              <TrendingUp className="h-4 w-4 mr-1" />
              Ranked by impact score
            </div>
          </div>
          
          {dropoffs.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {dropoffs.map((dropoff, index) => (
                <InsightCard
                  key={dropoff.id}
                  dropoff={dropoff}
                  rank={index + 1}
                  onViewInsight={handleViewInsight}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white p-8 rounded-lg shadow-sm border text-center">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No drop-off insights available. Please ensure your analytics tool is connected and data is flowing.</p>
              <button 
                onClick={() => setShowIntegrationsModal(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
              >
                <Settings className="h-4 w-4 inline mr-2" />
                Set Up Integrations
              </button>
            </div>
          )}
        </div>

        {/* Recommendation Review Modal */}
        {showRecommendations && selectedDropoff && (
          <RecommendationReview
            dropoff={selectedDropoff}
            onClose={handleCloseRecommendations}
            onRecommendationUpdate={handleRecommendationUpdate}
            onWorkflowSync={handleWorkflowSync}
            isConnected={isConnected}
          />
        )}

        {/* Integrations Selection Modal */}
        {showIntegrationsModal && (
          <IntegrationsModal
            isOpen={showIntegrationsModal}
            onClose={() => setShowIntegrationsModal(false)}
            onSelectHeap={() => setShowHeapIntegration(true)}
            onSelectGoogleAnalytics={() => setShowGoogleAnalyticsIntegration(true)}
            isConnected={isConnected}
          />
        )}

        {/* Heap Integration Modal */}
        {showHeapIntegration && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-hidden">
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-semibold text-gray-900">Heap Analytics Integration</h2>
                <button
                  onClick={() => setShowHeapIntegration(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
                <HeapIntegration 
                  onDataImported={loadData} // Reload data after import
                  onBack={() => {
                    setShowHeapIntegration(false);
                    setShowIntegrationsModal(true);
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Google Analytics Integration Modal */}
        {showGoogleAnalyticsIntegration && (
          <GoogleAnalyticsIntegration
            isOpen={showGoogleAnalyticsIntegration}
            onClose={() => setShowGoogleAnalyticsIntegration(false)}
            onDataImported={loadData} // Reload data after import
            onBack={() => {
              setShowGoogleAnalyticsIntegration(false);
              setShowIntegrationsModal(true);
            }}
          />
        )}
      </div>
    </div>
  );
};

export default Dashboard;





