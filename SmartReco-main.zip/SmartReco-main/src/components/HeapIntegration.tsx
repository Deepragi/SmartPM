import React, { useState, useEffect } from 'react';
import {
  Database,
  Upload,
  Download,
  Settings,
  CheckCircle,
  AlertCircle,
  XCircle,
  RefreshCw,
  FileText,
  BarChart3,
  Users,
  Activity,
  Wifi,
  WifiOff
} from 'lucide-react';
import { HeapDataWarehouseService, DataWarehouseConfig } from '../lib/heap-integration';
import { CSVImportService, CSVImportResult } from '../lib/csv-import';
import { DataValidationService, DataQualityReport } from '../lib/data-validation';

interface HeapIntegrationProps {
  onDataImported: (data: any) => void;
  onDataImportedAndShowSummary: (data: any, report: DataQualityReport) => void;
  onBack?: () => void;
}

type DataSource = 'warehouse' | 'csv';
type DataType = 'events' | 'users' | 'sessions';

const HeapIntegration: React.FC<HeapIntegrationProps> = ({ onDataImported, onDataImportedAndShowSummary, onBack }) => {
  const [activeTab, setActiveTab] = useState<'config' | 'import'>('import'); // Default to import tab
  const [dataSource, setDataSource] = useState<DataSource>('warehouse');
  const [dataType, setDataType] = useState<DataType>('events');
  
  // Warehouse configuration
  const [warehouseConfig, setWarehouseConfig] = useState<DataWarehouseConfig>({
    type: 'bigquery',
    projectId: '',
    dataset: '',
    credentials: {}
  });
  const [warehouseConnected, setWarehouseConnected] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);
  
  // CSV import
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvImportResult, setCsvImportResult] = useState<CSVImportResult | null>(null);
  const [importing, setImporting] = useState(false);
  
  // Data quality
  const [qualityReport, setQualityReport] = useState<DataQualityReport | null>(null);
  const [loadingQuality, setLoadingQuality] = useState(false);
  
  // General state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Test warehouse connection
  const testWarehouseConnection = async () => {
    setTestingConnection(true);
    setError(null);
    
    try {
      const service = new HeapDataWarehouseService(warehouseConfig);
      const isConnected = await service.testConnection();
      
      if (isConnected) {
        setWarehouseConnected(true);
        setSuccess('Successfully connected to data warehouse!');
      } else {
        setWarehouseConnected(false);
        setError('Failed to connect to data warehouse. Please check your configuration.');
      }
    } catch (err) {
      setWarehouseConnected(false);
      setError(`Connection failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setTestingConnection(false);
    }
  };

  // Import data from warehouse
  const importFromWarehouse = async () => {
    if (!warehouseConnected) {
      setError('Please connect to the data warehouse first.');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const service = new HeapDataWarehouseService(warehouseConfig);
      let data: any[] = [];
      
      switch (dataType) {
        case 'events':
          data = await service.pullEventData(1000);
          break;
        case 'users':
          data = await service.pullUserData(1000);
          break;
        case 'sessions':
          data = await service.pullSessionData(1000);
          break;
      }
      
      // Validate the imported data
      const report = DataValidationService.generateDataQualityReport(data, [], []); // Assuming data is events for now
      setQualityReport(report);

      setSuccess(`Successfully imported ${data.length} ${dataType} records from data warehouse!`);
      onDataImported?.(data);
      
      // Call the summary callback
      if (onDataImportedAndShowSummary) {
        console.log('Calling onDataImportedAndShowSummary from warehouse import');
        onDataImportedAndShowSummary(data, report);
      }
      
    } catch (err) {
      setError(`Import failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle CSV file selection
  const handleCsvFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCsvFile(file);
      setCsvImportResult(null);
    }
  };

  // Import data from CSV
  const importFromCSV = async () => {
    if (!csvFile) {
      setError('Please select a CSV file first.');
      return;
    }

    setImporting(true);
    setError(null);
    
    try {
      const csvContent = await csvFile.text();
      let result: CSVImportResult;
      
      switch (dataType) {
        case 'events':
          result = CSVImportService.importEventsFromCSV(csvContent);
          break;
        case 'users':
          result = CSVImportService.importUsersFromCSV(csvContent);
          break;
        case 'sessions':
          result = CSVImportService.importSessionsFromCSV(csvContent);
          break;
      }
      
      setCsvImportResult(result);
      
      if (result.success) {
        // Validate the imported data
        const report = DataValidationService.generateDataQualityReport(result.data, [], []); // Assuming data is events for now
        setQualityReport(report);

        setSuccess(`Successfully imported ${result.summary.validRows} ${dataType} records from CSV!`);
        onDataImported?.(result.data);
        
        // Call the summary callback
        if (onDataImportedAndShowSummary) {
          console.log('Calling onDataImportedAndShowSummary from CSV import');
          onDataImportedAndShowSummary(result.data, report);
        }
      } else {
        setError(`CSV import failed: ${result.errors.join(', ')}`);
      }
      
    } catch (err) {
      setError(`CSV import failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setImporting(false);
    }
  };

  // Download CSV template
  const downloadTemplate = () => {
    let template = '';
    let filename = '';
    
    switch (dataType) {
      case 'events':
        template = CSVImportService.generateEventCSVTemplate();
        filename = 'heap_events_template.csv';
        break;
      case 'users':
        template = CSVImportService.generateUserCSVTemplate();
        filename = 'heap_users_template.csv';
        break;
      case 'sessions':
        template = CSVImportService.generateSessionCSVTemplate();
        filename = 'heap_sessions_template.csv';
        break;
    }
    
    const blob = new Blob([template], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Clear messages after 5 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError(null);
        setSuccess(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  return (
    <div className="bg-white rounded-lg shadow-sm border">
      {/* Header */}
      <div className="border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {onBack && (
              <button
                onClick={onBack}
                className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
              >
                <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back
              </button>
            )}
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Heap Analytics Integration</h2>
              <p className="text-sm text-gray-600 mt-1">
                Configure data sources and import analytics data
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {warehouseConnected ? (
              <div className="flex items-center text-green-600 bg-green-50 px-3 py-1 rounded-full text-sm">
                <Wifi className="h-4 w-4 mr-1" />
                Connected
              </div>
            ) : (
              <div className="flex items-center text-gray-500 bg-gray-50 px-3 py-1 rounded-full text-sm">
                <WifiOff className="h-4 w-4 mr-1" />
                Disconnected
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8 px-6">
          {[
            { id: 'config', label: 'Configuration', icon: Settings },
            { id: 'import', label: 'Data Import', icon: Upload },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm ${
                activeTab === id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Messages */}
      {error && (
        <div className="mx-6 mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <div className="flex items-center">
            <XCircle className="h-5 w-5 text-red-400 mr-2" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        </div>
      )}

      {success && (
        <div className="mx-6 mt-4 p-4 bg-green-50 border border-green-200 rounded-md">
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
            <p className="text-sm text-green-700">{success}</p>
          </div>
        </div>
      )}

      {/* Tab Content */}
      <div className="p-6">
        {activeTab === 'config' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Data Warehouse Configuration</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Warehouse Type
                  </label>
                  <select
                    value={warehouseConfig.type}
                    onChange={(e) => setWarehouseConfig(prev => ({
                      ...prev,
                      type: e.target.value as any
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="bigquery">Google BigQuery</option>
                    <option value="snowflake">Snowflake</option>
                    <option value="redshift">Amazon Redshift</option>
                    <option value="s3">Amazon S3</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Project ID / Database
                  </label>
                  <input
                    type="text"
                    value={warehouseConfig.projectId || ''}
                    onChange={(e) => setWarehouseConfig(prev => ({
                      ...prev,
                      projectId: e.target.value
                    }))}
                    placeholder="your-project-id"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Dataset / Schema
                  </label>
                  <input
                    type="text"
                    value={warehouseConfig.dataset || ''}
                    onChange={(e) => setWarehouseConfig(prev => ({
                      ...prev,
                      dataset: e.target.value
                    }))}
                    placeholder="heap_data"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Connection String (Optional)
                  </label>
                  <input
                    type="text"
                    value={warehouseConfig.connectionString || ''}
                    onChange={(e) => setWarehouseConfig(prev => ({
                      ...prev,
                      connectionString: e.target.value
                    }))}
                    placeholder="Connection string or endpoint"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="mt-4">
                <button
                  onClick={testWarehouseConnection}
                  disabled={testingConnection}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {testingConnection ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <Database className="h-4 w-4" />
                  )}
                  <span>{testingConnection ? 'Testing...' : 'Test Connection'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'import' && (
          <div className="space-y-6">
            {/* Data Source Selection */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Data Source</h3>
              <div className="flex space-x-4">
                <button
                  onClick={() => setDataSource('warehouse')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md border ${
                    dataSource === 'warehouse'
                      ? 'bg-blue-50 border-blue-200 text-blue-700'
                      : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Database className="h-4 w-4" />
                  <span>Data Warehouse</span>
                </button>
                <button
                  onClick={() => setDataSource('csv')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md border ${
                    dataSource === 'csv'
                      ? 'bg-blue-50 border-blue-200 text-blue-700'
                      : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <FileText className="h-4 w-4" />
                  <span>CSV Upload</span>
                </button>
              </div>
            </div>

            {/* Data Type Selection */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Data Type</h3>
              <div className="flex space-x-4">
                {[
                  { id: 'events', label: 'Events', icon: Activity },
                  { id: 'users', label: 'Users', icon: Users },
                  { id: 'sessions', label: 'Sessions', icon: BarChart3 }
                ].map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => setDataType(id as DataType)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-md border ${
                      dataType === id
                        ? 'bg-blue-50 border-blue-200 text-blue-700'
                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Import Interface */}
            {dataSource === 'warehouse' ? (
              <div className="bg-gray-50 p-4 rounded-md">
                <h4 className="font-medium text-gray-900 mb-2">Import from Data Warehouse</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Import {dataType} data from your configured data warehouse.
                </p>
                <button
                  onClick={importFromWarehouse}
                  disabled={loading || !warehouseConnected}
                  className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50"
                >
                  {loading ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <Download className="h-4 w-4" />
                  )}
                  <span>{loading ? 'Importing...' : `Import ${dataType}`}</span>
                </button>
              </div>
            ) : (
              <div className="bg-gray-50 p-4 rounded-md">
                <h4 className="font-medium text-gray-900 mb-2">Upload CSV File</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Upload a CSV file containing {dataType} data.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <input
                      type="file"
                      accept=".csv"
                      onChange={handleCsvFileChange}
                      className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={importFromCSV}
                      disabled={importing || !csvFile}
                      className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50"
                    >
                      {importing ? (
                        <RefreshCw className="h-4 w-4 animate-spin" />
                      ) : (
                        <Upload className="h-4 w-4" />
                      )}
                      <span>{importing ? 'Importing...' : 'Import CSV'}</span>
                    </button>
                    
                    <button
                      onClick={downloadTemplate}
                      className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download Template</span>
                    </button>
                  </div>
                </div>

                {/* CSV Import Results */}
                {csvImportResult && (
                  <div className="mt-4 p-4 bg-white border rounded-md">
                    <h5 className="font-medium text-gray-900 mb-2">Import Results</h5>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Total Rows:</span>
                        <span className="ml-2 font-medium">{csvImportResult.summary.totalRows}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Valid:</span>
                        <span className="ml-2 font-medium text-green-600">{csvImportResult.summary.validRows}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Invalid:</span>
                        <span className="ml-2 font-medium text-red-600">{csvImportResult.summary.invalidRows}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Skipped:</span>
                        <span className="ml-2 font-medium text-gray-600">{csvImportResult.summary.skippedRows}</span>
                      </div>
                    </div>
                    
                    {csvImportResult.errors.length > 0 && (
                      <div className="mt-3">
                        <h6 className="text-sm font-medium text-red-700 mb-1">Errors:</h6>
                        <ul className="text-sm text-red-600 space-y-1">
                          {csvImportResult.errors.slice(0, 5).map((error, index) => (
                            <li key={index}>• {error}</li>
                          ))}
                          {csvImportResult.errors.length > 5 && (
                            <li>• ... and {csvImportResult.errors.length - 5} more errors</li>
                          )}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default HeapIntegration;