import React, { useState, useEffect } from 'react';
import { X, Lightbulb, CheckCircle, Plus, Edit, Trash2, Loader2, AlertCircle } from 'lucide-react';
import { DatabaseService } from '../lib/supabase';
import { AIModelingService } from '../lib/ai-modeling';
import { FunnelStep } from '../lib/database.types';

interface FunnelSuggestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isConnected: boolean;
}

interface SuggestedFunnel {
  id: string;
  name: string;
  steps: string[];
  source: string; // e.g., 'AI', 'User'
  status: 'suggested' | 'approved' | 'rejected';
}

const FunnelSuggestionsModal: React.FC<FunnelSuggestionsModalProps> = ({
  isOpen,
  onClose,
  isConnected,
}) => {
  const [suggestedFunnels, setSuggestedFunnels] = useState<SuggestedFunnel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [newFunnelName, setNewFunnelName] = useState('');
  const [newFunnelSteps, setNewFunnelSteps] = useState('');
  const [editingFunnelId, setEditingFunnelId] = useState<string | null>(null);
  const [editedFunnelName, setEditedFunnelName] = useState('');
  const [editedFunnelSteps, setEditedFunnelSteps] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (!isConnected) {
        setError('Connect to Supabase to enable AI Funnel Suggestions.');
      } else {
        handleGenerateSuggestions(); // Automatically generate suggestions when modal opens
      }
    }
  }, [isOpen, isConnected]);

  const handleGenerateSuggestions = async () => {
    if (!isConnected) {
      setError('Supabase not connected. Cannot generate AI suggestions.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const allEvents = await DatabaseService.getAllEvents();
      const aiSuggestions = await AIModelingService.suggestFunnelsFromEvents(allEvents);

      const newSuggestions: SuggestedFunnel[] = aiSuggestions.map((s, index) => ({
        id: `ai-funnel-${Date.now()}-${index}`,
        name: s.name,
        steps: s.steps,
        source: 'AI',
        status: 'suggested',
      }));
      setSuggestedFunnels((prev) => [...prev, ...newSuggestions]);
    } catch (err) {
      console.error('Failed to generate AI funnel suggestions:', err);
      setError('Failed to generate AI funnel suggestions: ' + (err instanceof Error ? err.message : 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const handleApproveFunnel = async (funnelId: string) => {
    setSuggestedFunnels((prev) =>
      prev.map((f) => (f.id === funnelId ? { ...f, status: 'approved' } : f))
    );
    const approvedFunnel = suggestedFunnels.find(f => f.id === funnelId);
    if (approvedFunnel && isConnected) {
      try {
        await DatabaseService.addFunnel({
          funnel_id: approvedFunnel.id,
          funnel_name: approvedFunnel.name,
          steps: approvedFunnel.steps,
        });
        console.log(`Funnel ${approvedFunnel.name} approved and added.`);
      } catch (err) {
        console.error('Failed to add approved funnel to DB:', err);
        setError('Failed to add approved funnel: ' + (err instanceof Error ? err.message : 'Unknown error'));
      }
    }
  };

  const handleRejectFunnel = (funnelId: string) => {
    setSuggestedFunnels((prev) =>
      prev.map((f) => (f.id === funnelId ? { ...f, status: 'rejected' } : f))
    );
  };

  const handleEditFunnel = (funnel: SuggestedFunnel) => {
    setEditingFunnelId(funnel.id);
    setEditedFunnelName(funnel.name);
    setEditedFunnelSteps(funnel.steps.join(', '));
  };

  const handleSaveEditedFunnel = async (funnelId: string) => {
    if (!editedFunnelName || !editedFunnelSteps) {
      setError('Funnel name and steps cannot be empty.');
      return;
    }
    const stepsArray = editedFunnelSteps.split(',').map(s => s.trim()).filter(s => s);
    if (stepsArray.length < 2) {
      setError('A funnel must have at least two steps.');
      return;
    }

    setSuggestedFunnels((prev) =>
      prev.map((f) =>
        f.id === funnelId
          ? { ...f, name: editedFunnelName, steps: stepsArray, status: 'approved' } // Mark as approved after editing
          : f
      )
    );
    setEditingFunnelId(null);
    setEditedFunnelName('');
    setEditedFunnelSteps('');
    setError(null);

    if (isConnected) {
      try {
        await DatabaseService.updateFunnel({
          funnel_id: funnelId,
          funnel_name: editedFunnelName,
          steps: stepsArray,
        });
        console.log(`Funnel ${editedFunnelName} updated.`);
      } catch (err) {
        console.error('Failed to update funnel in DB:', err);
        setError('Failed to update funnel: ' + (err instanceof Error ? err.message : 'Unknown error'));
      }
    }
  };

  const handleCancelEdit = () => {
    setEditingFunnelId(null);
    setEditedFunnelName('');
    setEditedFunnelSteps('');
    setError(null);
  };

  const handleAddCustomFunnel = async () => {
    if (!newFunnelName || !newFunnelSteps) {
      setError('Funnel name and steps cannot be empty.');
      return;
    }
    const stepsArray = newFunnelSteps.split(',').map(s => s.trim()).filter(s => s);
    if (stepsArray.length < 2) {
      setError('A funnel must have at least two steps.');
      return;
    }

    const customFunnel: SuggestedFunnel = {
      id: `custom-funnel-${Date.now()}`,
      name: newFunnelName,
      steps: stepsArray,
      source: 'User',
      status: 'approved',
    };

    setSuggestedFunnels((prev) => [...prev, customFunnel]);
    setNewFunnelName('');
    setNewFunnelSteps('');
    setError(null);

    if (isConnected) {
      try {
        await DatabaseService.addFunnel({
          funnel_id: customFunnel.id,
          funnel_name: customFunnel.name,
          steps: customFunnel.steps,
        });
        console.log(`Custom funnel ${customFunnel.name} added.`);
      } catch (err) {
        console.error('Failed to add custom funnel to DB:', err);
        setError('Failed to add custom funnel: ' + (err instanceof Error ? err.message : 'Unknown error'));
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-600 to-orange-600 text-white p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white bg-opacity-20 rounded-lg p-2">
              <Lightbulb className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">AI Funnel Suggestions</h2>
              <p className="text-yellow-100">Discover and manage potential conversion funnels</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-yellow-200 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 flex-grow overflow-y-auto">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {!isConnected && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-blue-600" />
              <p className="text-sm text-blue-700">Connect to Supabase to enable AI Funnel Suggestions and manage funnels.</p>
            </div>
          )}

          {/* Generate Suggestions Section - Removed as it's now automatic on open */}

          {/* Add Custom Funnel Section */}
          <div className="mb-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Custom Funnel</h3>
            <div className="space-y-4">
              <div>
                <label htmlFor="funnelName" className="block text-sm font-medium text-gray-700">Funnel Name</label>
                <input
                  type="text"
                  id="funnelName"
                  value={newFunnelName}
                  onChange={(e) => setNewFunnelName(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="e.g., User Onboarding Funnel"
                  disabled={!isConnected}
                />
              </div>
              <div>
                <label htmlFor="funnelSteps" className="block text-sm font-medium text-gray-700">Funnel Steps (comma-separated event names)</label>
                <input
                  type="text"
                  id="funnelSteps"
                  value={newFunnelSteps}
                  onChange={(e) => setNewFunnelSteps(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-yellow-500 focus:border-yellow-500"
                  placeholder="e.g., Signup, Profile Created, First Purchase"
                  disabled={!isConnected}
                />
              </div>
              <button
                onClick={handleAddCustomFunnel}
                disabled={!isConnected || !newFunnelName || !newFunnelSteps}
                className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plus className="h-5 w-5" />
                <span>Add Funnel</span>
              </button>
            </div>
          </div>

          {/* Suggested Funnels List */}
          <div className="">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Suggested & Custom Funnels ({suggestedFunnels.length})</h3>
            {suggestedFunnels.length === 0 && !loading && (
              <p className="text-gray-500">No funnels suggested or added yet. Generate some or add your own!</p>
            )}
            <div className="space-y-4">
              {suggestedFunnels.map((funnel) => (
                <div key={funnel.id} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                  {editingFunnelId === funnel.id ? (
                    <div className="space-y-3">
                      <div>
                        <label htmlFor={`edit-name-${funnel.id}`} className="block text-sm font-medium text-gray-700">Funnel Name</label>
                        <input
                          type="text"
                          id={`edit-name-${funnel.id}`}
                          value={editedFunnelName}
                          onChange={(e) => setEditedFunnelName(e.target.value)}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-yellow-500 focus:border-yellow-500"
                        />
                      </div>
                      <div>
                        <label htmlFor={`edit-steps-${funnel.id}`} className="block text-sm font-medium text-gray-700">Funnel Steps (comma-separated)</label>
                        <input
                          type="text"
                          id={`edit-steps-${funnel.id}`}
                          value={editedFunnelSteps}
                          onChange={(e) => setEditedFunnelSteps(e.target.value)}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-yellow-500 focus:border-yellow-500"
                        />
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleSaveEditedFunnel(funnel.id)}
                          className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors"
                        >
                          Save
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="bg-gray-300 text-gray-800 py-2 px-4 rounded-lg font-medium hover:bg-gray-400 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-gray-900">{funnel.name} <span className="text-xs text-gray-500">({funnel.source})</span></h4>
                        <p className="text-sm text-gray-600">Steps: {funnel.steps.join(' → ')}</p>
                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${funnel.status === 'approved' ? 'bg-green-100 text-green-800' : funnel.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                          {funnel.status.charAt(0).toUpperCase() + funnel.status.slice(1)}
                        </span>
                      </div>
                      <div className="flex space-x-2">
                        {funnel.status === 'suggested' && isConnected && (
                          <>
                            <button
                              onClick={() => handleApproveFunnel(funnel.id)}
                              className="p-2 rounded-full bg-green-100 text-green-600 hover:bg-green-200 transition-colors"
                              title="Approve Funnel"
                            >
                              <CheckCircle className="h-5 w-5" />
                            </button>
                            <button
                              onClick={() => handleRejectFunnel(funnel.id)}
                              className="p-2 rounded-full bg-red-100 text-red-600 hover:bg-red-200 transition-colors"
                              title="Reject Funnel"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </>
                        )}
                        {funnel.status === 'approved' && isConnected && (
                          <button
                            onClick={() => handleEditFunnel(funnel)}
                            className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
                            title="Edit Funnel"
                          >
                            <Edit className="h-5 w-5" />
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FunnelSuggestionsModal;


