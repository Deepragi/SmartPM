import React from 'react';
import { DropoffInsight } from '../lib/database.types';
import { TrendingDown, Users, Eye, AlertTriangle, Brain } from 'lucide-react';

interface InsightCardProps {
  dropoff: DropoffInsight;
  rank: number;
  onViewInsight: (dropoff: DropoffInsight) => void;
}

const InsightCard: React.FC<InsightCardProps> = ({ dropoff, rank, onViewInsight }) => {
  const getImpactColor = (score: number) => {
    if (score > 0.8) return 'text-red-600 bg-red-50';
    if (score > 0.6) return 'text-orange-600 bg-orange-50';
    return 'text-yellow-600 bg-yellow-50';
  };

  const getImpactLabel = (score: number) => {
    if (score > 0.8) return 'High Impact';
    if (score > 0.6) return 'Medium Impact';
    return 'Low Impact';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-600">
            #{rank}
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-medium ${getImpactColor(dropoff.impact_score)}`}>
            {getImpactLabel(dropoff.impact_score)}
          </div>
        </div>
        <TrendingDown className="h-5 w-5 text-red-500" />
      </div>

      <div className="mb-4">
        <h3 className="font-semibold text-gray-900 mb-2">
          {dropoff.step_from} → {dropoff.step_to}
        </h3>
        <p className="text-sm text-gray-600 line-clamp-3">
          {dropoff.hypothesis}
        </p>
      </div>

      {dropoff.ai_explanation && (
        <div className="mb-4 p-3 bg-blue-50 rounded-md border border-blue-200">
          <div className="flex items-center text-blue-800 mb-2">
            <Brain className="h-4 w-4 mr-2" />
            <span className="text-sm font-semibold">AI Hypothesis:</span>
          </div>
          <p className="text-xs text-blue-700 line-clamp-3">
            {dropoff.ai_explanation.hypothesis_text}
          </p>
        </div>
      )}

      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Drop Rate</span>
          <span className="text-sm font-semibold text-red-600">
            {(dropoff.drop_rate * 100).toFixed(1)}%
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Affected Users</span>
          <div className="flex items-center space-x-1">
            <Users className="h-4 w-4 text-gray-400" />
            <span className="text-sm font-semibold text-gray-900">
              {dropoff.affected_users.toLocaleString()}
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Recommendations</span>
          <div className="flex items-center space-x-1">
            <AlertTriangle className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-semibold text-orange-600">
              {dropoff.recommendations.length}
            </span>
          </div>
        </div>
      </div>

      <button
        onClick={() => onViewInsight(dropoff)}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2"
      >
        <Eye className="h-4 w-4" />
        <span>View Insights</span>
      </button>
    </div>
  );
};

export default InsightCard;

