import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, TrendingDown, AlertTriangle, Users, Target, Zap, ChevronRight, RefreshCw, Eye, CheckCircle, XCircle } from 'lucide-react';
import { aiModelingService } from '../lib/ai-modeling';
import { supabase } from '../lib/supabase';

interface AIInsight {
  id: string;
  insight_type: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  affected_users: number;
  potential_impact: number;
  recommended_actions: string[];
  status: 'new' | 'acknowledged' | 'in_progress' | 'completed' | 'dismissed';
  created_at: string;
}

interface ChurnPrediction {
  user_id: string;
  churn_probability: number;
  risk_level: 'low' | 'medium' | 'high';
  key_factors: string[];
  recommended_actions: string[];
}

interface ConversionPrediction {
  user_id: string;
  conversion_probability: number;
  predicted_action: string;
  time_to_conversion: number;
}

interface AnomalyDetection {
  id: string;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  affected_metric: string;
  detected_at: string;
  deviation: number;
  recommended_actions: string[];
}

interface UserSegment {
  id: string;
  name: string;
  description: string;
  user_count: number;
  avg_engagement: number;
  conversion_rate: number;
}

const AIInsights: React.FC = () => {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [churnPredictions, setChurnPredictions] = useState<ChurnPrediction[]>([]);
  const [conversionPredictions, setConversionPredictions] = useState<ConversionPrediction[]>([]);
  const [anomalies, setAnomalies] = useState<AnomalyDetection[]>([]);
  const [userSegments, setUserSegments] = useState<UserSegment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'churn' | 'conversion' | 'anomalies' | 'segments'>('overview');
  const [isRunningAnalysis, setIsRunningAnalysis] = useState(false);

  useEffect(() => {
    loadAIInsights();
  }, []);

  const loadAIInsights = async () => {
    try {
      setLoading(true);
      
      // Load AI insights summary
      const { data: insightsData } = await supabase
        .from('ai_insights_summary')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (insightsData) {
        setInsights(insightsData);
      }

      // Load churn predictions
      const { data: churnData } = await supabase
        .from('high_churn_risk_users')
        .select('*')
        .limit(20);
      
      if (churnData) {
        setChurnPredictions(churnData);
      }

      // Load conversion predictions
      const { data: conversionData } = await supabase
        .from('high_conversion_potential_users')
        .select('*')
        .limit(20);
      
      if (conversionData) {
        setConversionPredictions(conversionData);
      }

      // Load anomalies
      const { data: anomaliesData } = await supabase
        .from('active_anomalies')
        .select('*')
        .limit(10);
      
      if (anomaliesData) {
        setAnomalies(anomaliesData);
      }

      // Load user segments
      const { data: segmentsData } = await supabase
        .from('user_segments')
        .select('*')
        .order('user_count', { ascending: false });
      
      if (segmentsData) {
        setUserSegments(segmentsData);
      }

    } catch (error) {
      console.error('Error loading AI insights:', error);
    } finally {
      setLoading(false);
    }
  };

  const runAIAnalysis = async () => {
    try {
      setIsRunningAnalysis(true);
      
      // Simulate running AI analysis on imported data
      // In a real implementation, this would trigger the AI models
      await aiModelingService.updateModelPredictions();
      
      // Reload insights after analysis
      await loadAIInsights();
      
    } catch (error) {
      console.error('Error running AI analysis:', error);
    } finally {
      setIsRunningAnalysis(false);
    }
  };

  const updateInsightStatus = async (insightId: string, status: string) => {
    try {
      await supabase
        .from('ai_insights_summary')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', insightId);
      
      await loadAIInsights();
    } catch (error) {
      console.error('Error updating insight status:', error);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-50';
      case 'high': return 'text-orange-600 bg-orange-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-blue-600 bg-blue-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
        <span className="ml-2 text-gray-600">Loading AI insights...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Brain className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">AI Insights</h2>
            <p className="text-gray-600">AI-powered analytics and predictions</p>
          </div>
        </div>
        <button
          onClick={runAIAnalysis}
          disabled={isRunningAnalysis}
          className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <RefreshCw className={`h-4 w-4 ${isRunningAnalysis ? 'animate-spin' : ''}`} />
          <span>{isRunningAnalysis ? 'Running Analysis...' : 'Run AI Analysis'}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'overview', name: 'Overview', icon: Eye },
            { id: 'churn', name: 'Churn Risk', icon: TrendingDown },
            { id: 'conversion', name: 'Conversions', icon: Target },
            { id: 'anomalies', name: 'Anomalies', icon: AlertTriangle },
            { id: 'segments', name: 'Segments', icon: Users }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-purple-500 text-purple-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.name}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Insights Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">High Churn Risk</p>
                  <p className="text-2xl font-bold text-red-600">{churnPredictions.filter(p => p.risk_level === 'high').length}</p>
                </div>
                <TrendingDown className="h-8 w-8 text-red-600" />
              </div>
              <p className="text-xs text-gray-500 mt-2">Users likely to churn in 30 days</p>
            </div>

            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Conversion Opportunities</p>
                  <p className="text-2xl font-bold text-green-600">{conversionPredictions.length}</p>
                </div>
                <Target className="h-8 w-8 text-green-600" />
              </div>
              <p className="text-xs text-gray-500 mt-2">High-potential conversion candidates</p>
            </div>

            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Anomalies</p>
                  <p className="text-2xl font-bold text-orange-600">{anomalies.length}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-orange-600" />
              </div>
              <p className="text-xs text-gray-500 mt-2">Detected anomalies requiring attention</p>
            </div>
          </div>

          {/* Recent Insights */}
          <div className="bg-white rounded-lg border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Recent AI Insights</h3>
            </div>
            <div className="divide-y divide-gray-200">
              {insights.slice(0, 5).map((insight) => (
                <div key={insight.id} className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getPriorityColor(insight.priority)}`}>
                          {insight.priority.toUpperCase()}
                        </span>
                        <span className="text-sm text-gray-500">{insight.insight_type.replace('_', ' ')}</span>
                      </div>
                      <h4 className="text-lg font-medium text-gray-900 mb-1">{insight.title}</h4>
                      <p className="text-gray-600 mb-3">{insight.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>👥 {insight.affected_users} users</span>
                        <span>💰 ${insight.potential_impact.toLocaleString()} impact</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={() => updateInsightStatus(insight.id, 'acknowledged')}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-lg"
                        title="Acknowledge"
                      >
                        <CheckCircle className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => updateInsightStatus(insight.id, 'dismissed')}
                        className="p-2 text-gray-400 hover:bg-gray-50 rounded-lg"
                        title="Dismiss"
                      >
                        <XCircle className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Churn Risk Tab */}
      {activeTab === 'churn' && (
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Churn Risk Predictions</h3>
            <p className="text-gray-600">Users at risk of churning in the next 30 days</p>
          </div>
          <div className="divide-y divide-gray-200">
            {churnPredictions.map((prediction, index) => (
              <div key={prediction.user_id} className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <span className="font-medium text-gray-900">User {prediction.user_id}</span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getRiskColor(prediction.risk_level)}`}>
                      {prediction.risk_level.toUpperCase()} RISK
                    </span>
                  </div>
                  <span className="text-lg font-bold text-red-600">
                    {(prediction.churn_probability * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Key Risk Factors</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {prediction.key_factors.map((factor, i) => (
                        <li key={i} className="flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span>
                          <span>{factor}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Recommended Actions</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {prediction.recommended_actions.map((action, i) => (
                        <li key={i} className="flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                          <span>{action}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Conversion Opportunities Tab */}
      {activeTab === 'conversion' && (
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Conversion Opportunities</h3>
            <p className="text-gray-600">Users with high conversion potential</p>
          </div>
          <div className="divide-y divide-gray-200">
            {conversionPredictions.map((prediction, index) => (
              <div key={prediction.user_id} className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <span className="font-medium text-gray-900">User {prediction.user_id}</span>
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-50 text-green-600">
                      {prediction.predicted_action}
                    </span>
                  </div>
                  <span className="text-lg font-bold text-green-600">
                    {(prediction.conversion_probability * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex items-center space-x-6 text-sm text-gray-600">
                  <span>⏱️ {prediction.time_to_conversion} days to conversion</span>
                  <span>🎯 High conversion probability</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Anomalies Tab */}
      {activeTab === 'anomalies' && (
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Detected Anomalies</h3>
            <p className="text-gray-600">Unusual patterns and outliers in your data</p>
          </div>
          <div className="divide-y divide-gray-200">
            {anomalies.map((anomaly) => (
              <div key={anomaly.id} className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(anomaly.severity)}`}>
                        {anomaly.severity.toUpperCase()}
                      </span>
                      <span className="text-sm text-gray-500">{anomaly.type.replace('_', ' ')}</span>
                    </div>
                    <h4 className="text-lg font-medium text-gray-900 mb-1">{anomaly.description}</h4>
                    <p className="text-sm text-gray-600 mb-2">
                      Metric: {anomaly.affected_metric} | Deviation: {(anomaly.deviation * 100).toFixed(1)}%
                    </p>
                  </div>
                  <span className="text-sm text-gray-500">
                    {new Date(anomaly.detected_at).toLocaleDateString()}
                  </span>
                </div>
                <div>
                  <h5 className="text-sm font-medium text-gray-700 mb-1">Recommended Actions</h5>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {anomaly.recommended_actions.map((action, i) => (
                      <li key={i} className="flex items-center space-x-2">
                        <ChevronRight className="h-3 w-3" />
                        <span>{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* User Segments Tab */}
      {activeTab === 'segments' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {userSegments.map((segment) => (
            <div key={segment.id} className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{segment.name}</h3>
                <Users className="h-5 w-5 text-gray-400" />
              </div>
              <p className="text-gray-600 mb-4">{segment.description}</p>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Users</span>
                  <span className="text-sm font-medium">{segment.user_count.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Avg Engagement</span>
                  <span className="text-sm font-medium">{segment.avg_engagement.toFixed(1)}/10</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Conversion Rate</span>
                  <span className="text-sm font-medium">{(segment.conversion_rate * 100).toFixed(1)}%</span>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full" 
                    style={{ width: `${segment.avg_engagement * 10}%` }}
                  ></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">Engagement Score</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AIInsights;

