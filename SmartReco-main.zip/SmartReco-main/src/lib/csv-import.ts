import { HeapEvent, HeapUser, HeapSession, DataValidationResult } from './heap-integration';

export interface CSVImportResult {
  success: boolean;
  data: any[];
  errors: string[];
  warnings: string[];
  summary: {
    totalRows: number;
    validRows: number;
    invalidRows: number;
    skippedRows: number;
  };
}

export interface CSVColumn {
  name: string;
  required: boolean;
  type: 'string' | 'number' | 'date' | 'boolean' | 'json';
  validator?: (value: any) => boolean;
}

export class CSVImportService {
  // Expected CSV schemas for different data types
  private static readonly EVENT_SCHEMA: CSVColumn[] = [
    { name: 'event_id', required: true, type: 'string' },
    { name: 'user_id', required: true, type: 'string' },
    { name: 'session_id', required: true, type: 'string' },
    { name: 'time', required: true, type: 'date' },
    { name: 'event_name', required: true, type: 'string' },
    { name: 'event_properties', required: false, type: 'json' },
    { name: 'user_properties', required: false, type: 'json' },
    { name: 'session_properties', required: false, type: 'json' }
  ];

  private static readonly USER_SCHEMA: CSVColumn[] = [
    { name: 'user_id', required: true, type: 'string' },
    { name: 'identity', required: false, type: 'string' },
    { name: 'handle', required: false, type: 'string' },
    { name: 'email', required: false, type: 'string' },
    { name: 'joindate', required: true, type: 'date' },
    { name: 'last_modified', required: false, type: 'date' }
  ];

  private static readonly SESSION_SCHEMA: CSVColumn[] = [
    { name: 'event_id', required: true, type: 'string' },
    { name: 'user_id', required: true, type: 'string' },
    { name: 'session_id', required: true, type: 'string' },
    { name: 'time', required: true, type: 'date' },
    { name: 'library', required: false, type: 'string' },
    { name: 'platform', required: false, type: 'string' },
    { name: 'device_type', required: false, type: 'string' },
    { name: 'country', required: false, type: 'string' },
    { name: 'region', required: false, type: 'string' },
    { name: 'city', required: false, type: 'string' },
    { name: 'browser', required: false, type: 'string' },
    { name: 'utm_source', required: false, type: 'string' },
    { name: 'utm_campaign', required: false, type: 'string' },
    { name: 'utm_medium', required: false, type: 'string' }
  ];

  // Parse CSV file content
  static parseCSV(csvContent: string): string[][] {
    const lines = csvContent.split('\n');
    const result: string[][] = [];
    
    for (const line of lines) {
      if (line.trim() === '') continue;
      
      // Simple CSV parsing (handles basic cases)
      // In production, you might want to use a more robust CSV parser
      const row = this.parseCSVLine(line);
      result.push(row);
    }
    
    return result;
  }

  // Parse a single CSV line (handles quoted fields)
  private static parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  }

  // Import events from CSV
  static importEventsFromCSV(csvContent: string): CSVImportResult {
    try {
      const rows = this.parseCSV(csvContent);
      if (rows.length === 0) {
        return {
          success: false,
          data: [],
          errors: ['CSV file is empty'],
          warnings: [],
          summary: { totalRows: 0, validRows: 0, invalidRows: 0, skippedRows: 0 }
        };
      }

      const headers = rows[0].map(h => h.toLowerCase().trim());
      const dataRows = rows.slice(1);
      
      // Validate headers
      const headerValidation = this.validateHeaders(headers, this.EVENT_SCHEMA);
      if (!headerValidation.isValid) {
        return {
          success: false,
          data: [],
          errors: headerValidation.errors,
          warnings: headerValidation.warnings,
          summary: { totalRows: dataRows.length, validRows: 0, invalidRows: dataRows.length, skippedRows: 0 }
        };
      }

      // Process data rows
      const events: HeapEvent[] = [];
      const errors: string[] = [];
      const warnings: string[] = [];
      let validRows = 0;
      let invalidRows = 0;
      let skippedRows = 0;

      dataRows.forEach((row, index) => {
        const rowNumber = index + 2; // +2 because we skip header and arrays are 0-indexed
        
        if (row.every(cell => cell.trim() === '')) {
          skippedRows++;
          return;
        }

        try {
          const event = this.parseEventRow(headers, row, rowNumber);
          const validation = this.validateEventRow(event, rowNumber);
          
          if (validation.isValid) {
            events.push(event);
            validRows++;
          } else {
            errors.push(...validation.errors);
            invalidRows++;
          }
          
          warnings.push(...validation.warnings);
        } catch (error) {
          errors.push(`Row ${rowNumber}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          invalidRows++;
        }
      });

      return {
        success: errors.length === 0,
        data: events,
        errors,
        warnings,
        summary: {
          totalRows: dataRows.length,
          validRows,
          invalidRows,
          skippedRows
        }
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        errors: [`Failed to parse CSV: ${error instanceof Error ? error.message : 'Unknown error'}`],
        warnings: [],
        summary: { totalRows: 0, validRows: 0, invalidRows: 0, skippedRows: 0 }
      };
    }
  }

  // Import users from CSV
  static importUsersFromCSV(csvContent: string): CSVImportResult {
    try {
      const rows = this.parseCSV(csvContent);
      if (rows.length === 0) {
        return {
          success: false,
          data: [],
          errors: ['CSV file is empty'],
          warnings: [],
          summary: { totalRows: 0, validRows: 0, invalidRows: 0, skippedRows: 0 }
        };
      }

      const headers = rows[0].map(h => h.toLowerCase().trim());
      const dataRows = rows.slice(1);
      
      // Validate headers
      const headerValidation = this.validateHeaders(headers, this.USER_SCHEMA);
      if (!headerValidation.isValid) {
        return {
          success: false,
          data: [],
          errors: headerValidation.errors,
          warnings: headerValidation.warnings,
          summary: { totalRows: dataRows.length, validRows: 0, invalidRows: dataRows.length, skippedRows: 0 }
        };
      }

      // Process data rows
      const users: HeapUser[] = [];
      const errors: string[] = [];
      const warnings: string[] = [];
      let validRows = 0;
      let invalidRows = 0;
      let skippedRows = 0;

      dataRows.forEach((row, index) => {
        const rowNumber = index + 2;
        
        if (row.every(cell => cell.trim() === '')) {
          skippedRows++;
          return;
        }

        try {
          const user = this.parseUserRow(headers, row, rowNumber);
          const validation = this.validateUserRow(user, rowNumber);
          
          if (validation.isValid) {
            users.push(user);
            validRows++;
          } else {
            errors.push(...validation.errors);
            invalidRows++;
          }
          
          warnings.push(...validation.warnings);
        } catch (error) {
          errors.push(`Row ${rowNumber}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          invalidRows++;
        }
      });

      return {
        success: errors.length === 0,
        data: users,
        errors,
        warnings,
        summary: {
          totalRows: dataRows.length,
          validRows,
          invalidRows,
          skippedRows
        }
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        errors: [`Failed to parse CSV: ${error instanceof Error ? error.message : 'Unknown error'}`],
        warnings: [],
        summary: { totalRows: 0, validRows: 0, invalidRows: 0, skippedRows: 0 }
      };
    }
  }

  // Import sessions from CSV
  static importSessionsFromCSV(csvContent: string): CSVImportResult {
    try {
      const rows = this.parseCSV(csvContent);
      if (rows.length === 0) {
        return {
          success: false,
          data: [],
          errors: ['CSV file is empty'],
          warnings: [],
          summary: { totalRows: 0, validRows: 0, invalidRows: 0, skippedRows: 0 }
        };
      }

      const headers = rows[0].map(h => h.toLowerCase().trim());
      const dataRows = rows.slice(1);
      
      // Validate headers
      const headerValidation = this.validateHeaders(headers, this.SESSION_SCHEMA);
      if (!headerValidation.isValid) {
        return {
          success: false,
          data: [],
          errors: headerValidation.errors,
          warnings: headerValidation.warnings,
          summary: { totalRows: dataRows.length, validRows: 0, invalidRows: dataRows.length, skippedRows: 0 }
        };
      }

      // Process data rows
      const sessions: HeapSession[] = [];
      const errors: string[] = [];
      const warnings: string[] = [];
      let validRows = 0;
      let invalidRows = 0;
      let skippedRows = 0;

      dataRows.forEach((row, index) => {
        const rowNumber = index + 2;
        
        if (row.every(cell => cell.trim() === '')) {
          skippedRows++;
          return;
        }

        try {
          const session = this.parseSessionRow(headers, row, rowNumber);
          const validation = this.validateSessionRow(session, rowNumber);
          
          if (validation.isValid) {
            sessions.push(session);
            validRows++;
          } else {
            errors.push(...validation.errors);
            invalidRows++;
          }
          
          warnings.push(...validation.warnings);
        } catch (error) {
          errors.push(`Row ${rowNumber}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          invalidRows++;
        }
      });

      return {
        success: errors.length === 0,
        data: sessions,
        errors,
        warnings,
        summary: {
          totalRows: dataRows.length,
          validRows,
          invalidRows,
          skippedRows
        }
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        errors: [`Failed to parse CSV: ${error instanceof Error ? error.message : 'Unknown error'}`],
        warnings: [],
        summary: { totalRows: 0, validRows: 0, invalidRows: 0, skippedRows: 0 }
      };
    }
  }

  // Validate CSV headers against schema
  private static validateHeaders(headers: string[], schema: CSVColumn[]): { isValid: boolean; errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];
    
    // Check for required columns
    const requiredColumns = schema.filter(col => col.required).map(col => col.name);
    const missingRequired = requiredColumns.filter(col => !headers.includes(col));
    
    if (missingRequired.length > 0) {
      errors.push(`Missing required columns: ${missingRequired.join(', ')}`);
    }
    
    // Check for unknown columns
    const knownColumns = schema.map(col => col.name);
    const unknownColumns = headers.filter(header => !knownColumns.includes(header));
    
    if (unknownColumns.length > 0) {
      warnings.push(`Unknown columns will be ignored: ${unknownColumns.join(', ')}`);
    }
    
    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  // Parse event row
  private static parseEventRow(headers: string[], row: string[], rowNumber: number): HeapEvent {
    const getValue = (columnName: string): string => {
      const index = headers.indexOf(columnName);
      return index >= 0 ? row[index]?.trim() || '' : '';
    };

    const parseJSON = (value: string): any => {
      if (!value) return {};
      try {
        return JSON.parse(value);
      } catch {
        return {};
      }
    };

    return {
      event_id: getValue('event_id'),
      user_id: getValue('user_id'),
      session_id: getValue('session_id'),
      time: getValue('time'),
      event_name: getValue('event_name'),
      event_properties: parseJSON(getValue('event_properties')),
      user_properties: parseJSON(getValue('user_properties')),
      session_properties: parseJSON(getValue('session_properties'))
    };
  }

  // Parse user row
  private static parseUserRow(headers: string[], row: string[], rowNumber: number): HeapUser {
    const getValue = (columnName: string): string => {
      const index = headers.indexOf(columnName);
      return index >= 0 ? row[index]?.trim() || '' : '';
    };

    const user: HeapUser = {
      user_id: getValue('user_id'),
      joindate: getValue('joindate'),
      last_modified: getValue('last_modified') || new Date().toISOString()
    };

    // Add optional fields
    const identity = getValue('identity');
    if (identity) user.identity = identity;
    
    const handle = getValue('handle');
    if (handle) user.handle = handle;
    
    const email = getValue('email');
    if (email) user.email = email;

    // Add any additional columns as custom properties
    headers.forEach((header, index) => {
      if (!['user_id', 'identity', 'handle', 'email', 'joindate', 'last_modified'].includes(header)) {
        const value = row[index]?.trim();
        if (value) {
          user[header] = value;
        }
      }
    });

    return user;
  }

  // Parse session row
  private static parseSessionRow(headers: string[], row: string[], rowNumber: number): HeapSession {
    const getValue = (columnName: string): string => {
      const index = headers.indexOf(columnName);
      return index >= 0 ? row[index]?.trim() || '' : '';
    };

    const session: HeapSession = {
      event_id: getValue('event_id'),
      user_id: getValue('user_id'),
      session_id: getValue('session_id'),
      time: getValue('time'),
      library: getValue('library') || 'web'
    };

    // Add optional fields
    const optionalFields = ['platform', 'device_type', 'country', 'region', 'city', 'browser', 'utm_source', 'utm_campaign', 'utm_medium'];
    optionalFields.forEach(field => {
      const value = getValue(field);
      if (value) {
        (session as any)[field] = value;
      }
    });

    return session;
  }

  // Validate event row
  private static validateEventRow(event: HeapEvent, rowNumber: number): { isValid: boolean; errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!event.event_id) errors.push(`Row ${rowNumber}: Missing event_id`);
    if (!event.user_id) errors.push(`Row ${rowNumber}: Missing user_id`);
    if (!event.session_id) errors.push(`Row ${rowNumber}: Missing session_id`);
    if (!event.time) errors.push(`Row ${rowNumber}: Missing time`);
    if (!event.event_name) errors.push(`Row ${rowNumber}: Missing event_name`);

    // Validate timestamp
    if (event.time && !this.isValidTimestamp(event.time)) {
      errors.push(`Row ${rowNumber}: Invalid timestamp format`);
    }

    return { isValid: errors.length === 0, errors, warnings };
  }

  // Validate user row
  private static validateUserRow(user: HeapUser, rowNumber: number): { isValid: boolean; errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!user.user_id) errors.push(`Row ${rowNumber}: Missing user_id`);
    if (!user.joindate) errors.push(`Row ${rowNumber}: Missing joindate`);

    // Validate timestamps
    if (user.joindate && !this.isValidTimestamp(user.joindate)) {
      errors.push(`Row ${rowNumber}: Invalid joindate format`);
    }
    if (user.last_modified && !this.isValidTimestamp(user.last_modified)) {
      errors.push(`Row ${rowNumber}: Invalid last_modified format`);
    }

    // Validate email format
    if (user.email && !this.isValidEmail(user.email)) {
      warnings.push(`Row ${rowNumber}: Invalid email format`);
    }

    return { isValid: errors.length === 0, errors, warnings };
  }

  // Validate session row
  private static validateSessionRow(session: HeapSession, rowNumber: number): { isValid: boolean; errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!session.event_id) errors.push(`Row ${rowNumber}: Missing event_id`);
    if (!session.user_id) errors.push(`Row ${rowNumber}: Missing user_id`);
    if (!session.session_id) errors.push(`Row ${rowNumber}: Missing session_id`);
    if (!session.time) errors.push(`Row ${rowNumber}: Missing time`);

    // Validate timestamp
    if (session.time && !this.isValidTimestamp(session.time)) {
      errors.push(`Row ${rowNumber}: Invalid timestamp format`);
    }

    return { isValid: errors.length === 0, errors, warnings };
  }

  // Helper methods
  private static isValidTimestamp(timestamp: string): boolean {
    const date = new Date(timestamp);
    return !isNaN(date.getTime());
  }

  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Generate CSV templates
  static generateEventCSVTemplate(): string {
    const headers = this.EVENT_SCHEMA.map(col => col.name);
    const sampleRow = [
      'event_123',
      'user_456',
      'session_789',
      '2024-01-01T12:00:00Z',
      'page_view',
      '{"url": "/home", "title": "Home Page"}',
      '{"plan": "premium", "segment": "power_user"}',
      '{"utm_source": "google", "device_type": "desktop"}'
    ];
    
    return [headers.join(','), sampleRow.join(',')].join('\n');
  }

  static generateUserCSVTemplate(): string {
    const headers = this.USER_SCHEMA.map(col => col.name);
    const sampleRow = [
      'user_456',
      'john.doe@example.com',
      'johndoe',
      'john.doe@example.com',
      '2024-01-01T12:00:00Z',
      '2024-01-15T12:00:00Z'
    ];
    
    return [headers.join(','), sampleRow.join(',')].join('\n');
  }

  static generateSessionCSVTemplate(): string {
    const headers = this.SESSION_SCHEMA.map(col => col.name);
    const sampleRow = [
      'session_event_789',
      'user_456',
      'session_789',
      '2024-01-01T12:00:00Z',
      'web',
      'web',
      'desktop',
      'US',
      'CA',
      'San Francisco',
      'Chrome',
      'google',
      'summer_sale',
      'cpc'
    ];
    
    return [headers.join(','), sampleRow.join(',')].join('\n');
  }
}

