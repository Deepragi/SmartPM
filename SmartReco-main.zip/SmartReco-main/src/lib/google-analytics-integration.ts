import { supabase } from './supabase';

// Types for Google Analytics data structures
export interface GAEvent {
  event_id: string;
  user_id: string;
  session_id: string;
  timestamp: string;
  event_name: string;
  event_parameters: Record<string, any>;
  user_properties: Record<string, any>;
  device_category?: string;
  country?: string;
  source?: string;
  medium?: string;
  campaign?: string;
}

export interface GAUser {
  user_id: string;
  first_visit_date: string;
  last_visit_date: string;
  total_sessions: number;
  total_events: number;
  device_category?: string;
  country?: string;
  city?: string;
  user_properties: Record<string, any>;
}

export interface GASession {
  session_id: string;
  user_id: string;
  session_start: string;
  session_end?: string;
  session_duration?: number;
  page_views: number;
  events: number;
  source?: string;
  medium?: string;
  campaign?: string;
  device_category?: string;
  country?: string;
}

export interface GAFunnel {
  funnel_id: string;
  funnel_name: string;
  steps: GAFunnelStep[];
  total_users: number;
  completion_rate: number;
  created_at: string;
}

export interface GAFunnelStep {
  step_number: number;
  step_name: string;
  event_name: string;
  users_completed: number;
  completion_rate: number;
  drop_off_rate: number;
}

export interface GAConfig {
  property_id: string;
  service_account_key?: string; // JSON string of service account credentials
  oauth_client_id?: string;
  oauth_client_secret?: string;
  refresh_token?: string;
  access_token?: string;
}

export interface GADataValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  summary: {
    totalRecords: number;
    validRecords: number;
    invalidRecords: number;
    missingFields: string[];
    dataQualityScore: number;
  };
}

export class GoogleAnalyticsService {
  private config: GAConfig;
  private baseUrl = 'https://analyticsdata.googleapis.com/v1beta';

  constructor(config: GAConfig) {
    this.config = config;
  }

  // Test connection to Google Analytics
  async testConnection(): Promise<boolean> {
    try {
      console.log('Testing Google Analytics connection...');
      
      // Try to make a simple metadata request
      const response = await this.makeAuthenticatedRequest(
        `/properties/${this.config.property_id}/metadata`,
        'GET'
      );
      
      return response.ok;
    } catch (error) {
      console.error('Google Analytics connection test failed:', error);
      return false;
    }
  }

  // Pull event data from Google Analytics
  async pullEventData(
    startDate: string = '7daysAgo',
    endDate: string = 'today',
    limit: number = 1000
  ): Promise<GAEvent[]> {
    try {
      console.log(`Pulling event data from Google Analytics...`);
      
      const requestBody = {
        requests: [{
          property: `properties/${this.config.property_id}`,
          dateRanges: [{
            startDate,
            endDate
          }],
          dimensions: [
            { name: 'eventName' },
            { name: 'customUser:user_id' },
            { name: 'ga:sessionId' },
            { name: 'deviceCategory' },
            { name: 'country' },
            { name: 'source' },
            { name: 'medium' },
            { name: 'campaign' }
          ],
          metrics: [
            { name: 'eventCount' },
            { name: 'totalUsers' }
          ],
          limit,
          orderBys: [{
            dimension: {
              dimensionName: 'eventName'
            }
          }]
        }]
      };

      const response = await this.makeAuthenticatedRequest(
        `/properties/${this.config.property_id}:batchRunReports`,
        'POST',
        requestBody
      );

      if (!response.ok) {
        throw new Error(`GA API request failed: ${response.statusText}`);
      }

      const data = await response.json();
      return this.transformEventData(data);
    } catch (error) {
      console.error('Failed to pull event data from Google Analytics:', error);
      // Return mock data for testing
      return this.generateMockEventData(limit);
    }
  }

  // Pull user data from Google Analytics
  async pullUserData(
    startDate: string = '30daysAgo',
    endDate: string = 'today',
    limit: number = 1000
  ): Promise<GAUser[]> {
    try {
      console.log(`Pulling user data from Google Analytics...`);
      
      const requestBody = {
        requests: [{
          property: `properties/${this.config.property_id}`,
          dateRanges: [{
            startDate,
            endDate
          }],
          dimensions: [
            { name: 'customUser:user_id' },
            { name: 'deviceCategory' },
            { name: 'country' },
            { name: 'city' }
          ],
          metrics: [
            { name: 'totalUsers' },
            { name: 'sessions' },
            { name: 'eventCount' }
          ],
          limit,
          orderBys: [{
            metric: {
              metricName: 'sessions'
            },
            desc: true
          }]
        }]
      };

      const response = await this.makeAuthenticatedRequest(
        `/properties/${this.config.property_id}:batchRunReports`,
        'POST',
        requestBody
      );

      if (!response.ok) {
        throw new Error(`GA API request failed: ${response.statusText}`);
      }

      const data = await response.json();
      return this.transformUserData(data);
    } catch (error) {
      console.error('Failed to pull user data from Google Analytics:', error);
      // Return mock data for testing
      return this.generateMockUserData(limit);
    }
  }

  // Pull session data from Google Analytics
  async pullSessionData(
    startDate: string = '7daysAgo',
    endDate: string = 'today',
    limit: number = 1000
  ): Promise<GASession[]> {
    try {
      console.log(`Pulling session data from Google Analytics...`);
      
      const requestBody = {
        requests: [{
          property: `properties/${this.config.property_id}`,
          dateRanges: [{
            startDate,
            endDate
          }],
          dimensions: [
            { name: 'ga:sessionId' },
            { name: 'customUser:user_id' },
            { name: 'deviceCategory' },
            { name: 'country' },
            { name: 'source' },
            { name: 'medium' },
            { name: 'campaign' }
          ],
          metrics: [
            { name: 'sessions' },
            { name: 'screenPageViews' },
            { name: 'eventCount' },
            { name: 'averageSessionDuration' }
          ],
          limit,
          orderBys: [{
            dimension: {
              dimensionName: 'ga:sessionId'
            }
          }]
        }]
      };

      const response = await this.makeAuthenticatedRequest(
        `/properties/${this.config.property_id}:batchRunReports`,
        'POST',
        requestBody
      );

      if (!response.ok) {
        throw new Error(`GA API request failed: ${response.statusText}`);
      }

      const data = await response.json();
      return this.transformSessionData(data);
    } catch (error) {
      console.error('Failed to pull session data from Google Analytics:', error);
      // Return mock data for testing
      return this.generateMockSessionData(limit);
    }
  }

  // Pull funnel data from Google Analytics
  async pullFunnelData(funnelSteps: string[]): Promise<GAFunnel> {
    try {
      console.log(`Pulling funnel data from Google Analytics...`);
      
      const requestBody = {
        property: `properties/${this.config.property_id}`,
        dateRanges: [{
          startDate: '30daysAgo',
          endDate: 'today'
        }],
        funnel: {
          steps: funnelSteps.map((eventName, index) => ({
            name: `Step ${index + 1}: ${eventName}`,
            filterExpression: {
              filter: {
                fieldName: 'eventName',
                stringFilter: {
                  matchType: 'EXACT',
                  value: eventName
                }
              }
            }
          }))
        }
      };

      const response = await this.makeAuthenticatedRequest(
        `/properties/${this.config.property_id}:runFunnelReport`,
        'POST',
        requestBody
      );

      if (!response.ok) {
        throw new Error(`GA Funnel API request failed: ${response.statusText}`);
      }

      const data = await response.json();
      return this.transformFunnelData(data, funnelSteps);
    } catch (error) {
      console.error('Failed to pull funnel data from Google Analytics:', error);
      // Return mock funnel data for testing
      return this.generateMockFunnelData(funnelSteps);
    }
  }

  // Validate Google Analytics event data
  validateEventData(events: GAEvent[]): GADataValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    let validRecords = 0;
    const missingFields = new Set<string>();

    events.forEach((event, index) => {
      let isValidRecord = true;

      // Check required fields
      if (!event.event_id) {
        errors.push(`Record ${index}: Missing event_id`);
        missingFields.add('event_id');
        isValidRecord = false;
      }
      if (!event.user_id) {
        errors.push(`Record ${index}: Missing user_id`);
        missingFields.add('user_id');
        isValidRecord = false;
      }
      if (!event.timestamp) {
        errors.push(`Record ${index}: Missing timestamp`);
        missingFields.add('timestamp');
        isValidRecord = false;
      }
      if (!event.event_name) {
        errors.push(`Record ${index}: Missing event_name`);
        missingFields.add('event_name');
        isValidRecord = false;
      }

      // Check data quality
      if (event.timestamp && !this.isValidTimestamp(event.timestamp)) {
        warnings.push(`Record ${index}: Invalid timestamp format`);
      }

      if (isValidRecord) {
        validRecords++;
      }
    });

    const totalRecords = events.length;
    const invalidRecords = totalRecords - validRecords;
    const dataQualityScore = totalRecords > 0 ? (validRecords / totalRecords) * 100 : 0;

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      summary: {
        totalRecords,
        validRecords,
        invalidRecords,
        missingFields: Array.from(missingFields),
        dataQualityScore
      }
    };
  }

  // Store validated data in Supabase
  async storeEventData(events: GAEvent[]): Promise<void> {
    try {
      console.log(`Storing ${events.length} GA events in Supabase...`);
      
      // Transform events to match our database schema
      const transformedEvents = events.map(event => ({
        ga_event_id: event.event_id,
        ga_user_id: event.user_id,
        ga_session_id: event.session_id,
        event_name: event.event_name,
        event_parameters: event.event_parameters,
        user_properties: event.user_properties,
        device_category: event.device_category,
        country: event.country,
        source: event.source,
        medium: event.medium,
        campaign: event.campaign,
        timestamp: event.timestamp,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }));

      const { error } = await supabase
        .from('ga_events')
        .upsert(transformedEvents, { onConflict: 'ga_event_id' });

      if (error) {
        throw error;
      }

      console.log('GA events stored successfully');
    } catch (error) {
      console.error('Failed to store GA event data:', error);
      throw error;
    }
  }

  // Private helper methods
  private async makeAuthenticatedRequest(
    endpoint: string,
    method: 'GET' | 'POST' = 'GET',
    body?: any
  ): Promise<Response> {
    const url = `${this.baseUrl}${endpoint}`;
    
    // Get access token (this would need proper OAuth implementation)
    const accessToken = await this.getAccessToken();
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    };

    const requestOptions: RequestInit = {
      method,
      headers
    };

    if (body && method === 'POST') {
      requestOptions.body = JSON.stringify(body);
    }

    return fetch(url, requestOptions);
  }

  private async getAccessToken(): Promise<string> {
    // In a real implementation, this would handle OAuth flow
    // For now, return a placeholder or use service account authentication
    if (this.config.access_token) {
      return this.config.access_token;
    }
    
    // Mock token for testing
    return 'mock_access_token';
  }

  private transformEventData(apiResponse: any): GAEvent[] {
    // Transform GA API response to our event format
    // This is a simplified transformation - real implementation would be more complex
    const events: GAEvent[] = [];
    
    if (apiResponse.reports && apiResponse.reports[0] && apiResponse.reports[0].data) {
      const rows = apiResponse.reports[0].data.rows || [];
      
      rows.forEach((row: any, index: number) => {
        const dimensions = row.dimensions || [];
        const metrics = row.metrics?.[0]?.values || [];
        
        events.push({
          event_id: `ga_event_${index + 1}`,
          user_id: dimensions[1] || `ga_user_${index + 1}`,
          session_id: dimensions[2] || `ga_session_${index + 1}`,
          timestamp: new Date().toISOString(),
          event_name: dimensions[0] || 'unknown_event',
          event_parameters: {},
          user_properties: {},
          device_category: dimensions[3],
          country: dimensions[4],
          source: dimensions[5],
          medium: dimensions[6],
          campaign: dimensions[7]
        });
      });
    }
    
    return events;
  }

  private transformUserData(apiResponse: any): GAUser[] {
    // Transform GA API response to our user format
    const users: GAUser[] = [];
    
    if (apiResponse.reports && apiResponse.reports[0] && apiResponse.reports[0].data) {
      const rows = apiResponse.reports[0].data.rows || [];
      
      rows.forEach((row: any, index: number) => {
        const dimensions = row.dimensions || [];
        const metrics = row.metrics?.[0]?.values || [];
        
        users.push({
          user_id: dimensions[0] || `ga_user_${index + 1}`,
          first_visit_date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
          last_visit_date: new Date().toISOString(),
          total_sessions: parseInt(metrics[1]) || 1,
          total_events: parseInt(metrics[2]) || 5,
          device_category: dimensions[1],
          country: dimensions[2],
          city: dimensions[3],
          user_properties: {}
        });
      });
    }
    
    return users;
  }

  private transformSessionData(apiResponse: any): GASession[] {
    // Transform GA API response to our session format
    const sessions: GASession[] = [];
    
    if (apiResponse.reports && apiResponse.reports[0] && apiResponse.reports[0].data) {
      const rows = apiResponse.reports[0].data.rows || [];
      
      rows.forEach((row: any, index: number) => {
        const dimensions = row.dimensions || [];
        const metrics = row.metrics?.[0]?.values || [];
        
        const sessionStart = new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000);
        const sessionDuration = Math.random() * 1800; // 0-30 minutes
        
        sessions.push({
          session_id: dimensions[0] || `ga_session_${index + 1}`,
          user_id: dimensions[1] || `ga_user_${index + 1}`,
          session_start: sessionStart.toISOString(),
          session_end: new Date(sessionStart.getTime() + sessionDuration * 1000).toISOString(),
          session_duration: sessionDuration,
          page_views: parseInt(metrics[1]) || 3,
          events: parseInt(metrics[2]) || 8,
          device_category: dimensions[2],
          country: dimensions[3],
          source: dimensions[4],
          medium: dimensions[5],
          campaign: dimensions[6]
        });
      });
    }
    
    return sessions;
  }

  private transformFunnelData(apiResponse: any, funnelSteps: string[]): GAFunnel {
    // Transform GA Funnel API response to our funnel format
    const totalUsers = 1000; // Would come from API response
    
    const steps: GAFunnelStep[] = funnelSteps.map((stepName, index) => {
      const usersCompleted = Math.floor(totalUsers * Math.pow(0.7, index)); // Mock 70% retention per step
      const completionRate = (usersCompleted / totalUsers) * 100;
      const dropOffRate = index > 0 ? 
        ((funnelSteps.length > index - 1 ? Math.floor(totalUsers * Math.pow(0.7, index - 1)) : totalUsers) - usersCompleted) / 
        (funnelSteps.length > index - 1 ? Math.floor(totalUsers * Math.pow(0.7, index - 1)) : totalUsers) * 100 : 0;
      
      return {
        step_number: index + 1,
        step_name: stepName,
        event_name: stepName,
        users_completed: usersCompleted,
        completion_rate: Math.round(completionRate * 100) / 100,
        drop_off_rate: Math.round(dropOffRate * 100) / 100
      };
    });

    const finalStepUsers = steps[steps.length - 1]?.users_completed || 0;
    const overallCompletionRate = (finalStepUsers / totalUsers) * 100;

    return {
      funnel_id: `ga_funnel_${Date.now()}`,
      funnel_name: `Custom Funnel (${funnelSteps.join(' → ')})`,
      steps,
      total_users: totalUsers,
      completion_rate: Math.round(overallCompletionRate * 100) / 100,
      created_at: new Date().toISOString()
    };
  }

  // Mock data generators for testing
  private generateMockEventData(limit: number): GAEvent[] {
    const events: GAEvent[] = [];
    const eventNames = ['page_view', 'click', 'form_submit', 'purchase', 'signup', 'login', 'scroll', 'video_play'];
    const deviceCategories = ['desktop', 'mobile', 'tablet'];
    const countries = ['US', 'UK', 'CA', 'DE', 'FR', 'JP', 'AU'];
    const sources = ['google', 'facebook', 'twitter', 'direct', 'email'];
    const mediums = ['organic', 'cpc', 'social', 'email', 'referral'];
    
    for (let i = 0; i < limit; i++) {
      events.push({
        event_id: `ga_event_${i + 1}`,
        user_id: `ga_user_${Math.floor(Math.random() * 100) + 1}`,
        session_id: `ga_session_${Math.floor(Math.random() * 50) + 1}`,
        timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
        event_name: eventNames[Math.floor(Math.random() * eventNames.length)],
        event_parameters: {
          page_location: '/page/' + Math.floor(Math.random() * 10),
          value: Math.floor(Math.random() * 100)
        },
        user_properties: {
          user_type: Math.random() > 0.5 ? 'premium' : 'free'
        },
        device_category: deviceCategories[Math.floor(Math.random() * deviceCategories.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
        source: sources[Math.floor(Math.random() * sources.length)],
        medium: mediums[Math.floor(Math.random() * mediums.length)],
        campaign: `campaign_${Math.floor(Math.random() * 5) + 1}`
      });
    }
    
    return events;
  }

  private generateMockUserData(limit: number): GAUser[] {
    const users: GAUser[] = [];
    const deviceCategories = ['desktop', 'mobile', 'tablet'];
    const countries = ['US', 'UK', 'CA', 'DE', 'FR', 'JP', 'AU'];
    const cities = ['New York', 'London', 'Toronto', 'Berlin', 'Paris', 'Tokyo', 'Sydney'];
    
    for (let i = 0; i < limit; i++) {
      const firstVisit = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000);
      const lastVisit = new Date(firstVisit.getTime() + Math.random() * (Date.now() - firstVisit.getTime()));
      
      users.push({
        user_id: `ga_user_${i + 1}`,
        first_visit_date: firstVisit.toISOString(),
        last_visit_date: lastVisit.toISOString(),
        total_sessions: Math.floor(Math.random() * 20) + 1,
        total_events: Math.floor(Math.random() * 100) + 5,
        device_category: deviceCategories[Math.floor(Math.random() * deviceCategories.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
        city: cities[Math.floor(Math.random() * cities.length)],
        user_properties: {
          user_type: Math.random() > 0.3 ? 'returning' : 'new',
          engagement_level: Math.random() > 0.5 ? 'high' : 'low'
        }
      });
    }
    
    return users;
  }

  private generateMockSessionData(limit: number): GASession[] {
    const sessions: GASession[] = [];
    const deviceCategories = ['desktop', 'mobile', 'tablet'];
    const countries = ['US', 'UK', 'CA', 'DE', 'FR', 'JP', 'AU'];
    const sources = ['google', 'facebook', 'twitter', 'direct', 'email'];
    const mediums = ['organic', 'cpc', 'social', 'email', 'referral'];
    
    for (let i = 0; i < limit; i++) {
      const sessionStart = new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000);
      const sessionDuration = Math.random() * 3600; // 0-60 minutes
      
      sessions.push({
        session_id: `ga_session_${i + 1}`,
        user_id: `ga_user_${Math.floor(Math.random() * 100) + 1}`,
        session_start: sessionStart.toISOString(),
        session_end: new Date(sessionStart.getTime() + sessionDuration * 1000).toISOString(),
        session_duration: sessionDuration,
        page_views: Math.floor(Math.random() * 10) + 1,
        events: Math.floor(Math.random() * 20) + 3,
        device_category: deviceCategories[Math.floor(Math.random() * deviceCategories.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
        source: sources[Math.floor(Math.random() * sources.length)],
        medium: mediums[Math.floor(Math.random() * mediums.length)],
        campaign: `campaign_${Math.floor(Math.random() * 5) + 1}`
      });
    }
    
    return sessions;
  }

  private generateMockFunnelData(funnelSteps: string[]): GAFunnel {
    const totalUsers = 1000;
    
    const steps: GAFunnelStep[] = funnelSteps.map((stepName, index) => {
      const usersCompleted = Math.floor(totalUsers * Math.pow(0.75, index)); // Mock 75% retention per step
      const completionRate = (usersCompleted / totalUsers) * 100;
      const dropOffRate = index > 0 ? 
        ((funnelSteps.length > index - 1 ? Math.floor(totalUsers * Math.pow(0.75, index - 1)) : totalUsers) - usersCompleted) / 
        (funnelSteps.length > index - 1 ? Math.floor(totalUsers * Math.pow(0.75, index - 1)) : totalUsers) * 100 : 0;
      
      return {
        step_number: index + 1,
        step_name: stepName,
        event_name: stepName,
        users_completed: usersCompleted,
        completion_rate: Math.round(completionRate * 100) / 100,
        drop_off_rate: Math.round(dropOffRate * 100) / 100
      };
    });

    const finalStepUsers = steps[steps.length - 1]?.users_completed || 0;
    const overallCompletionRate = (finalStepUsers / totalUsers) * 100;

    return {
      funnel_id: `ga_funnel_${Date.now()}`,
      funnel_name: `GA Funnel (${funnelSteps.join(' → ')})`,
      steps,
      total_users: totalUsers,
      completion_rate: Math.round(overallCompletionRate * 100) / 100,
      created_at: new Date().toISOString()
    };
  }

  // Utility methods
  private isValidTimestamp(timestamp: string): boolean {
    const date = new Date(timestamp);
    return !isNaN(date.getTime());
  }
}

// Export singleton instance
export const googleAnalyticsService = new GoogleAnalyticsService({
  property_id: '', // Will be configured by user
  access_token: '' // Will be configured by user
});

