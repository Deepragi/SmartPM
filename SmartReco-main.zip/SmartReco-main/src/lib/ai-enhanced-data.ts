import { supabase } from './supabase';
import { AIModelingService } from './ai-modeling';
import { DropoffInsight, Recommendation, FunnelStep, AIExplanation } from './database.types';

/**
 * Service to integrate AI-generated insights into existing data tables
 * This allows the app to display AI insights alongside existing funnel data
 */
export class AIEnhancedDataService {
  
  /**
   * Enhance dropoff insights with AI-generated analysis and explanations
   */
  static async enhanceDropoffInsights() {
    try {
      console.log('🤖 Enhancing dropoff insights with AI analysis and explanations...');
      
      // Get existing dropoff insights
      const { data: dropoffs, error: dropoffError } = await supabase
        .from('dropoff_insights')
        .select('*')
        .order('impact_score', { ascending: false });

      if (dropoffError) {
        console.error('❌ Error fetching dropoff insights:', dropoffError);
        throw dropoffError;
      }

      if (!dropoffs || dropoffs.length === 0) {
        console.log('⚠️ No dropoff insights found to enhance');
        return [];
      }

      const enhancedDropoffs = [];
      for (const dropoff of dropoffs) {
        try {
          // Generate AI analysis for this dropoff
          const aiAnalysis = await AIModelingService.analyzeDropoffPoint({
            stepFrom: dropoff.step_from,
            stepTo: dropoff.step_to,
            dropRate: dropoff.drop_rate,
            affectedUsers: dropoff.affected_users,
            currentHypothesis: dropoff.hypothesis,
            currentEvidence: dropoff.evidence
          });

          // Generate and store AI explanation
          const aiExplanation: AIExplanation = await AIModelingService.generateExplanationForDropoff({
            dropoff_insight_id: dropoff.id,
            hypothesis_text: aiAnalysis.hypothesis,
            evidence_summary: aiAnalysis.evidenceSummary,
            evidence_details: aiAnalysis.evidenceDetails,
            ai_reasoning_trace: aiAnalysis.reasoningTrace,
            confidence_score: aiAnalysis.confidence
          });

          // Update the dropoff insight with AI-generated fields and link to explanation
          const { error: updateError } = await supabase
            .from('dropoff_insights')
            .update({
              ai_confidence: aiAnalysis.confidence,
              ai_predicted_impact: aiAnalysis.predictedImpact,
              ai_optimization_suggestions: aiAnalysis.optimizationSuggestions,
              ai_risk_factors: aiAnalysis.riskFactors,
              ai_last_analyzed: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              ai_generated_hypothesis_id: aiExplanation.id // Link to new explanation
            })
            .eq('id', dropoff.id);

          if (updateError) {
            console.error(`❌ Error updating dropoff ${dropoff.id}:`, updateError);
            continue;
          }

          enhancedDropoffs.push({
            ...dropoff,
            ai_confidence: aiAnalysis.confidence,
            ai_predicted_impact: aiAnalysis.predictedImpact,
            ai_optimization_suggestions: aiAnalysis.optimizationSuggestions,
            ai_risk_factors: aiAnalysis.riskFactors,
            ai_last_analyzed: new Date().toISOString(),
            ai_generated_hypothesis_id: aiExplanation.id
          });

          console.log(`✅ Enhanced dropoff insight: ${dropoff.step_from} → ${dropoff.step_to}`);
        } catch (error) {
          console.error(`💥 Failed to enhance dropoff ${dropoff.id}:`, error);
          enhancedDropoffs.push(dropoff); // Include original without AI enhancement
        }
      }

      console.log(`✅ Enhanced ${enhancedDropoffs.length} dropoff insights with AI analysis`);
      return enhancedDropoffs;

    } catch (error) {
      console.error('💥 Failed to enhance dropoff insights:', error);
      throw error;
    }
  }

  /**
   * Enhance recommendations with AI-generated priority, impact, and effort scores
   */
  static async enhanceRecommendations() {
    try {
      console.log('🤖 Enhancing recommendations with AI analysis...');
      
      // Get existing recommendations
      const { data: recommendations, error: recError } = await supabase
        .from('recommendations')
        .select('*')
        .eq('status', 'pending');

      if (recError) {
        console.error('❌ Error fetching recommendations:', recError);
        throw recError;
      }

      if (!recommendations || recommendations.length === 0) {
        console.log('⚠️ No pending recommendations found to enhance');
        return [];
      }

      // Generate AI analysis for each recommendation
      const enhancedRecommendations = [];
      for (const rec of recommendations) {
        try {
          // Generate AI analysis for this recommendation
          const aiAnalysis = await AIModelingService.analyzeRecommendation({
            title: rec.title,
            description: rec.description,
            confidence: rec.confidence,
            rationale: rec.rationale
          });

          // Update the recommendation with AI-generated fields
          const { error: updateError } = await supabase
            .from('recommendations')
            .update({
              ai_generated: false, // This is a human-generated recommendation enhanced by AI
              ai_ranking_score: aiAnalysis.priorityScore, // Renamed
              ai_implementation_effort: aiAnalysis.implementationEffort,
              ai_expected_impact: aiAnalysis.expectedImpact,
              ai_success_probability: aiAnalysis.successProbability,
              ai_estimated_impact: aiAnalysis.estimatedImpact, // New field
              ai_estimated_effort: aiAnalysis.estimatedEffort, // New field
              updated_at: new Date().toISOString()
            })
            .eq('id', rec.id);

          if (updateError) {
            console.error(`❌ Error updating recommendation ${rec.id}:`, updateError);
            continue;
          }

          enhancedRecommendations.push({
            ...rec,
            ai_generated: false,
            ai_ranking_score: aiAnalysis.priorityScore,
            ai_implementation_effort: aiAnalysis.implementationEffort,
            ai_expected_impact: aiAnalysis.expectedImpact,
            ai_success_probability: aiAnalysis.successProbability,
            ai_estimated_impact: aiAnalysis.estimatedImpact,
            ai_estimated_effort: aiAnalysis.estimatedEffort
          });

          console.log(`✅ Enhanced recommendation: ${rec.title}`);
        } catch (error) {
          console.error(`💥 Failed to enhance recommendation ${rec.id}:`, error);
          enhancedRecommendations.push(rec); // Include original without AI enhancement
        }
      }

      console.log(`✅ Enhanced ${enhancedRecommendations.length} recommendations with AI analysis`);
      return enhancedRecommendations;

    } catch (error) {
      console.error('💥 Failed to enhance recommendations:', error);
      throw error;
    }
  }

  /**
   * Enhance funnel steps with AI-generated predictions and optimization potential
   */
  static async enhanceFunnelSteps() {
    try {
      console.log('🤖 Enhancing funnel steps with AI analysis...');
      
      // Get existing funnel steps
      const { data: funnelSteps, error: funnelError } = await supabase
        .from('funnels')
        .select('*')
        .order('step_order', { ascending: true });

      if (funnelError) {
        console.error('❌ Error fetching funnel steps:', funnelError);
        throw funnelError;
      }

      if (!funnelSteps || funnelSteps.length === 0) {
        console.log('⚠️ No funnel steps found to enhance');
        return [];
      }

      // Generate AI analysis for each funnel step
      const enhancedSteps = [];
      for (const step of funnelSteps) {
        try {
          // Generate AI analysis for this funnel step
          const aiAnalysis = await AIModelingService.analyzeFunnelStep({
            stepName: step.step_name,
            conversionRate: step.conversion_rate,
            stepOrder: step.step_order,
            funnelId: step.funnel_id
          });

          // Update the funnel step with AI-generated fields
          const { error: updateError } = await supabase
            .from('funnels')
            .update({
              ai_predicted_conversion_rate: aiAnalysis.predictedConversionRate,
              ai_optimization_potential: aiAnalysis.optimizationPotential,
              ai_bottleneck_score: aiAnalysis.bottleneckScore,
              ai_recommendations: aiAnalysis.recommendations,
              ai_last_analyzed: new Date().toISOString(),
              updated_at: new Date().toISOString()
            })
            .eq('funnel_id', step.funnel_id)
            .eq('step_name', step.step_name);

          if (updateError) {
            console.error(`❌ Error updating funnel step ${step.step_name}:`, updateError);
            continue;
          }

          enhancedSteps.push({
            ...step,
            ai_predicted_conversion_rate: aiAnalysis.predictedConversionRate,
            ai_optimization_potential: aiAnalysis.optimizationPotential,
            ai_bottleneck_score: aiAnalysis.bottleneckScore,
            ai_recommendations: aiAnalysis.recommendations,
            ai_last_analyzed: new Date().toISOString()
          });

          console.log(`✅ Enhanced funnel step: ${step.step_name}`);
        } catch (error) {
          console.error(`💥 Failed to enhance funnel step ${step.step_name}:`, error);
          enhancedSteps.push(step); // Include original without AI enhancement
        }
      }

      console.log(`✅ Enhanced ${enhancedSteps.length} funnel steps with AI analysis`);
      return enhancedSteps;

    } catch (error) {
      console.error('💥 Failed to enhance funnel steps:', error);
      throw error;
    }
  }

  /**
   * Generate AI-powered recommendations for existing dropoff insights
   */
  static async generateAIRecommendations() {
    try {
      console.log('🤖 Generating AI-powered recommendations...');
      
      // Get dropoff insights that don't have recent AI recommendations
      const { data: dropoffs, error: dropoffError } = await supabase
        .from('dropoff_insights')
        .select('*')
        .order('impact_score', { ascending: false });

      if (dropoffError) {
        console.error('❌ Error fetching dropoff insights:', dropoffError);
        throw dropoffError;
      }

      if (!dropoffs || dropoffs.length === 0) {
        console.log('⚠️ No dropoff insights found for AI recommendation generation');
        return [];
      }

      const newRecommendations = [];
      for (const dropoff of dropoffs) {
        try {
          // Generate AI recommendations for this dropoff
          const aiRecommendations = await AIModelingService.generateRecommendations({
            stepFrom: dropoff.step_from,
            stepTo: dropoff.step_to,
            dropRate: dropoff.drop_rate,
            affectedUsers: dropoff.affected_users,
            hypothesis: dropoff.hypothesis,
            evidence: dropoff.evidence
          });

          // Insert AI-generated recommendations
          const insertedRecIds: string[] = [];
          for (const aiRec of aiRecommendations) {
            const { data: insertedRec, error: insertError } = await supabase
              .from('recommendations')
              .insert({
                dropoff_id: dropoff.id,
                title: aiRec.title,
                description: aiRec.description,
                confidence: aiRec.confidence,
                rationale: aiRec.rationale,
                status: 'pending',
                ai_generated: true,
                ai_ranking_score: aiRec.priorityScore, // Renamed
                ai_implementation_effort: aiRec.implementationEffort,
                ai_expected_impact: aiRec.expectedImpact,
                ai_success_probability: aiRec.successProbability,
                ai_estimated_impact: aiRec.estimatedImpact, // New field
                ai_estimated_effort: aiRec.estimatedEffort // New field
              })
              .select()
              .single();

            if (insertError) {
              console.error(`❌ Error inserting AI recommendation:`, insertError);
              continue;
            }

            newRecommendations.push(insertedRec);
            insertedRecIds.push(insertedRec.id);
            console.log(`✅ Generated AI recommendation: ${aiRec.title}`);
          }

          // Update dropoff_insights with generated recommendation IDs
          if (insertedRecIds.length > 0) {
            const { error: updateDropoffError } = await supabase
              .from('dropoff_insights')
              .update({ ai_generated_recommendation_ids: insertedRecIds })
              .eq('id', dropoff.id);
            
            if (updateDropoffError) {
              console.error(`❌ Error updating dropoff with recommendation IDs ${dropoff.id}:`, updateDropoffError);
            }
          }

        } catch (error) {
          console.error(`💥 Failed to generate AI recommendations for dropoff ${dropoff.id}:`, error);
        }
      }

      console.log(`✅ Generated ${newRecommendations.length} AI-powered recommendations`);
      return newRecommendations;

    } catch (error) {
      console.error('💥 Failed to generate AI recommendations:', error);
      throw error;
    }
  }

  /**
   * Run complete AI enhancement process for all data
   */
  static async runCompleteAIEnhancement() {
    try {
      console.log('🚀 Starting complete AI enhancement process...');
      
      const results = {
        enhancedDropoffs: [],
        enhancedRecommendations: [],
        enhancedFunnelSteps: [],
        newAIRecommendations: []
      };

      // Run all enhancement processes
      try {
        results.enhancedDropoffs = await this.enhanceDropoffInsights();
      } catch (error) {
        console.error('Failed to enhance dropoff insights:', error);
      }

      try {
        results.enhancedRecommendations = await this.enhanceRecommendations();
      } catch (error) {
        console.error('Failed to enhance recommendations:', error);
      }

      try {
        results.enhancedFunnelSteps = await this.enhanceFunnelSteps();
      } catch (error) {
        console.error('Failed to enhance funnel steps:', error);
      }

      try {
        results.newAIRecommendations = await this.generateAIRecommendations();
      } catch (error) {
        console.error('Failed to generate AI recommendations:', error);
      }

      console.log('🎉 Complete AI enhancement process finished!');
      console.log('Results:', {
        enhancedDropoffs: results.enhancedDropoffs.length,
        enhancedRecommendations: results.enhancedRecommendations.length,
        enhancedFunnelSteps: results.enhancedFunnelSteps.length,
        newAIRecommendations: results.newAIRecommendations.length
      });

      return results;

    } catch (error) {
      console.error('💥 Failed to run complete AI enhancement:', error);
      throw error;
    }
  }

  /**
   * Get enhanced data for dashboard display
   */
  static async getEnhancedDashboardData() {
    try {
      console.log('📊 Fetching enhanced dashboard data...');
      
      // Fetch all enhanced data
      const [dropoffs, recommendations, funnelSteps, aiExplanations] = await Promise.all([
        supabase.from('dropoff_insights').select('*').order('impact_score', { ascending: false }),
        supabase.from('recommendations').select('*').order('ai_ranking_score', { ascending: false }), // Renamed
        supabase.from('funnels').select('*').order('step_order', { ascending: true }),
        supabase.from('ai_explanations').select('*') // Fetch AI explanations
      ]);

      if (dropoffs.error) throw dropoffs.error;
      if (recommendations.error) throw recommendations.error;
      if (funnelSteps.error) throw funnelSteps.error;
      if (aiExplanations.error) throw aiExplanations.error;

      // Combine dropoffs with their recommendations and explanations
      const enhancedDropoffs = (dropoffs.data || []).map(dropoff => {
        const dropoffRecommendations = (recommendations.data || []).filter(rec => rec.dropoff_id === dropoff.id);
        const explanation = (aiExplanations.data || []).find(exp => exp.id === dropoff.ai_generated_hypothesis_id);
        return {
          ...dropoff,
          recommendations: dropoffRecommendations,
          ai_explanation: explanation // Attach explanation
        };
      });

      console.log('✅ Enhanced dashboard data fetched successfully');
      return {
        dropoffs: enhancedDropoffs,
        funnelSteps: funnelSteps.data || [],
        totalRecommendations: recommendations.data?.length || 0,
        aiGeneratedRecommendations: recommendations.data?.filter(r => r.ai_generated)?.length || 0
      };

    } catch (error) {
      console.error('💥 Failed to fetch enhanced dashboard data:', error);
      throw error;
    }
  }
}


