import { createClient } from '@supabase/supabase-js';
import { Database, UserFeedback, FunnelStep } from './database.types';

// These will be populated from your .env file after connecting to Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Check if Supabase is configured
const isSupabaseConfigured = supabaseUrl && supabaseAnonKey && supabaseUrl !== 'undefined' && supabaseAnonKey !== 'undefined';

// Only create client if properly configured
export const supabase = isSupabaseConfigured 
  ? createClient<Database>(supabaseUrl, supabaseAnonKey)
  : null;

// Demo data for when Supabase is not configured
const DEMO_FUNNEL_STEPS = [
  { funnel_id: 'demo-1', step_name: 'Landing Page', conversion_rate: 0.85, step_order: 1 },
  { funnel_id: 'demo-2', step_name: 'Sign Up', conversion_rate: 0.42, step_order: 2 },
  { funnel_id: 'demo-3', step_name: 'Onboarding', conversion_rate: 0.78, step_order: 3 },
  { funnel_id: 'demo-4', step_name: 'Activation', conversion_rate: 0.65, step_order: 4 }
];

const DEMO_DROPOFF_INSIGHTS = [
  {
    id: 'demo-dropoff-1',
    step_from: 'Landing Page',
    step_to: 'Sign Up',
    impact_score: 0.92,
    drop_rate: 0.58,
    affected_users: 2340,
    hypothesis: 'Complex signup form with too many required fields is causing friction. Users are abandoning before completing registration.',
    evidence: ['High form abandonment rate', 'Mobile users drop off 2x more', 'Time on signup page is 40% longer than benchmark'],
    recommendations: [
      {
        id: 'demo-rec-1',
        title: 'Simplify signup form',
        description: 'Reduce required fields from 8 to 3 (email, password, name)',
        confidence: 0.85,
        rationale: 'Industry benchmarks show 3-field forms have 35% higher completion rates',
        status: 'pending'
      },
      {
        id: 'demo-rec-2',
        title: 'Add social login options',
        description: 'Implement Google and Apple sign-in for faster registration',
        confidence: 0.78,
        rationale: 'Social logins reduce friction and increase mobile conversion by 25%',
        status: 'pending'
      }
    ]
  },
  {
    id: 'demo-dropoff-2',
    step_from: 'Sign Up',
    step_to: 'Onboarding',
    impact_score: 0.76,
    drop_rate: 0.22,
    affected_users: 890,
    hypothesis: 'Email verification requirement is creating a disconnect between signup and onboarding completion.',
    evidence: ['24-hour delay in email verification', 'Low email open rates (32%)', 'Users who verify complete onboarding at 95% rate'],
    recommendations: [
      {
        id: 'demo-rec-3',
        title: 'Optional email verification',
        description: 'Allow users to proceed with onboarding before email verification',
        confidence: 0.72,
        rationale: 'Reduces immediate friction while maintaining security through later verification',
        status: 'pending'
      }
    ]
  },
  {
    id: 'demo-dropoff-3',
    step_from: 'Onboarding',
    step_to: 'Activation',
    impact_score: 0.68,
    drop_rate: 0.35,
    affected_users: 1120,
    hypothesis: 'Users are overwhelmed by the number of setup steps required for activation.',
    evidence: ['Average onboarding session is 12 minutes vs 6 minute benchmark', 'Users exit most at step 4 of 7', 'Support tickets about setup complexity increased 40%'],
    recommendations: [
      {
        id: 'demo-rec-4',
        title: 'Progressive onboarding',
        description: 'Split onboarding into core (3 steps) and advanced (4 steps) flows',
        confidence: 0.81,
        rationale: 'Progressive disclosure reduces cognitive load and increases completion rates',
        status: 'pending'
      }
    ]
  }
];

// Database service functions
export const DatabaseService = {
  // Check if Supabase is available
  isAvailable() {
    return isSupabaseConfigured && supabase !== null;
  },

  // Fetch funnel steps
  async getFunnelSteps() {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured - using demo mode');
      // Return demo data for when Supabase is not configured
      return DEMO_FUNNEL_STEPS;
    }

    try {
      console.log('🔍 Fetching funnel steps...');
      
      const { data, error, status, statusText } = await supabase!
        .from('funnels')
        .select('*')
        .order('step_order', { ascending: true });
      
      console.log('Funnels query response:', { data, error, status, statusText });
      
      if (error) {
        console.error('❌ Error fetching funnel steps:', error);
        console.error('Error details:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
        throw error;
      }
      
      console.log('✅ Funnel steps fetched successfully:', data?.length || 0);
      return data || [];
    } catch (error) {
      console.error('💥 Failed to fetch funnel steps:', error);
      throw error;
    }
  },

  // Fetch dropoff insights with recommendations and explanations
  async getDropoffInsights() {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured - using demo mode');
      // Return demo data for when Supabase is not configured
      return DEMO_DROPOFF_INSIGHTS;
    }

    try {
      console.log('🔍 Fetching dropoff insights...');
      
      // First, get dropoff insights
      const { data: dropoffData, error: dropoffError, status: dropoffStatus, statusText: dropoffStatusText } = await supabase!
        .from('dropoff_insights')
        .select('*')
        .order('impact_score', { ascending: false });
      
      console.log('Dropoff insights query response:', { 
        data: dropoffData, 
        error: dropoffError, 
        status: dropoffStatus, 
        statusText: dropoffStatusText 
      });
      
      if (dropoffError) {
        console.error('❌ Error fetching dropoff insights:', dropoffError);
        console.error('Error details:', {
          message: dropoffError.message,
          details: dropoffError.details,
          hint: dropoffError.hint,
          code: error.code
        });
        throw dropoffError;
      }
      
      console.log('✅ Dropoff insights fetched:', dropoffData?.length || 0);
      
      if (!dropoffData || dropoffData.length === 0) {
        console.log('⚠️ No dropoff insights found in database');
        return [];
      }
      
      // Then, get recommendations for each dropoff insight
      console.log('🔍 Fetching recommendations...');
      const dropoffIds = dropoffData.map(d => d.id);
      console.log('Looking for recommendations for dropoff IDs:', dropoffIds);
      
      const { data: recommendationsData, error: recommendationsError, status: recStatus, statusText: recStatusText } = await supabase!
        .from('recommendations')
        .select('*')
        .in('dropoff_id', dropoffIds);
      
      console.log('Recommendations query response:', { 
        data: recommendationsData, 
        error: recommendationsError, 
        status: recStatus, 
        statusText: recStatusText 
      });
      
      if (recommendationsError) {
        console.error('❌ Error fetching recommendations:', recommendationsError);
        console.error('Error details:', {
          message: recommendationsError.message,
          details: recommendationsError.details,
          hint: recommendationsError.hint,
          code: recommendationsError.code
        });
        // Don't throw here, just log and continue without recommendations
      }
      
      console.log('✅ Recommendations fetched:', recommendationsData?.length || 0);

      // Fetch AI explanations
      console.log('🔍 Fetching AI explanations...');
      const explanationIds = dropoffData.map(d => d.ai_generated_hypothesis_id).filter(Boolean);
      const { data: explanationsData, error: explanationsError } = await supabase!
        .from('ai_explanations')
        .select('*')
        .in('id', explanationIds);

      if (explanationsError) {
        console.error('❌ Error fetching AI explanations:', explanationsError);
      }
      console.log('✅ AI explanations fetched:', explanationsData?.length || 0);
      
      // Combine dropoff insights with their recommendations and explanations
      const result = dropoffData.map(dropoff => {
        const dropoffRecommendations = recommendationsData?.filter(rec => rec.dropoff_id === dropoff.id) || [];
        const aiExplanation = explanationsData?.find(exp => exp.id === dropoff.ai_generated_hypothesis_id);
        
        return {
          ...dropoff,
          recommendations: dropoffRecommendations,
          ai_explanation: aiExplanation
        };
      });
      
      console.log('✅ Combined dropoff insights with recommendations and explanations:', result.length);
      console.log('Final result sample:', result[0]);
      return result;
      
    } catch (error) {
      console.error('💥 Failed to fetch dropoff insights:', error);
      throw error;
    }
  },

  // Update recommendation status
  async updateRecommendationStatus(recommendationId: string, status: string, userFeedback?: string) {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured, cannot update recommendation status');
      return;
    }

    try {
      console.log('🔄 Updating recommendation status:', { recommendationId, status, userFeedback });
      
      const { error: updateError } = await supabase!
        .from('recommendations')
        .update({ 
          status,
          user_feedback: userFeedback, // New field
          updated_at: new Date().toISOString()
        })
        .eq('id', recommendationId);

      if (updateError) {
        console.error('❌ Error updating recommendation:', updateError);
        throw updateError;
      }

      // Log user feedback
      if (userFeedback) {
        await this.logUserFeedback({
          recommendation_id: recommendationId,
          feedback_type: status as UserFeedback['feedback_type'], // 'approved', 'dismissed', 'edited'
          feedback_text: userFeedback,
          user_id: 'current_user_id', // Placeholder, replace with actual user ID
          context: { source: 'updateRecommendationStatus' }
        });
      }
      
      console.log('✅ Recommendation status updated successfully');
    } catch (error) {
      console.error('💥 Failed to update recommendation status:', error);
      throw error;
    }
  },

  // Create workflow sync record
  async createWorkflowSync(recommendationId: string, platform: 'jira' | 'notion', ticketId?: string, syncDetails?: Record<string, any>) {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured, cannot create workflow sync');
      return null;
    }

    try {
      console.log('🔄 Creating workflow sync:', { recommendationId, platform, ticketId });
      
      const { data, error } = await supabase!
        .from('workflow_sync_log') // New table
        .insert({
          recommendation_id: recommendationId,
          platform,
          ticket_id: ticketId,
          sync_status: 'success',
          sync_details: syncDetails || {},
          synced_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) {
        console.error('❌ Error creating workflow sync:', error);
        throw error;
      }

      // Update recommendation with jira_ticket_id
      if (ticketId) {
        const { error: updateRecError } = await supabase!
          .from('recommendations')
          .update({ jira_ticket_id: ticketId })
          .eq('id', recommendationId);
        
        if (updateRecError) {
          console.error('❌ Error updating recommendation with ticket ID:', updateRecError);
        }
      }
      
      console.log('✅ Workflow sync created successfully');
      return data;
    } catch (error) {
      console.error('💥 Failed to create workflow sync:', error);
      throw error;
    }
  },

  // Log user feedback
  async logUserFeedback(feedback: UserFeedback) {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured, cannot log user feedback');
      return;
    }

    try {
      console.log('📝 Logging user feedback:', feedback);
      const { error } = await supabase!
        .from('user_feedback')
        .insert({
          recommendation_id: feedback.recommendation_id,
          feedback_type: feedback.feedback_type,
          feedback_text: feedback.feedback_text,
          user_id: feedback.user_id,
          context: feedback.context,
          created_at: new Date().toISOString()
        });

      if (error) {
        console.error('❌ Error logging user feedback:', error);
        throw error;
      }
      console.log('✅ User feedback logged successfully');
    } catch (error) {
      console.error('💥 Failed to log user feedback:', error);
      throw error;
    }
  },

  // Get top N highest-impact drop-offs for the dashboard
  async getTopDropoffInsights(limit: number = 3) {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured - using demo mode');
      return DEMO_DROPOFF_INSIGHTS.slice(0, limit);
    }

    try {
      console.log(`🔍 Fetching top ${limit} dropoff insights...`);
      const { data, error } = await supabase!
        .from('dropoff_insights')
        .select('*')
        .order('impact_score', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('❌ Error fetching top dropoff insights:', error);
        throw error;
      }
      console.log(`✅ Fetched ${data?.length || 0} top dropoff insights.`);
      return data || [];
    } catch (error) {
      console.error('💥 Failed to fetch top dropoff insights:', error);
      throw error;
    }
  },

  // Get recommendations for a specific dropoff
  async getRecommendationsForDropoff(dropoffId: string) {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured');
      return [];
    }

    try {
      console.log(`🔍 Fetching recommendations for dropoff ${dropoffId}...`);
      const { data, error } = await supabase!
        .from('recommendations')
        .select('*')
        .eq('dropoff_id', dropoffId)
        .order('ai_ranking_score', { ascending: false });

      if (error) {
        console.error(`❌ Error fetching recommendations for dropoff ${dropoffId}:`, error);
        throw error;
      }
      console.log(`✅ Fetched ${data?.length || 0} recommendations for dropoff ${dropoffId}.`);
      return data || [];
    } catch (error) {
      console.error(`💥 Failed to fetch recommendations for dropoff ${dropoffId}:`, error);
      throw error;
    }
  },

  // Test database connection
  async testConnection() {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured');
      return false;
    }

    try {
      console.log('🔍 Testing database connection...');
      
      const { data, error, status, statusText } = await supabase!
        .from('user_segments') // Using a simpler table for connection test
        .select('count(*)')
        .limit(1);
      
      console.log('Connection test response:', { data, error, status, statusText });
      
      if (error) {
        console.error('❌ Database connection test failed:', error);
        throw error;
      }
      
      console.log('✅ Database connection test successful');
      return true;
    } catch (error) {
      console.error('💥 Database connection test failed:', error);
      throw error;
    }
  },

  // New: Get all events (for funnel suggestion)
  async getAllEvents() {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured - returning empty events array');
      return [];
    }
    try {
      console.log('🔍 Fetching all events...');
      const { data, error } = await supabase!
        .from('events') // Assuming an 'events' table exists in your Supabase DB
        .select('*');
      
      if (error) {
        console.error('❌ Error fetching all events:', error);
        throw error;
      }
      console.log(`✅ Fetched ${data?.length || 0} events.`);
      return data || [];
    } catch (error) {
      console.error('💥 Failed to fetch all events:', error);
      throw error;
    }
  },

  // New: Add a new funnel
  async addFunnel(funnel: { funnel_id: string; funnel_name: string; steps: string[]; }) {
    if (!this.isAvailable()) {
      console.log('⚠️ Supabase not configured - cannot add funnel');
      return;
    }
    try {
      console.log('➕ Adding new funnel:', funnel.funnel_name);
      // For simplicity, assuming 'funnels' table can store funnel_name and steps directly
      // You might need to adjust this based on your actual 'funnels' table schema
      const { error } = await supabase!
        .from('funnels')
        .insert({
          funnel_id: funnel.funnel_id,
          funnel_name: funnel.funnel_name,
          step_name: funnel.steps[0], // Assuming first step is the funnel name for simplicity
          conversion_rate: 1.0, // Default for new funnel
          step_order: 1, // Default for new funnel
          // You might need to insert each step individually if your schema is normalized
        });

      if (error) {
        console.error('❌ Error adding funnel:', error);
        throw error;
      }
      console.log('✅ Funnel added successfully');
    } catch (error) {
      console.error('💥 Failed to add funnel:', error);
      throw error;
    }
  }
};

