export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          user_id: string;
          segment: string;
          device: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id?: string;
          segment?: string;
          device?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          user_id?: string;
          segment?: string;
          device?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      sessions: {
        Row: {
          session_id: string;
          user_id: string;
          event_path: string[];
          duration: number;
          created_at: string;
        };
        Insert: {
          session_id?: string;
          user_id: string;
          event_path: string[];
          duration: number;
          created_at?: string;
        };
        Update: {
          session_id?: string;
          user_id?: string;
          event_path?: string[];
          duration?: number;
          created_at?: string;
        };
      };
      funnels: {
        Row: {
          funnel_id: string;
          step_name: string;
          conversion_rate: number;
          step_order: number;
          created_at: string;
          updated_at: string;
          // AI-generated fields
          ai_predicted_conversion_rate?: number;
          ai_optimization_potential?: number;
          ai_bottleneck_score?: number;
          ai_recommendations?: string[];
          ai_last_analyzed?: string;
        };
        Insert: {
          funnel_id?: string;
          step_name: string;
          conversion_rate: number;
          step_order: number;
          created_at?: string;
          updated_at?: string;
          // AI-generated fields
          ai_predicted_conversion_rate?: number;
          ai_optimization_potential?: number;
          ai_bottleneck_score?: number;
          ai_recommendations?: string[];
          ai_last_analyzed?: string;
        };
        Update: {
          funnel_id?: string;
          step_name?: string;
          conversion_rate?: number;
          step_order?: number;
          created_at?: string;
          updated_at?: string;
          // AI-generated fields
          ai_predicted_conversion_rate?: number;
          ai_optimization_potential?: number;
          ai_bottleneck_score?: number;
          ai_recommendations?: string[];
          ai_last_analyzed?: string;
        };
      };
      dropoff_insights: {
        Row: {
          id: string;
          step_from: string;
          step_to: string;
          impact_score: number;
          drop_rate: number;
          affected_users: number;
          hypothesis: string;
          evidence: string[];
          created_at: string;
          updated_at: string;
          // AI-generated fields
          ai_confidence?: number;
          ai_predicted_impact?: number;
          ai_optimization_suggestions?: string[];
          ai_risk_factors?: string[];
          ai_last_analyzed?: string;
          ai_generated_hypothesis_id?: string; // New field
          ai_generated_recommendation_ids?: string[]; // New field
        };
        Insert: {
          id?: string;
          step_from: string;
          step_to: string;
          impact_score: number;
          drop_rate: number;
          affected_users: number;
          hypothesis: string;
          evidence: string[];
          created_at?: string;
          updated_at?: string;
          // AI-generated fields
          ai_confidence?: number;
          ai_predicted_impact?: number;
          ai_optimization_suggestions?: string[];
          ai_risk_factors?: string[];
          ai_last_analyzed?: string;
          ai_generated_hypothesis_id?: string; // New field
          ai_generated_recommendation_ids?: string[]; // New field
        };
        Update: {
          id?: string;
          step_from?: string;
          step_to?: string;
          impact_score?: number;
          drop_rate?: number;
          affected_users?: number;
          hypothesis?: string;
          evidence?: string[];
          created_at?: string;
          updated_at?: string;
          // AI-generated fields
          ai_confidence?: number;
          ai_predicted_impact?: number;
          ai_optimization_suggestions?: string[];
          ai_risk_factors?: string[];
          ai_last_analyzed?: string;
          ai_generated_hypothesis_id?: string; // New field
          ai_generated_recommendation_ids?: string[]; // New field
        };
      };
      recommendations: {
        Row: {
          id: string;
          dropoff_id: string;
          title: string;
          description: string;
          confidence: number;
          rationale: string;
          status: 'pending' | 'approved' | 'dismissed' | 'edited';
          created_at: string;
          updated_at: string;
          // AI-generated fields
          ai_generated?: boolean;
          ai_ranking_score?: number; // Renamed from ai_priority_score
          ai_implementation_effort?: 'low' | 'medium' | 'high';
          ai_expected_impact?: number;
          ai_success_probability?: number;
          user_feedback?: string; // New field
          jira_ticket_id?: string; // New field
          ai_estimated_impact?: number; // New field
          ai_estimated_effort?: 'low' | 'medium' | 'high'; // New field
        };
        Insert: {
          id?: string;
          dropoff_id: string;
          title: string;
          description: string;
          confidence: number;
          rationale: string;
          status?: 'pending' | 'approved' | 'dismissed' | 'edited';
          created_at?: string;
          updated_at?: string;
          // AI-generated fields
          ai_generated?: boolean;
          ai_ranking_score?: number; // Renamed from ai_priority_score
          ai_implementation_effort?: 'low' | 'medium' | 'high';
          ai_expected_impact?: number;
          ai_success_probability?: number;
          user_feedback?: string; // New field
          jira_ticket_id?: string; // New field
          ai_estimated_impact?: number; // New field
          ai_estimated_effort?: 'low' | 'medium' | 'high'; // New field
        };
        Update: {
          id?: string;
          dropoff_id?: string;
          title?: string;
          description?: string;
          confidence?: number;
          rationale?: string;
          status?: 'pending' | 'approved' | 'dismissed' | 'edited';
          created_at?: string;
          updated_at?: string;
          // AI-generated fields
          ai_generated?: boolean;
          ai_ranking_score?: number; // Renamed from ai_priority_score
          ai_implementation_effort?: 'low' | 'medium' | 'high';
          ai_expected_impact?: number;
          ai_success_probability?: number;
          user_feedback?: string; // New field
          jira_ticket_id?: string; // New field
          ai_estimated_impact?: number; // New field
          ai_estimated_effort?: 'low' | 'medium' | 'high'; // New field
        };
      };
      ai_explanations: { // New table
        Row: {
          id: string;
          dropoff_insight_id: string;
          hypothesis_text: string;
          evidence_summary: string;
          evidence_details: Record<string, any>;
          ai_reasoning_trace: Record<string, any>;
          confidence_score: number;
          generated_at: string;
          last_updated: string;
        };
        Insert: {
          id?: string;
          dropoff_insight_id: string;
          hypothesis_text: string;
          evidence_summary?: string;
          evidence_details?: Record<string, any>;
          ai_reasoning_trace?: Record<string, any>;
          confidence_score?: number;
          generated_at?: string;
          last_updated?: string;
        };
        Update: {
          id?: string;
          dropoff_insight_id?: string;
          hypothesis_text?: string;
          evidence_summary?: string;
          evidence_details?: Record<string, any>;
          ai_reasoning_trace?: Record<string, any>;
          confidence_score?: number;
          generated_at?: string;
          last_updated?: string;
        };
      };
      workflow_sync_log: { // New table
        Row: {
          id: string;
          recommendation_id: string;
          platform: 'jira' | 'notion';
          ticket_id: string | null;
          sync_status: 'success' | 'failed';
          synced_at: string;
          sync_details: Record<string, any>;
        };
        Insert: {
          id?: string;
          recommendation_id: string;
          platform: 'jira' | 'notion';
          ticket_id?: string | null;
          sync_status?: 'success' | 'failed';
          synced_at?: string;
          sync_details?: Record<string, any>;
        };
        Update: {
          id?: string;
          recommendation_id?: string;
          platform?: 'jira' | 'notion';
          ticket_id?: string | null;
          sync_status?: 'success' | 'failed';
          synced_at?: string;
          sync_details?: Record<string, any>;
        };
      };
      user_feedback: { // New table
        Row: {
          id: string;
          recommendation_id: string | null;
          feedback_type: 'approve' | 'edit' | 'dismiss' | 'explanation_clarity' | 'general';
          feedback_text: string | null;
          user_id: string | null; // Assuming user_id exists elsewhere or is captured
          created_at: string;
          context: Record<string, any> | null;
        };
        Insert: {
          id?: string;
          recommendation_id?: string | null;
          feedback_type: 'approve' | 'edit' | 'dismiss' | 'explanation_clarity' | 'general';
          feedback_text?: string | null;
          user_id?: string | null;
          created_at?: string;
          context?: Record<string, any> | null;
        };
        Update: {
          id?: string;
          recommendation_id?: string | null;
          feedback_type?: 'approve' | 'edit' | 'dismiss' | 'explanation_clarity' | 'general';
          feedback_text?: string | null;
          user_id?: string | null;
          created_at?: string;
          context?: Record<string, any> | null;
        };
      };
    };
  };
}

// Application types
export interface DropoffInsight {
  id: string;
  step_from: string;
  step_to: string;
  impact_score: number;
  drop_rate: number;
  affected_users: number;
  hypothesis: string;
  evidence: string[];
  recommendations: Recommendation[];
  ai_generated_hypothesis_id?: string; // New field
  ai_generated_recommendation_ids?: string[]; // New field
}

export interface Recommendation {
  id: string;
  title: string;
  description: string;
  confidence: number;
  rationale: string;
  status?: 'pending' | 'approved' | 'dismissed' | 'edited';
  user_feedback?: string; // New field
  jira_ticket_id?: string; // New field
  ai_estimated_impact?: number; // New field
  ai_estimated_effort?: 'low' | 'medium' | 'high'; // New field
  ai_ranking_score?: number; // Renamed from ai_priority_score
}

export interface FunnelStep {
  funnel_id: string;
  step_name: string;
  conversion_rate: number;
  step_order: number;
}

export interface User {
  user_id: string;
  segment: string;
  device: string;
  created_at: string;
}

export interface Session {
  session_id: string;
  user_id: string;
  event_path: string[];
  duration: number;
  created_at: string;
}

export interface AIExplanation { // New interface
  id: string;
  dropoff_insight_id: string;
  hypothesis_text: string;
  evidence_summary?: string;
  evidence_details?: Record<string, any>;
  ai_reasoning_trace?: Record<string, any>;
  confidence_score?: number;
  generated_at: string;
  last_updated: string;
}

export interface WorkflowSyncLog { // New interface
  id: string;
  recommendation_id: string;
  platform: 'jira' | 'notion';
  ticket_id: string | null;
  sync_status: 'success' | 'failed';
  synced_at: string;
  sync_details?: Record<string, any>;
}

export interface UserFeedback { // New interface
  id: string;
  recommendation_id: string | null;
  feedback_type: 'approve' | 'edit' | 'dismiss' | 'explanation_clarity' | 'general';
  feedback_text: string | null;
  user_id: string | null;
  created_at: string;
  context: Record<string, any> | null;
}

