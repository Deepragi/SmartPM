import { DataValidationResult } from './database.types'; // Using common types

export interface ValidationRule {
  field: string;
  type: 'required' | 'format' | 'range' | 'custom';
  message: string;
  validator?: (value: any, record?: any) => boolean;
  severity: 'error' | 'warning';
}

export interface DataQualityReport {
  overall: {
    score: number;
    grade: 'A' | 'B' | 'C' | 'D' | 'F';
    totalRecords: number;
    validRecords: number;
    invalidRecords: number;
  };
  fieldQuality: {
    [fieldName: string]: {
      completeness: number;
      validity: number;
      issues: string[];
    };
  };
  issues: {
    critical: string[];
    warnings: string[];
    suggestions: string[];
  };
  recommendations: string[];
}

export class DataValidationService {
  // Validation rules for events (simplified for generic use)
  private static readonly EVENT_RULES: ValidationRule[] = [
    {
      field: 'event_id',
      type: 'required',
      message: 'Event ID is required',
      severity: 'error'
    },
    {
      field: 'user_id',
      type: 'required',
      message: 'User ID is required',
      severity: 'error'
    },
    {
      field: 'timestamp',
      type: 'required',
      message: 'Timestamp is required',
      severity: 'error'
    },
    {
      field: 'timestamp',
      type: 'format',
      message: 'Invalid timestamp format',
      validator: (value) => DataValidationService.isValidTimestamp(value),
      severity: 'error'
    },
    {
      field: 'event_name',
      type: 'required',
      message: 'Event name is required',
      severity: 'error'
    },
    {
      field: 'event_name',
      type: 'format',
      message: 'Event name should not be empty or contain only whitespace',
      validator: (value) => typeof value === 'string' && value.trim().length > 0,
      severity: 'error'
    },
    {
      field: 'timestamp',
      type: 'range',
      message: 'Event timestamp is in the future',
      validator: (value) => new Date(value) <= new Date(),
      severity: 'warning'
    }
  ];

  // Validation rules for users (simplified for generic use)
  private static readonly USER_RULES: ValidationRule[] = [
    {
      field: 'user_id',
      type: 'required',
      message: 'User ID is required',
      severity: 'error'
    },
    {
      field: 'created_at',
      type: 'required',
      message: 'Creation date is required',
      severity: 'error'
    },
    {
      field: 'created_at',
      type: 'format',
      message: 'Invalid creation date format',
      validator: (value) => DataValidationService.isValidTimestamp(value),
      severity: 'error'
    }
  ];

  // Validation rules for sessions (simplified for generic use)
  private static readonly SESSION_RULES: ValidationRule[] = [
    {
      field: 'session_id',
      type: 'required',
      message: 'Session ID is required',
      severity: 'error'
    },
    {
      field: 'user_id',
      type: 'required',
      message: 'User ID is required',
      severity: 'error'
    },
    {
      field: 'created_at',
      type: 'required',
      message: 'Session start time is required',
      severity: 'error'
    },
    {
      field: 'created_at',
      type: 'format',
      message: 'Invalid session start time format',
      validator: (value) => DataValidationService.isValidTimestamp(value),
      severity: 'error'
    }
  ];

  // Validate generic data records
  static validateRecords(records: any[], rules: ValidationRule[]): DataValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    let validRecords = 0;
    const fieldIssues: { [field: string]: string[] } = {};

    records.forEach((record, index) => {
      let isValid = true;
      
      rules.forEach(rule => {
        const fieldValue = (record as any)[rule.field];
        const isFieldValid = this.validateField(fieldValue, rule, record);
        
        if (!isFieldValid) {
          const message = `Record ${index + 1}: ${rule.message}`;
          
          if (rule.severity === 'error') {
            errors.push(message);
            isValid = false;
          } else {
            warnings.push(message);
          }
          
          if (!fieldIssues[rule.field]) {
            fieldIssues[rule.field] = [];
          }
          fieldIssues[rule.field].push(message);
        }
      });

      if (isValid) {
        validRecords++;
      }
    });

    const totalRecords = records.length;
    const invalidRecords = totalRecords - validRecords;
    const dataQualityScore = totalRecords > 0 ? (validRecords / totalRecords) * 100 : 0;

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      summary: {
        totalRecords,
        validRecords,
        invalidRecords,
        missingFields: Object.keys(fieldIssues),
        dataQualityScore
      }
    };
  }

  // Validate events data
  static validateEvents(events: any[]): DataValidationResult {
    return this.validateRecords(events, this.EVENT_RULES);
  }

  // Validate users data
  static validateUsers(users: any[]): DataValidationResult {
    return this.validateRecords(users, this.USER_RULES);
  }

  // Validate sessions data
  static validateSessions(sessions: any[]): DataValidationResult {
    return this.validateRecords(sessions, this.SESSION_RULES);
  }

  // Generate comprehensive data quality report
  static generateDataQualityReport(
    events: any[],
    users: any[],
    sessions: any[]
  ): DataQualityReport {
    const eventValidation = this.validateEvents(events);
    const userValidation = this.validateUsers(users);
    const sessionValidation = this.validateSessions(sessions);

    const totalRecords = events.length + users.length + sessions.length;
    const totalValid = eventValidation.summary.validRecords + 
                      userValidation.summary.validRecords + 
                      sessionValidation.summary.validRecords;
    
    const overallScore = totalRecords > 0 ? (totalValid / totalRecords) * 100 : 0;
    const grade = this.getDataQualityGrade(overallScore);

    // Analyze field quality
    const fieldQuality: { [fieldName: string]: any } = {};
    
    this.analyzeFieldQuality(events, 'events', fieldQuality);
    this.analyzeFieldQuality(users, 'users', fieldQuality);
    this.analyzeFieldQuality(sessions, 'sessions', fieldQuality);

    // Collect all issues
    const critical = [
      ...eventValidation.errors,
      ...userValidation.errors,
      ...sessionValidation.errors
    ];
    
    const warnings = [
      ...eventValidation.warnings,
      ...userValidation.warnings,
      ...sessionValidation.warnings
    ];

    // Generate recommendations
    const recommendations = this.generateRecommendations(
      eventValidation,
      userValidation,
      sessionValidation,
      overallScore
    );

    return {
      overall: {
        score: Math.round(overallScore * 100) / 100,
        grade,
        totalRecords,
        validRecords: totalValid,
        invalidRecords: totalRecords - totalValid
      },
      fieldQuality,
      issues: {
        critical,
        warnings,
        suggestions: []
      },
      recommendations
    };
  }

  // Private helper methods
  private static validateField(value: any, rule: ValidationRule, record?: any): boolean {
    switch (rule.type) {
      case 'required':
        return value !== undefined && value !== null && value !== '';
      
      case 'format':
      case 'range':
      case 'custom':
        if (rule.validator) {
          return rule.validator(value, record);
        }
        return true;
      
      default:
        return true;
    }
  }

  private static analyzeFieldQuality(records: any[], type: string, fieldQuality: any): void {
    if (records.length === 0) return;

    const fields = Object.keys(records[0]);
    
    fields.forEach(field => {
      const fieldKey = `${type}.${field}`;
      const nonEmptyValues = records.filter(record => 
        record[field] !== undefined && 
        record[field] !== null && 
        record[field] !== ''
      );
      
      const completeness = (nonEmptyValues.length / records.length) * 100;
      
      const validity = 100; // Simplified for now
      
      const issues: string[] = [];
      if (completeness < 90) {
        issues.push(`Low completeness: ${Math.round(completeness)}%`);
      }

      fieldQuality[fieldKey] = {
        completeness: Math.round(completeness * 100) / 100,
        validity: Math.round(validity * 100) / 100,
        issues
      };
    });
  }

  private static getDataQualityGrade(score: number): 'A' | 'B' | 'C' | 'D' | 'F' {
    if (score >= 95) return 'A';
    if (score >= 85) return 'B';
    if (score >= 75) return 'C';
    if (score >= 65) return 'D';
    return 'F';
  }

  private static generateRecommendations(
    eventValidation: DataValidationResult,
    userValidation: DataValidationResult,
    sessionValidation: DataValidationResult,
    overallScore: number
  ): string[] {
    const recommendations: string[] = [];

    if (overallScore < 80) {
      recommendations.push('Overall data quality is below acceptable threshold. Consider reviewing data collection processes.');
    }

    if (eventValidation.summary.dataQualityScore < 90) {
      recommendations.push('Event data quality needs improvement. Focus on ensuring all required fields are populated.');
    }

    if (userValidation.summary.dataQualityScore < 90) {
      recommendations.push('User data quality needs improvement. Verify user identification and property collection.');
    }

    if (sessionValidation.summary.dataQualityScore < 90) {
      recommendations.push('Session data quality needs improvement. Check session tracking implementation.');
    }

    if (eventValidation.errors.length > 0) {
      recommendations.push('Critical errors found in event data. These must be fixed before proceeding.');
    }

    if (eventValidation.warnings.length > eventValidation.summary.totalRecords * 0.1) {
      recommendations.push('High number of warnings in event data. Consider reviewing data collection standards.');
    }

    if (recommendations.length === 0) {
      recommendations.push('Data quality is excellent! No immediate action required.');
    }

    return recommendations;
  }

  // Utility methods
  private static isValidTimestamp(timestamp: any): boolean {
    if (!timestamp) return false;
    const date = new Date(timestamp);
    return !isNaN(date.getTime());
  }

  private static isValidEmail(email: any): boolean {
    if (!email || typeof email !== 'string') return false;
    const emailRegex = /^[\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
}


