/*
  # Clean Database - Remove All Records

  1. Data Cleanup
    - Remove all records from all tables
    - Maintain table structure and relationships
    - Reset to empty state for fresh start

  2. Order of Operations
    - Delete in reverse dependency order to avoid foreign key conflicts
    - Start with dependent tables first, then parent tables
*/

-- Delete all records in dependency order (children first, then parents)
DELETE FROM workflow_syncs;
DELETE FROM recommendation_reviews;
DELETE FROM recommendations;
DELETE FROM dropoff_insights;
DELETE FROM sessions;
DELETE FROM funnels;
DELETE FROM users;

-- Verify cleanup
DO $$
DECLARE
  user_count INTEGER;
  session_count INTEGER;
  funnel_count INTEGER;
  dropoff_count INTEGER;
  recommendation_count INTEGER;
  review_count INTEGER;
  sync_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO user_count FROM users;
  SELECT COUNT(*) INTO session_count FROM sessions;
  SELECT COUNT(*) INTO funnel_count FROM funnels;
  SELECT COUNT(*) INTO dropoff_count FROM dropoff_insights;
  SELECT COUNT(*) INTO recommendation_count FROM recommendations;
  SELECT COUNT(*) INTO review_count FROM recommendation_reviews;
  SELECT COUNT(*) INTO sync_count FROM workflow_syncs;
  
  RAISE NOTICE 'Database cleanup complete:';
  RAISE NOTICE 'Users: %', user_count;
  RAISE NOTICE 'Sessions: %', session_count;
  RAISE NOTICE 'Funnel steps: %', funnel_count;
  RAISE NOTICE 'Dropoff insights: %', dropoff_count;
  RAISE NOTICE 'Recommendations: %', recommendation_count;
  RAISE NOTICE 'Reviews: %', review_count;
  RAISE NOTICE 'Workflow syncs: %', sync_count;
  
  IF user_count = 0 AND session_count = 0 AND funnel_count = 0 AND 
     dropoff_count = 0 AND recommendation_count = 0 AND 
     review_count = 0 AND sync_count = 0 THEN
    RAISE NOTICE 'SUCCESS: All tables are now empty';
  ELSE
    RAISE NOTICE 'WARNING: Some tables still contain data';
  END IF;
END $$;