/*
  # Complete SmartPM Database Schema Setup

  1. New Tables
    - `users` - User profiles with segment and device info
    - `sessions` - User session data with event paths
    - `funnels` - Conversion funnel steps and rates
    - `dropoff_insights` - AI-generated dropoff analysis
    - `recommendations` - Actionable recommendations for dropoffs
    - `recommendation_reviews` - Review decisions and notes
    - `workflow_syncs` - Integration with external workflow tools

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access all data

  3. Sample Data
    - Mock users, sessions, funnels, dropoffs, and recommendations for testing
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  user_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  segment text NOT NULL DEFAULT 'new_user',
  device text NOT NULL DEFAULT 'desktop',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create sessions table
CREATE TABLE IF NOT EXISTS sessions (
  session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(user_id) ON DELETE CASCADE,
  event_path text[] NOT NULL DEFAULT '{}',
  duration integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create funnels table
CREATE TABLE IF NOT EXISTS funnels (
  funnel_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  step_name text NOT NULL,
  conversion_rate numeric(5,4) NOT NULL DEFAULT 0.0000,
  step_order integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create dropoff_insights table
CREATE TABLE IF NOT EXISTS dropoff_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  step_from text NOT NULL,
  step_to text NOT NULL,
  impact_score numeric(3,2) NOT NULL DEFAULT 0.00,
  drop_rate numeric(5,4) NOT NULL DEFAULT 0.0000,
  affected_users integer NOT NULL DEFAULT 0,
  hypothesis text NOT NULL DEFAULT '',
  evidence text[] NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create recommendations table
CREATE TABLE IF NOT EXISTS recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dropoff_id uuid REFERENCES dropoff_insights(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  confidence numeric(3,2) NOT NULL DEFAULT 0.00,
  rationale text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add constraint for recommendations status if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'recommendations_status_check' 
    AND table_name = 'recommendations'
  ) THEN
    ALTER TABLE recommendations ADD CONSTRAINT recommendations_status_check 
    CHECK (status IN ('pending', 'approved', 'dismissed', 'edited'));
  END IF;
END $$;

-- Create recommendation_reviews table
CREATE TABLE IF NOT EXISTS recommendation_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recommendation_id uuid REFERENCES recommendations(id) ON DELETE CASCADE,
  reviewer_notes text DEFAULT '',
  decision text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Add constraint for recommendation_reviews decision if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'recommendation_reviews_decision_check' 
    AND table_name = 'recommendation_reviews'
  ) THEN
    ALTER TABLE recommendation_reviews ADD CONSTRAINT recommendation_reviews_decision_check 
    CHECK (decision IN ('approved', 'dismissed', 'edited'));
  END IF;
END $$;

-- Create workflow_syncs table
CREATE TABLE IF NOT EXISTS workflow_syncs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recommendation_id uuid REFERENCES recommendations(id) ON DELETE CASCADE,
  platform text NOT NULL,
  external_id text,
  sync_status text NOT NULL DEFAULT 'pending',
  sync_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add constraints for workflow_syncs if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'workflow_syncs_platform_check' 
    AND table_name = 'workflow_syncs'
  ) THEN
    ALTER TABLE workflow_syncs ADD CONSTRAINT workflow_syncs_platform_check 
    CHECK (platform IN ('jira', 'notion', 'linear'));
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'workflow_syncs_sync_status_check' 
    AND table_name = 'workflow_syncs'
  ) THEN
    ALTER TABLE workflow_syncs ADD CONSTRAINT workflow_syncs_sync_status_check 
    CHECK (sync_status IN ('pending', 'synced', 'failed'));
  END IF;
END $$;

-- Create indexes for better performance (only if they don't exist)
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_funnels_step_order ON funnels(step_order);
CREATE INDEX IF NOT EXISTS idx_recommendations_dropoff_id ON recommendations(dropoff_id);
CREATE INDEX IF NOT EXISTS idx_recommendation_reviews_recommendation_id ON recommendation_reviews(recommendation_id);
CREATE INDEX IF NOT EXISTS idx_workflow_syncs_recommendation_id ON workflow_syncs(recommendation_id);

-- Enable Row Level Security on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE funnels ENABLE ROW LEVEL SECURITY;
ALTER TABLE dropoff_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE recommendation_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_syncs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and recreate them
DO $$
BEGIN
  -- Drop and recreate policies for users table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON users;
  CREATE POLICY "Allow all operations for authenticated users" ON users
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

  -- Drop and recreate policies for sessions table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON sessions;
  CREATE POLICY "Allow all operations for authenticated users" ON sessions
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

  -- Drop and recreate policies for funnels table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON funnels;
  CREATE POLICY "Allow all operations for authenticated users" ON funnels
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

  -- Drop and recreate policies for dropoff_insights table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON dropoff_insights;
  CREATE POLICY "Allow all operations for authenticated users" ON dropoff_insights
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

  -- Drop and recreate policies for recommendations table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON recommendations;
  CREATE POLICY "Allow all operations for authenticated users" ON recommendations
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

  -- Drop and recreate policies for recommendation_reviews table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON recommendation_reviews;
  CREATE POLICY "Allow all operations for authenticated users" ON recommendation_reviews
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

  -- Drop and recreate policies for workflow_syncs table
  DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON workflow_syncs;
  CREATE POLICY "Allow all operations for authenticated users" ON workflow_syncs
    FOR ALL TO authenticated USING (true) WITH CHECK (true);
END $$;

-- Insert sample data for testing (using ON CONFLICT to avoid duplicates)
INSERT INTO users (user_id, segment, device) VALUES
  ('550e8400-e29b-41d4-a716-446655440001', 'power_user', 'desktop'),
  ('550e8400-e29b-41d4-a716-446655440002', 'new_user', 'mobile'),
  ('550e8400-e29b-41d4-a716-446655440003', 'casual_user', 'tablet'),
  ('550e8400-e29b-41d4-a716-446655440004', 'power_user', 'desktop'),
  ('550e8400-e29b-41d4-a716-446655440005', 'new_user', 'mobile')
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO sessions (session_id, user_id, event_path, duration) VALUES
  ('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', ARRAY['landing', 'signup', 'onboarding'], 420),
  ('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', ARRAY['landing', 'signup'], 180),
  ('650e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', ARRAY['landing'], 45),
  ('650e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440004', ARRAY['landing', 'signup', 'onboarding', 'activation'], 680),
  ('650e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440005', ARRAY['landing', 'signup', 'onboarding'], 320)
ON CONFLICT (session_id) DO NOTHING;

INSERT INTO funnels (funnel_id, step_name, conversion_rate, step_order) VALUES
  ('750e8400-e29b-41d4-a716-446655440001', 'Landing Page', 0.8500, 1),
  ('750e8400-e29b-41d4-a716-446655440002', 'Sign Up', 0.4200, 2),
  ('750e8400-e29b-41d4-a716-446655440003', 'Onboarding', 0.7800, 3),
  ('750e8400-e29b-41d4-a716-446655440004', 'Activation', 0.6500, 4)
ON CONFLICT (funnel_id) DO NOTHING;

INSERT INTO dropoff_insights (id, step_from, step_to, impact_score, drop_rate, affected_users, hypothesis, evidence) VALUES
  ('850e8400-e29b-41d4-a716-446655440001', 'Landing Page', 'Sign Up', 0.92, 0.5800, 2340, 'Complex signup form with too many required fields is causing friction. Users are abandoning before completing registration.', ARRAY['High form abandonment rate', 'Mobile users drop off 2x more', 'Time on signup page is 40% longer than benchmark']),
  ('850e8400-e29b-41d4-a716-446655440002', 'Sign Up', 'Onboarding', 0.76, 0.2200, 890, 'Email verification requirement is creating a disconnect between signup and onboarding completion.', ARRAY['24-hour delay in email verification', 'Low email open rates (32%)', 'Users who verify complete onboarding at 95% rate']),
  ('850e8400-e29b-41d4-a716-446655440003', 'Onboarding', 'Activation', 0.68, 0.3500, 1120, 'Users are overwhelmed by the number of setup steps required for activation.', ARRAY['Average onboarding session is 12 minutes vs 6 minute benchmark', 'Users exit most at step 4 of 7', 'Support tickets about setup complexity increased 40%'])
ON CONFLICT (id) DO NOTHING;

INSERT INTO recommendations (id, dropoff_id, title, description, confidence, rationale, status) VALUES
  ('950e8400-e29b-41d4-a716-446655440001', '850e8400-e29b-41d4-a716-446655440001', 'Simplify signup form', 'Reduce required fields from 8 to 3 (email, password, name)', 0.85, 'Industry benchmarks show 3-field forms have 35% higher completion rates', 'pending'),
  ('950e8400-e29b-41d4-a716-446655440002', '850e8400-e29b-41d4-a716-446655440001', 'Add social login options', 'Implement Google and Apple sign-in for faster registration', 0.78, 'Social logins reduce friction and increase mobile conversion by 25%', 'pending'),
  ('950e8400-e29b-41d4-a716-446655440003', '850e8400-e29b-41d4-a716-446655440002', 'Optional email verification', 'Allow users to proceed with onboarding before email verification', 0.72, 'Reduces immediate friction while maintaining security through later verification', 'pending'),
  ('950e8400-e29b-41d4-a716-446655440004', '850e8400-e29b-41d4-a716-446655440003', 'Progressive onboarding', 'Split onboarding into core (3 steps) and advanced (4 steps) flows', 0.81, 'Progressive disclosure reduces cognitive load and increases completion rates', 'pending')
ON CONFLICT (id) DO NOTHING;