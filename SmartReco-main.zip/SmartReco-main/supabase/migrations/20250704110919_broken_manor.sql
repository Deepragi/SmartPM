/*
  # Fix RLS policies for public access

  1. Security Updates
    - Update RLS policies to allow public read access
    - Keep write operations restricted to authenticated users
    - This allows the dashboard to display data without requiring authentication

  2. Policy Changes
    - Allow public SELECT on all tables
    - Restrict INSERT/UPDATE/DELETE to authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON users;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON sessions;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON funnels;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON dropoff_insights;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON recommendations;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON recommendation_reviews;
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON workflow_syncs;

-- Create new policies for users table
CREATE POLICY "Allow public read access" ON users
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON users
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create new policies for sessions table
CREATE POLICY "Allow public read access" ON sessions
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON sessions
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create new policies for funnels table
CREATE POLICY "Allow public read access" ON funnels
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON funnels
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create new policies for dropoff_insights table
CREATE POLICY "Allow public read access" ON dropoff_insights
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON dropoff_insights
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create new policies for recommendations table
CREATE POLICY "Allow public read access" ON recommendations
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON recommendations
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create new policies for recommendation_reviews table
CREATE POLICY "Allow public read access" ON recommendation_reviews
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON recommendation_reviews
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create new policies for workflow_syncs table
CREATE POLICY "Allow public read access" ON workflow_syncs
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow authenticated write access" ON workflow_syncs
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);