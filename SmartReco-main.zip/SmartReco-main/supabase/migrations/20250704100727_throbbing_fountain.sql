/*
  # Populate SmartPM Database with Sample Data

  1. Sample Data
    - Creates 5 sample users with different segments and devices
    - Creates 5 sample sessions with realistic event paths
    - Creates 4 funnel steps with conversion rates
    - Creates 3 dropoff insights with AI-generated hypotheses
    - Creates 4 recommendations linked to dropoff insights

  2. Data Structure
    - Users: Mix of power users, new users, and casual users
    - Sessions: Realistic user journeys through the funnel
    - Funnels: Complete conversion funnel from landing to activation
    - Dropoffs: High-impact areas where users are dropping off
    - Recommendations: AI-generated suggestions to improve conversion

  3. Purpose
    - Provides realistic demo data for the SmartPM dashboard
    - Shows the full functionality of the analytics platform
    - Demonstrates AI-powered insights and recommendations
*/

-- Clear existing data first (in case of re-runs)
DELETE FROM workflow_syncs;
DELETE FROM recommendation_reviews;
DELETE FROM recommendations;
DELETE FROM dropoff_insights;
DELETE FROM funnels;
DELETE FROM sessions;
DELETE FROM users;

-- Insert sample users
INSERT INTO users (user_id, segment, device, created_at, updated_at) VALUES
  ('550e8400-e29b-41d4-a716-446655440001', 'power_user', 'desktop', now() - interval '30 days', now() - interval '30 days'),
  ('550e8400-e29b-41d4-a716-446655440002', 'new_user', 'mobile', now() - interval '25 days', now() - interval '25 days'),
  ('550e8400-e29b-41d4-a716-446655440003', 'casual_user', 'tablet', now() - interval '20 days', now() - interval '20 days'),
  ('550e8400-e29b-41d4-a716-446655440004', 'power_user', 'desktop', now() - interval '15 days', now() - interval '15 days'),
  ('550e8400-e29b-41d4-a716-446655440005', 'new_user', 'mobile', now() - interval '10 days', now() - interval '10 days'),
  ('550e8400-e29b-41d4-a716-446655440006', 'casual_user', 'desktop', now() - interval '8 days', now() - interval '8 days'),
  ('550e8400-e29b-41d4-a716-446655440007', 'power_user', 'mobile', now() - interval '5 days', now() - interval '5 days'),
  ('550e8400-e29b-41d4-a716-446655440008', 'new_user', 'tablet', now() - interval '3 days', now() - interval '3 days'),
  ('550e8400-e29b-41d4-a716-446655440009', 'casual_user', 'desktop', now() - interval '2 days', now() - interval '2 days'),
  ('550e8400-e29b-41d4-a716-446655440010', 'power_user', 'mobile', now() - interval '1 day', now() - interval '1 day');

-- Insert sample sessions with realistic user journeys
INSERT INTO sessions (session_id, user_id, event_path, duration, created_at) VALUES
  ('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', ARRAY['landing', 'signup', 'onboarding', 'activation'], 420, now() - interval '30 days'),
  ('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', ARRAY['landing', 'signup'], 180, now() - interval '25 days'),
  ('650e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', ARRAY['landing'], 45, now() - interval '20 days'),
  ('650e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440004', ARRAY['landing', 'signup', 'onboarding', 'activation'], 680, now() - interval '15 days'),
  ('650e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440005', ARRAY['landing', 'signup', 'onboarding'], 320, now() - interval '10 days'),
  ('650e8400-e29b-41d4-a716-446655440006', '550e8400-e29b-41d4-a716-446655440006', ARRAY['landing', 'signup'], 150, now() - interval '8 days'),
  ('650e8400-e29b-41d4-a716-446655440007', '550e8400-e29b-41d4-a716-446655440007', ARRAY['landing', 'signup', 'onboarding', 'activation'], 520, now() - interval '5 days'),
  ('650e8400-e29b-41d4-a716-446655440008', '550e8400-e29b-41d4-a716-446655440008', ARRAY['landing'], 30, now() - interval '3 days'),
  ('650e8400-e29b-41d4-a716-446655440009', '550e8400-e29b-41d4-a716-446655440009', ARRAY['landing', 'signup', 'onboarding'], 280, now() - interval '2 days'),
  ('650e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440010', ARRAY['landing', 'signup', 'onboarding', 'activation'], 450, now() - interval '1 day');

-- Insert funnel steps with realistic conversion rates
INSERT INTO funnels (funnel_id, step_name, conversion_rate, step_order, created_at, updated_at) VALUES
  ('750e8400-e29b-41d4-a716-446655440001', 'Landing Page', 0.8500, 1, now() - interval '7 days', now()),
  ('750e8400-e29b-41d4-a716-446655440002', 'Sign Up', 0.4200, 2, now() - interval '7 days', now()),
  ('750e8400-e29b-41d4-a716-446655440003', 'Onboarding', 0.7800, 3, now() - interval '7 days', now()),
  ('750e8400-e29b-41d4-a716-446655440004', 'Activation', 0.6500, 4, now() - interval '7 days', now());

-- Insert dropoff insights with AI-generated hypotheses
INSERT INTO dropoff_insights (id, step_from, step_to, impact_score, drop_rate, affected_users, hypothesis, evidence, created_at, updated_at) VALUES
  (
    '850e8400-e29b-41d4-a716-446655440001', 
    'Landing Page', 
    'Sign Up', 
    0.92, 
    0.5800, 
    2340, 
    'Complex signup form with too many required fields is causing friction. Users are abandoning before completing registration, particularly on mobile devices where form completion is more challenging.',
    ARRAY[
      'High form abandonment rate of 58% vs industry average of 35%',
      'Mobile users drop off 2x more than desktop users',
      'Time on signup page is 40% longer than benchmark',
      'Heat map analysis shows users clicking away after seeing form length',
      'A/B test data suggests shorter forms increase completion by 35%'
    ],
    now() - interval '3 days',
    now() - interval '1 day'
  ),
  (
    '850e8400-e29b-41d4-a716-446655440002', 
    'Sign Up', 
    'Onboarding', 
    0.76, 
    0.2200, 
    890, 
    'Email verification requirement is creating a disconnect between signup and onboarding completion. Users who successfully sign up are not returning to complete the verification process.',
    ARRAY[
      '24-hour delay in email verification creates user drop-off',
      'Low email open rates (32%) compared to industry standard (45%)',
      'Users who verify email complete onboarding at 95% rate',
      'Support tickets about "not receiving verification email" increased 60%',
      'Mobile users less likely to check email immediately after signup'
    ],
    now() - interval '3 days',
    now() - interval '1 day'
  ),
  (
    '850e8400-e29b-41d4-a716-446655440003', 
    'Onboarding', 
    'Activation', 
    0.68, 
    0.3500, 
    1120, 
    'Users are overwhelmed by the number of setup steps required for activation. The onboarding process is too lengthy and complex, causing users to abandon before reaching the activation milestone.',
    ARRAY[
      'Average onboarding session is 12 minutes vs 6 minute benchmark',
      'Users exit most frequently at step 4 of 7 in the onboarding flow',
      'Support tickets about setup complexity increased 40%',
      'User feedback mentions "too many steps" and "confusing process"',
      'Successful users who complete onboarding show 85% retention rate'
    ],
    now() - interval '3 days',
    now() - interval '1 day'
  );

-- Insert recommendations linked to dropoff insights
INSERT INTO recommendations (id, dropoff_id, title, description, confidence, rationale, status, created_at, updated_at) VALUES
  (
    '950e8400-e29b-41d4-a716-446655440001', 
    '850e8400-e29b-41d4-a716-446655440001', 
    'Simplify signup form', 
    'Reduce required fields from 8 to 3 (email, password, name). Move additional profile information to post-signup onboarding flow.',
    0.85, 
    'Industry benchmarks show 3-field forms have 35% higher completion rates. Progressive profiling reduces initial friction while still capturing necessary data.',
    'pending',
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    '950e8400-e29b-41d4-a716-446655440002', 
    '850e8400-e29b-41d4-a716-446655440001', 
    'Add social login options', 
    'Implement Google and Apple sign-in for faster registration. Reduce form fields to zero for social login users.',
    0.78, 
    'Social logins reduce friction and increase mobile conversion by 25%. Users trust established platforms and prefer one-click registration.',
    'pending',
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    '950e8400-e29b-41d4-a716-446655440003', 
    '850e8400-e29b-41d4-a716-446655440002', 
    'Optional email verification', 
    'Allow users to proceed with onboarding before email verification. Implement progressive verification with gentle reminders.',
    0.72, 
    'Reduces immediate friction while maintaining security through later verification. Users can experience value before being asked to verify.',
    'pending',
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    '950e8400-e29b-41d4-a716-446655440004', 
    '850e8400-e29b-41d4-a716-446655440003', 
    'Progressive onboarding', 
    'Split onboarding into core (3 steps) and advanced (4 steps) flows. Allow users to start using the product after core setup.',
    0.81, 
    'Progressive disclosure reduces cognitive load and increases completion rates. Users can experience value quickly and complete advanced setup later.',
    'pending',
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    '950e8400-e29b-41d4-a716-446655440005', 
    '850e8400-e29b-41d4-a716-446655440003', 
    'Add progress indicators', 
    'Implement clear progress bars and step indicators throughout the onboarding process. Show estimated time remaining.',
    0.74, 
    'Progress indicators reduce uncertainty and increase completion rates by 23%. Users are more likely to continue when they see clear progress.',
    'pending',
    now() - interval '2 days',
    now() - interval '2 days'
  );

-- Refresh the materialized views or update any cached data
-- (This would be where you'd refresh any materialized views if they existed)

-- Verify data was inserted correctly
DO $$
DECLARE
  user_count INTEGER;
  session_count INTEGER;
  funnel_count INTEGER;
  dropoff_count INTEGER;
  recommendation_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO user_count FROM users;
  SELECT COUNT(*) INTO session_count FROM sessions;
  SELECT COUNT(*) INTO funnel_count FROM funnels;
  SELECT COUNT(*) INTO dropoff_count FROM dropoff_insights;
  SELECT COUNT(*) INTO recommendation_count FROM recommendations;
  
  RAISE NOTICE 'Data insertion complete:';
  RAISE NOTICE 'Users: %', user_count;
  RAISE NOTICE 'Sessions: %', session_count;
  RAISE NOTICE 'Funnel steps: %', funnel_count;
  RAISE NOTICE 'Dropoff insights: %', dropoff_count;
  RAISE NOTICE 'Recommendations: %', recommendation_count;
END $$;