/*
  # SmartPM Database Schema

  1. New Tables
    - `users` - User profiles with segments and device info
    - `sessions` - User session data with event paths and duration
    - `funnels` - Funnel steps with conversion rates and ordering
    - `dropoff_insights` - AI-generated drop-off analysis and hypotheses
    - `recommendations` - Actionable recommendations with confidence scores
    - `recommendation_reviews` - Human review decisions and feedback
    - `workflow_syncs` - Integration logs for JIRA/Notion pushes

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users

  3. Mock Data
    - Realistic user segments and device distributions
    - Session paths representing typical SaaS funnels
    - Drop-off insights with AI-generated hypotheses
    - Recommendations with varying confidence levels
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  user_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  segment text NOT NULL DEFAULT 'new_user',
  device text NOT NULL DEFAULT 'desktop',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Sessions table
CREATE TABLE IF NOT EXISTS sessions (
  session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(user_id) ON DELETE CASCADE,
  event_path text[] NOT NULL DEFAULT '{}',
  duration integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Funnels table
CREATE TABLE IF NOT EXISTS funnels (
  funnel_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  step_name text NOT NULL,
  conversion_rate decimal(5,4) NOT NULL DEFAULT 0.0000,
  step_order integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Dropoff insights table
CREATE TABLE IF NOT EXISTS dropoff_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  step_from text NOT NULL,
  step_to text NOT NULL,
  impact_score decimal(3,2) NOT NULL DEFAULT 0.00,
  drop_rate decimal(5,4) NOT NULL DEFAULT 0.0000,
  affected_users integer NOT NULL DEFAULT 0,
  hypothesis text NOT NULL DEFAULT '',
  evidence text[] NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Recommendations table
CREATE TABLE IF NOT EXISTS recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dropoff_id uuid REFERENCES dropoff_insights(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  confidence decimal(3,2) NOT NULL DEFAULT 0.00,
  rationale text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'dismissed', 'edited')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Recommendation reviews table
CREATE TABLE IF NOT EXISTS recommendation_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recommendation_id uuid REFERENCES recommendations(id) ON DELETE CASCADE,
  reviewer_notes text DEFAULT '',
  decision text NOT NULL CHECK (decision IN ('approved', 'dismissed', 'edited')),
  created_at timestamptz DEFAULT now()
);

-- Workflow syncs table
CREATE TABLE IF NOT EXISTS workflow_syncs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recommendation_id uuid REFERENCES recommendations(id) ON DELETE CASCADE,
  platform text NOT NULL CHECK (platform IN ('jira', 'notion', 'linear')),
  external_id text,
  sync_status text NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
  sync_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE funnels ENABLE ROW LEVEL SECURITY;
ALTER TABLE dropoff_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE recommendation_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_syncs ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allowing all operations for authenticated users for now)
CREATE POLICY "Allow all operations for authenticated users" ON users
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations for authenticated users" ON sessions
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations for authenticated users" ON funnels
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations for authenticated users" ON dropoff_insights
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations for authenticated users" ON recommendations
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations for authenticated users" ON recommendation_reviews
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations for authenticated users" ON workflow_syncs
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_funnels_step_order ON funnels(step_order);
CREATE INDEX IF NOT EXISTS idx_recommendations_dropoff_id ON recommendations(dropoff_id);
CREATE INDEX IF NOT EXISTS idx_recommendation_reviews_recommendation_id ON recommendation_reviews(recommendation_id);
CREATE INDEX IF NOT EXISTS idx_workflow_syncs_recommendation_id ON workflow_syncs(recommendation_id);