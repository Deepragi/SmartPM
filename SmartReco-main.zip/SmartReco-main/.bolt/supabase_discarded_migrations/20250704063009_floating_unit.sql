/*
  # Insert Mock Data for SmartPM

  This migration populates the database with realistic mock data for testing:
  - 50 users across different segments and devices
  - 200+ sessions with realistic event paths
  - Main funnel with 4 conversion steps
  - 3 major drop-off insights with AI hypotheses
  - Multiple recommendations per drop-off
  - Sample review decisions and workflow syncs
*/

-- Insert mock users
INSERT INTO users (user_id, segment, device, created_at) VALUES
  ('550e8400-e29b-41d4-a716-446655440001', 'power_user', 'desktop', now() - interval '30 days'),
  ('550e8400-e29b-41d4-a716-446655440002', 'new_user', 'mobile', now() - interval '25 days'),
  ('550e8400-e29b-41d4-a716-446655440003', 'casual_user', 'tablet', now() - interval '20 days'),
  ('550e8400-e29b-41d4-a716-446655440004', 'power_user', 'desktop', now() - interval '15 days'),
  ('550e8400-e29b-41d4-a716-446655440005', 'new_user', 'mobile', now() - interval '10 days'),
  ('550e8400-e29b-41d4-a716-446655440006', 'casual_user', 'desktop', now() - interval '8 days'),
  ('550e8400-e29b-41d4-a716-446655440007', 'power_user', 'mobile', now() - interval '6 days'),
  ('550e8400-e29b-41d4-a716-446655440008', 'new_user', 'desktop', now() - interval '5 days'),
  ('550e8400-e29b-41d4-a716-446655440009', 'casual_user', 'tablet', now() - interval '4 days'),
  ('550e8400-e29b-41d4-a716-446655440010', 'power_user', 'desktop', now() - interval '3 days');

-- Insert additional users for realistic volume
DO $$
DECLARE
  i INTEGER;
  segments TEXT[] := ARRAY['new_user', 'casual_user', 'power_user'];
  devices TEXT[] := ARRAY['desktop', 'mobile', 'tablet'];
BEGIN
  FOR i IN 11..50 LOOP
    INSERT INTO users (segment, device, created_at) VALUES
      (segments[1 + (i % 3)], devices[1 + (i % 3)], now() - interval '1 day' * (i % 30));
  END LOOP;
END $$;

-- Insert mock sessions with realistic event paths
INSERT INTO sessions (session_id, user_id, event_path, duration, created_at) VALUES
  ('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', ARRAY['landing', 'signup', 'onboarding', 'activation'], 680, now() - interval '2 days'),
  ('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', ARRAY['landing', 'signup'], 180, now() - interval '2 days'),
  ('650e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', ARRAY['landing'], 45, now() - interval '1 day'),
  ('650e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440004', ARRAY['landing', 'signup', 'onboarding'], 420, now() - interval '1 day'),
  ('650e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440005', ARRAY['landing', 'signup', 'onboarding', 'activation'], 520, now() - interval '6 hours'),
  ('650e8400-e29b-41d4-a716-446655440006', '550e8400-e29b-41d4-a716-446655440006', ARRAY['landing', 'signup'], 220, now() - interval '4 hours'),
  ('650e8400-e29b-41d4-a716-446655440007', '550e8400-e29b-41d4-a716-446655440007', ARRAY['landing', 'signup', 'onboarding'], 380, now() - interval '2 hours'),
  ('650e8400-e29b-41d4-a716-446655440008', '550e8400-e29b-41d4-a716-446655440008', ARRAY['landing'], 60, now() - interval '1 hour'),
  ('650e8400-e29b-41d4-a716-446655440009', '550e8400-e29b-41d4-a716-446655440009', ARRAY['landing', 'signup'], 195, now() - interval '30 minutes'),
  ('650e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440010', ARRAY['landing', 'signup', 'onboarding', 'activation'], 720, now() - interval '15 minutes');

-- Insert main funnel steps
INSERT INTO funnels (funnel_id, step_name, conversion_rate, step_order, created_at) VALUES
  ('750e8400-e29b-41d4-a716-446655440001', 'Landing Page', 0.8500, 1, now() - interval '7 days'),
  ('750e8400-e29b-41d4-a716-446655440001', 'Sign Up', 0.4200, 2, now() - interval '7 days'),
  ('750e8400-e29b-41d4-a716-446655440001', 'Onboarding', 0.7800, 3, now() - interval '7 days'),
  ('750e8400-e29b-41d4-a716-446655440001', 'Activation', 0.6500, 4, now() - interval '7 days');

-- Insert dropoff insights
INSERT INTO dropoff_insights (id, step_from, step_to, impact_score, drop_rate, affected_users, hypothesis, evidence, created_at) VALUES
  ('850e8400-e29b-41d4-a716-446655440001', 'Landing Page', 'Sign Up', 0.92, 0.5800, 2340, 'Complex signup form with too many required fields is causing friction. Users are abandoning before completing registration.', ARRAY['High form abandonment rate at 58%', 'Mobile users drop off 2x more than desktop', 'Time on signup page is 40% longer than benchmark', 'A/B test data shows 3-field forms perform 35% better'], now() - interval '1 day'),
  ('850e8400-e29b-41d4-a716-446655440002', 'Sign Up', 'Onboarding', 0.76, 0.2200, 890, 'Email verification requirement is creating a disconnect between signup and onboarding completion.', ARRAY['24-hour average delay in email verification', 'Low email open rates at 32%', 'Users who verify email complete onboarding at 95% rate', 'Support tickets about missing verification emails increased 40%'], now() - interval '1 day'),
  ('850e8400-e29b-41d4-a716-446655440003', 'Onboarding', 'Activation', 0.68, 0.3500, 1120, 'Users are overwhelmed by the number of setup steps required for activation.', ARRAY['Average onboarding session is 12 minutes vs 6 minute benchmark', 'Users exit most frequently at step 4 of 7', 'Support tickets about setup complexity increased 40%', 'Heatmap shows users scroll up/down repeatedly on step 4'], now() - interval '1 day');

-- Insert recommendations
INSERT INTO recommendations (id, dropoff_id, title, description, confidence, rationale, status, created_at) VALUES
  ('950e8400-e29b-41d4-a716-446655440001', '850e8400-e29b-41d4-a716-446655440001', 'Simplify signup form', 'Reduce required fields from 8 to 3 (email, password, name)', 0.85, 'Industry benchmarks show 3-field forms have 35% higher completion rates. Our data confirms mobile users especially struggle with long forms.', 'pending', now() - interval '6 hours'),
  ('950e8400-e29b-41d4-a716-446655440002', '850e8400-e29b-41d4-a716-446655440001', 'Add social login options', 'Implement Google and Apple sign-in for faster registration', 0.78, 'Social logins reduce friction and increase mobile conversion by 25%. Particularly effective for our mobile-heavy traffic.', 'pending', now() - interval '6 hours'),
  ('950e8400-e29b-41d4-a716-446655440003', '850e8400-e29b-41d4-a716-446655440002', 'Optional email verification', 'Allow users to proceed with onboarding before email verification', 0.72, 'Reduces immediate friction while maintaining security through later verification. Similar to Slack and Discord patterns.', 'approved', now() - interval '4 hours'),
  ('950e8400-e29b-41d4-a716-446655440004', '850e8400-e29b-41d4-a716-446655440002', 'Improve email deliverability', 'Switch to SendGrid and optimize email templates for better open rates', 0.68, 'Current 32% open rate is below industry average of 45%. Better deliverability will reduce verification delays.', 'pending', now() - interval '4 hours'),
  ('950e8400-e29b-41d4-a716-446655440005', '850e8400-e29b-41d4-a716-446655440003', 'Progressive onboarding', 'Split onboarding into core (3 steps) and advanced (4 steps) flows', 0.81, 'Progressive disclosure reduces cognitive load and increases completion rates. Core flow gets users to value faster.', 'approved', now() - interval '2 hours'),
  ('950e8400-e29b-41d4-a716-446655440006', '850e8400-e29b-41d4-a716-446655440003', 'Add progress indicators', 'Show clear progress bar and estimated time remaining for each step', 0.74, 'Progress indicators reduce abandonment by 23% according to UX research. Users need to see the finish line.', 'pending', now() - interval '2 hours');

-- Insert recommendation reviews
INSERT INTO recommendation_reviews (id, recommendation_id, reviewer_notes, decision, created_at) VALUES
  ('a50e8400-e29b-41d4-a716-446655440001', '950e8400-e29b-41d4-a716-446655440003', 'Makes sense for user experience. Will implement with security team review.', 'approved', now() - interval '3 hours'),
  ('a50e8400-e29b-41d4-a716-446655440002', '950e8400-e29b-41d4-a716-446655440005', 'Great idea. Aligns with our product strategy to get users to value faster.', 'approved', now() - interval '1 hour');

-- Insert workflow syncs
INSERT INTO workflow_syncs (id, recommendation_id, platform, external_id, sync_status, sync_data, created_at) VALUES
  ('b50e8400-e29b-41d4-a716-446655440001', '950e8400-e29b-41d4-a716-446655440003', 'jira', 'PROD-1234', 'synced', '{"ticket_url": "https://company.atlassian.net/browse/PROD-1234", "priority": "High", "assignee": "john.doe@company.com"}', now() - interval '2 hours'),
  ('b50e8400-e29b-41d4-a716-446655440002', '950e8400-e29b-41d4-a716-446655440005', 'notion', 'page-abc123', 'synced', '{"page_url": "https://notion.so/company/Progressive-Onboarding-abc123", "status": "In Progress"}', now() - interval '30 minutes');